import init from './Api/init'//引入封装方法
let util = require('./Api/util')//
import './utils/mp-weixin'
App({
  onLaunch() {
    init()
    
    let system = wx.getSystemInfoSync();
    let rect = wx.getMenuButtonBoundingClientRect();
    let spacing = rect.top - system.statusBarHeight; // 状态栏与胶囊之间的间距
    this.globalData.width = system.screenWidth;
    this.globalData.height = system.screenHeight;
    this.globalData.statusBarHeight = system.statusBarHeight;
    this.globalData.titleBarHeight = rect.height + spacing * 2;
    this.globalData.navigationBarHeight = this.globalData.statusBarHeight + this.globalData.titleBarHeight;
    let customBar = rect.bottom + rect.top - system.statusBarHeight
    this.globalData.customBar = customBar
    // 透明头部 end
   this.globalData.topheight= rect.bottom + rect.top - system.statusBarHeight
    // 透明头部 end
    
    // 通过mp-weixin全局注入一个store对象，更改使用  this.setData({})  即可同步全局数据
    // 当注入store时，组件内的生命周期需写到 [lifetimes] 中，Component->lifetimes->attached()
    // 参考链接：https://hub.nuaa.cf/theajack/mp-mixin
    // 必须引入该Mixins，控制组件的audio音频播放

    // const mixin = {
    //   store: {userInfo: wx.$cache.get("userInfo")||{"test":true}}
    // }
    // wx.mixin(mixin)

    wx.$http(wx.$api.get_show).then(res => {
      wx.$cache.set('can', res)
      if (res.edition == 1) {
        /*如果显示配置中版本为过审版本，小程序上线有诸多限制，
        为保证上线顺畅，我们与后端约定了两个版本切换，
        一个过审版edition == 1一个运营版为edition == 2，
        当运营版时项目已经上线，可以展示一些资质不限定的内容*/
            if (system.platform == 'ios') {//当前系统为ios时
              wx.$IOS = true//ios为true，这里主要用来做虚拟支付判定，非虚拟支付的板块继续用配置中的edition判断显示隐藏
            }
          }
    })
    let mixin = {
      store: {
        domain: wx.$domain
      }
    }
    wx.mixin(mixin)
    //请求分享图，可以获得随机分享图一张，存参数为share，不要改变参数值，所有小程序都需要请求，然后分享中使用该参数
    wx.$http(wx.$api.get_share).then(ress => {
      wx.$cache.set('share', ress)
    }).catch(err=>{
      console.error(err)
    })
    // wx.$http(wx.$api.show_setting).then(ress => {
    //   if (ress.edition == 1) {
    //     if (res.platform == 'ios') {
    //       this.globalData.ios = true
    //     }
    //   }
    //   wx.$cache.set('can', ress)
    // })
    // 分享 end
  },
  onShow(e) {
    if(e.query.pid){
      if(wx.$cache.get('member_id')==e.query.pid){
      }else{
        wx.$cache.set('pid',e.query.pid)
      }
    }
     /*
    非测试账号时，为避免之前的测试体验账号存有key，故而进行清空，默认请求key为1
    */
   if(wx.$cache.get('key')==1){
    wx.$cache.set('key','')
  }
/*
当新项目拿到后，由于这时候客户可能还没有小程序账号，为方便开发，我们与后端约定，key=1为测试通用key。同样作为有效凭证返回数据
*/
  // wx.$cache.set('key',1)//设置默认key为1，此为测试操作
  // wx.$cache.set('member_id',1)//设置默认用户id为1，此为测试操作
  // if(!wx.$cache.get('key')){
  //  //当本地检测没有key值时，携带code，p_id向服务器申请key，p_id为上级用户id，当没有时，默认为0，这里要求是哪怕是非分销项目也要将上级id传上去
  // wx.login({
  //   success: ras => {
  //     var pamdata = {
  //       code: ras.code,
  //       p_id: wx.$cache.get('pid') || 0
  //     };
  //     // 传递code 已及 分享id
  //     wx.$http.post(wx.$api.getopenid, pamdata).then(res => {
  //       console.log('登录', res)//返回的res已经经过拦截器，拿到的是实际的后端参数
  //       // 存入用户 token 与 id
  //       wx.$cache.set('key', res.token)//存入用户key，请求数据凭证，请勿修改参数名
  //       wx.$cache.set('member_id', res.info.id)//存入用户id
  //     })
  //   }
  // })
  // }

  /*city()只有需要定位的项目需要用到*/
  
    //  this.city()//获取地理位置
    //  console.log(wx.$datetype(new Date().getTime()))
     
  },
  city() { //获取地理位置
    var that = this
    util.getLocation('', true, '', function (e) {
      console.log(e)
      let params = {
        latitude: e.latitude,
        longitude: e.longitude
      }
      util.locationDetails(params).then((res)=>{
       
        wx.$cityInfo={//$cityInfo为地理位置固定参数，可以增加参数，但是不能改命名，避免后续维护成本
          'province':res.result.address_component.province,//存入省市
          'city': res.result.address_component.city,//存入城市
          'area': res.result.address_component.district,//存入区县
          'lat':res.result.location.lat,//存入经纬度
          'lng': res.result.location.lng,
          'addressinfo': res.result.address,//详细地址描述
        }
        console.log('获取到了位置',  wx.$cityInfo)
        //拿到页面栈
        var pageArr = getCurrentPages();
        var thisPage = pageArr[pageArr.length - 1];
        // setTimeout(() => {
        //   thisPage.onShow()//页面回显的方法再次执行，这时候对于需要位置才能用的接口可以放到这里
        // thisPage.init()
        // /**或者这里。init为初始化页面需要执行的页面逻辑。这里与onshow有异曲同工之妙
        // ，但是一般onshow执行多次，init只执行一次，考虑到页面栈的框架逻辑这里并未调用onload。在写项目是也不要外部调onload*/
        // }, 800);
      })
    }, function (err) {
      console.log(err)
    })
  },
  globalData: {
    
   
  }
})