var datechoose = require('datechoose.js');
var day = '';
var hour = '';
var min = '';
var oldtime = []
Component({

  /**
   * 页面的初始数据
   */
  data: {
    lotindex: 0,
    lotdateidx: [0, 0, 0],
    lotdate: [],
  },
  properties: {
    start: {
      type: Number,
      default:new Date().getTime()
    },
    daynum:{
      type: Number,
      default:7
    },
    dataid:{
      type: Number,
      default:0
    },
    value: {
      type: Number,
      default: new Date().getTime()
    },
  },

  lifetimes: {
  
    attached: function () {
    // console.log(this.data.dataid,3411111111)
      var that = this;
    // // console.log('value',this.data.value,'star', this.data.start,88888888888)
    //   if (!that.data.start) {
    //     that.data.start = new Date();
    //   }
    //   if (!that.data.value) {
    //     that.data.value = new Date();
    //   }
     
    //   if(new Date(that.data.value)<new Date(that.data.start)){
    //     that.data.value=that.data.start
    //   }
    //   var ntime = new Date(that.data.start);
    //   var did = Math.ceil((ntime.getTime() - (new Date().getTime())) / 86400000);
    //   var hid = ntime.getHours();
    //   var mid = ntime.getMinutes();
    //   var vntime = new Date(that.data.value);
    //   var vdid = Math.ceil((vntime.getTime() - (new Date().getTime())) / 86400000);
    //   var vhid = vntime.getHours();
    //   var vmid = vntime.getMinutes();
    // // console.log('value',[vdid, vhid, vmid + 1],'star', [did, hid, mid + 1])
    // // console.log(ntime,that.data.value,vntime,'111111')
    //   wx.getSystemInfo({
    //     //获取系统信息成功，将系统窗口的宽高赋给页面的宽高  
    //     success: function (res) {
      
     console.log(this.data)
          that.setData({
            lotdate: datechoose.AddDays(this.data.daynum),
            // lotdateidx: [vdid, vhid, vmid + 1],
          })
    //       oldtime = [did, hid, mid + 1];
    //     }
    //   })
    }
  },
  observers: {
    'start, value': function(start, value) {
      var dataid=this.data.dataid
   
      var that = this;
      if (!that.data.start) {
        that.data.start = new Date();
      }
      if (!that.data.value) {
        that.data.value = new Date();
      }
     
      if(new Date(that.data.value)<new Date(that.data.start)){
        that.data.value=that.data.start
      }
      var ntime = new Date();
      var did = Math.ceil((ntime.getTime() - (new Date().getTime())) / 86400000);
      var hid = ntime.getHours();
      var mid = ntime.getMinutes();
      var vntime = new Date(that.data.value);
      var vdid = Math.ceil((vntime.getTime() - (new Date().getTime())) / 86400000);
      var vhid = vntime.getHours();
      var vmid = vntime.getMinutes();
    // console.log(ntime,that.data.value,vntime,'999999')
    // console.log('value',[vdid, vhid, vmid + 1],'star', [did, hid, mid + 1])
      wx.getSystemInfo({
        //获取系统信息成功，将系统窗口的宽高赋给页面的宽高  
        success: function (res) {
          that.setData({
             [`lotdateidx[${dataid}]`]: [vdid, vhid, vmid + 1],
          })
          oldtime = [did, hid, mid + 1];
        }
      })
      // var nd = new Date().getTime() + vdid * 24 * 60 * 60 * 1000 + vhid * 60 * 60 * 1000 + vmid * 60 * 1000;
      // var lotteryname = datechoose.datetransition(new Date(nd).getTime());
      // this.triggerEvent('change', {
      //   lotterytime: new Date(nd).getTime(),
      //   day: lotteryname
      // })
    }
  },
  methods: {
    //选择时间；
    tapdate(){
      var dataid=this.data.dataid
      var that = this;
      // if (!that.data.start) {
      //   that.data.start = new Date();
      // }
      // if (!that.data.value) {
      //   that.data.value = new Date();
      // }
     
      if(new Date(that.data.value)<new Date(that.data.start)){
        that.data.value=that.data.start
      }

      var ntime = new Date(that.data.start);
      var did = Math.ceil((ntime.getTime() - (new Date().getTime())) / 86400000);
      var hid = ntime.getHours();
      var mid = ntime.getMinutes();
      var vntime = new Date(that.data.value);
      var vdid =Math.abs(Math.ceil((vntime.getTime() - (new Date().getTime())) / 86400000));
      var vhid = vntime.getHours();
      var vmid = vntime.getMinutes();
    // console.log(ntime,that.data.value,vntime,'999999')
    // console.log('value',[vdid, vhid, vmid + 1],'star', [did, hid, mid + 1])
      wx.getSystemInfo({
        //获取系统信息成功，将系统窗口的宽高赋给页面的宽高  
        success: function (res) {
          that.setData({
              [`lotdateidx[${dataid}]`]: [vdid, vhid, vmid + 1],
            })
             oldtime = [did, hid, mid + 1]
        }
      })
    },
    changeDateTime2() {
      var dataid=this.data.dataid
    // console.log(oldtime);
      this.setData({
        [`lotdateidx[${dataid}]`]: oldtime
      })
    },
    changeDateTime1: function (e) {
      var dataid=this.data.dataid
      var that = this
      oldtime = [];
      that.setData({
        [`lotdateidx[${dataid}]`]: e.detail.value
      })
      var timeidx = e.detail.value;

      var ntime = new Date();
      ntime = new Date(ntime.toLocaleDateString());
      ntime = ntime.getTime();
      var nd = ntime + timeidx[0] * 24 * 60 * 60 * 1000 + timeidx[1] * 60 * 60 * 1000 + timeidx[2] * 60 * 1000;
      var lotteryname = wx.$datetype(new Date(nd).getTime());

      this.triggerEvent('change', {
        lotterytime: new Date(nd).getTime(),
        day: lotteryname
      })
    },
    changeDateTimeColumn1: function (e) {
      var dataid=this.data.dataid
      var that = this;
      if (oldtime.length < 1) {
        oldtime = that.data.lotdateidx[dataid]
      }
      var ntime = new Date(that.data.start);
    // console.log(e.detail.value)
      var did = oldtime[0]
      var hid = oldtime[1]
      //ntime.getHours();
      var mid = oldtime[2]
      //ntime.getMinutes();
    // console.log(that.data.lotdateidx[dataid])
      if (e.detail.column == 0) {
        day = e.detail.value;
      }
      if (e.detail.column == 1) {
        hour = e.detail.value;
        if (day == "") {
          day = that.data.lotdateidx[dataid][0]
        }
      }
     
      if (e.detail.column == 2) {
        min = e.detail.value;
        if (hour == "") {
          hour = that.data.lotdateidx[dataid][1];
          day = that.data.lotdateidx[dataid][0]
        }
      }
      switch (e.detail.column) {
        case 0:
          if (day <= did) {
            that.setData({
              [`lotdateidx[${dataid}][0]`]: did,
              [`lotdateidx[${dataid}][1]`]: hid,
              [`lotdateidx[${dataid}][2]`]: mid == 59 ? 0 : mid + 1
            })
            // if (hour <= hid) {

            //   if (min <= mid) {
            //     that.setData({
            //       [`lotdateidx[${dataid}][0]`]: did,
            //       [`lotdateidx[${dataid}][1]`]: hid,
            //       [`lotdateidx[${dataid}][2]`]:  mid == 59 ? 0 : mid + 1
            //     })
            //   } else {
            //     that.setData({
            //       [`lotdateidx[${dataid}][0]`]:did,
            //       [`lotdateidx[${dataid}][1]`]: hid,
            //       [`lotdateidx[${dataid}][2]`]:  mid
            //     })
            //   }
            // }
          }
          break;
        case 1:
          if (day == did) {
            if (e.detail.value <= hid) {
              that.setData({
                [`lotdateidx[${dataid}][0]`]: 0,
                [`lotdateidx[${dataid}][1]`]: hid,
                [`lotdateidx[${dataid}][2]`]: mid == 59 ? 0 : mid + 1
              })
            }
          }
          break;
        case 2:
          if (e.detail.value <= mid && day == 0) {
            if (hour <= hid) {
              that.setData({
                [`lotdateidx[${dataid}][0]`]: 0,
                [`lotdateidx[${dataid}][1]`]: hid,
                [`lotdateidx[${dataid}][2]`]: mid == 59 ? 0 : mid + 1
              })
            }
          }
          break;
        default:
          return
      }
    },
  }
})