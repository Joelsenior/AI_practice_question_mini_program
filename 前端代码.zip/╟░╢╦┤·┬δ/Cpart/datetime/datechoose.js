const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('-') + '+' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

function AddDays(daynum) {
  var od = new Date();
  od = od.valueOf();
  var minute = []
  var hour = []
  for (let i = 0; i < 60; i++) {
    let item = null
    if (i < 10) {
      item = '0' + i
    } else {
      item = i
    }
    minute.push(item)
  }
  for (let i = 0; i < 24; i++) {
    let item = ''
    if (i < 10) {
      item = '0' + i
    } else {
      item = i
    }
    hour.push(item)
  }
  var dayarr = ['今天'];
  let show_day = new Array('周日', '周一', '周二', '周三', '周四', '周五', '周六');
  console.log(daynum)
  for (let i = 1; i < daynum; i++) {
    var nd = od + i * 24 * 60 * 60 * 1000;
    nd = new Date(nd);
    var d = nd.getDate();
    var xq = nd.getDay();
    var M = (nd.getMonth() + 1 < 10 ? '0' + (nd.getMonth() + 1) : nd.getMonth() + 1);
    if (d <= 9) d = "0" + d;
    dayarr.push(M+'月'+d + '日(' + show_day[xq] + ')')
  }
  var newdayarr = [dayarr, hour, minute]

  return newdayarr;
}



module.exports = {
  formatTime: formatTime,
  AddDays: AddDays

}