let app = getApp()

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    show:{
      type:Boolean,
      value:false
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },
  lifetimes:{
    show(){
      wx.login({
        success(res){
          app.code = res.code
        }
      })
    },
  },
  /**
   * 组件的方法列表
   */
  methods: {
    getPhoneNumber(e){
      var that = this
      wx.login({
        success(codeinfo){
    var params = {
      code:codeinfo.code,
      encryptedData:e.detail.encryptedData,
      iv:e.detail.iv,
      session_key:wx.$cache.get('key')
    }
    wx.$http.post(wx.$api.decryption,params).then(res=>{
      console.log('获取手机号', res)
      wx.$cache.set('phone',res);
      that.triggerEvent('phonesc',{}, )
      that.setData({
        show:false
      })
 
      // if(wx.$cache.get('key')){//如果已经有用户key，直接调起绑定
        that.bang(res)
      // }else{

      // }
     
    }).catch(()=>{
      
    })
  },
})
    },
    getuserinfo() {
      wx.$http.post(wx.$api.get_member_info, {}).then(res => {
        console.log(res, '用户信息')
        wx.$cache.set('userInfo', res)
        wx.$cache.set('member_id', res.id)
        var pageArr = getCurrentPages();
        var thisPage = pageArr[pageArr.length - 1];
        thisPage.onShow()
        thisPage.setData({
          login: false
        })

      })
    },
    bang(e){//绑定手机号
      var that = this
      var params = {
        mobile:e
      }
      wx.$http.post(wx.$api.edit_member,params).then(res=>{
        console.log('绑定手机号', res)
          wx.$cache.set('phone',e)
       this.getuserinfo();
  
              })
    }
  },
  
})
