const app = getApp();
Component({
    lifetimes: {
        attached() {
            let res = wx.getSystemInfoSync();
            if (getCurrentPages().length > 1) {
                this.setData({
                    leftimg2: true,
                })
            }
            let rect = wx.getMenuButtonBoundingClientRect();
            let customBar = res.statusBarHeight + rect.height + (rect.top - res.statusBarHeight) * 2
            console.log("res", res)
            this.setData({
                customBar,
                statusBarHeight: rect.top,
                navH: rect.height,
            })
        },

    },
    properties: {
        title: {//title字
            type: String,
            value: '我的错题'
        },
        bgColor: {//背景颜色
            type: String,
            value: ''
        },
        bgSrc: {//背景图
            type: String,
            value: ''
        },
        color: {//字体颜色
            type: String,
            value: 'black'
        },

        flexd: {//是否固定占位，默认固定
            type: Boolean,
            value: true
        },
        flage: {//是否返回首页
            type: Boolean,
            value: false
        }
    },
    data: {
        leftimg2: true,
        statusBarHeight: 0,
        navH: 0,

    },
    /**
     * 组件的初始数据
     */
    data: {
        // top:app.globalData.top,
        customBar: '',//头部高度
    },
    /**
     * 组件的方法列表
     */
    methods: {
        black() {
            if (this.data.flage) {
                wx.switchTab({
                    url: '/pages/index/index',
                })
            } else {
                wx.navigateBack(
                    {
                        delta: 1,
                        fail: (err => {
                            wx.switchTab({
                                url: '/pages/index/index',
                            })
                        })
                    }
                )
            }
        },
    }
})
