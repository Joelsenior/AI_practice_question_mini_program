// components/NavigationBar/NavigationBar.js
const app = getApp()

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    justify: {
      type: String,
      value: ""
    },
    title: { // 标题
      type: String,
      value: ""
    },
    color: { // 标题的字体颜色&返回图标的字体颜色
      type: String,
      value: "#1B1B1B"
    },
    flexd1: {
      type: String,
      value: ""
    },
    bgColor: {
      type: String,
      value: ""
    },
    showBack: { // 是否显示返回图标
      type: Boolean,
      value: false
    },
    bgSrc: { // 导航栏背景的源
      type: String,
      value: ""
    },
    flage: { //是否返回首页
      type: Boolean,
      value: false
    },
    mode: { // 显示背景的模式, 同官方image一致
      type: String,
      value: "scaleToFill"
    },
    height: { // 背景的高度
      type: Number,
      value: 0
    },
    navigateTo: { // 按下返回图标时跳转的路径
      type: String,
      value: ""
    },
    navigateBack: { // 按下返回图标时返回的层数
      type: Number,
      value: 1
    },
    noPlaceholder: {  //  是否不占位
      type: Boolean,
      value: false
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    statusBarHeight: app.globalData.statusBarHeight,
    titleBarHeight: app.globalData.titleBarHeight,
    navigationBarHeight: app.globalData.navigationBarHeight,
  },
  attached() {
    if (getCurrentPages().length > 1) {
      this.setData({
        showBack: true,
      })
    }
  },
  /**
   * 组件的方法列表
   */
  methods: {
    back: function () {

      // if (this.properties.navigateTo !== "") {
      //   wx.navigateTo({
      //     url: this.navigateTo,
      //   })
      //   return
      // }

      if (this.properties.navigateBack > 0) {
        if (this.data.flage) {
          wx.navigateTo({
            url: '/pages/index/index'
          })
        } else {
          wx.navigateBack({
            delta: this.navigateBack
          })
        }
        return
      }

      throw ("请检查是否有为返回图标设置跳转规则")
    }
  }
})