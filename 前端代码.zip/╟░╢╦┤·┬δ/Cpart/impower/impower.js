let app = getApp();

Component({
    data: {
        userInfo: {}, // 用户信息
        active: false,
        phoActive: false,

    },
    properties: {
        // 登录状态
        login: {
            type: Boolean,
            value: false
        },
        Authorization_type: { //授权类型
            type: String,
            value: 'user'
        }
    },
    observers: {
        'login': function (login) {
            var that = this;
            var Authorization_type = this.data.Authorization_type;
            // 在 numberA 或者 numberB 被设置时，执行这个函数
            console.log(login)
            if (login) { //当要求弹起授权时
                switch (Authorization_type) {
                    case 'user': //只授权头像昵称
                        that.setData({
                            active: true,
                        })
                        break;
                    case 'phone': //只授权手机号
                        that.setData({
                            phoActive: true,
                        })
                        break;
                    case 'user_phone': //先授权头像昵称，接着授权手机号
                        that.setData({
                            active: true,
                        })
                        break;
                    case 'phone_user': //先授权手机号，接着授权头像昵称
                        if (wx.$cache.get('phone')) {
                            that.setData({
                                active: true,
                            })
                        } else {
                            that.setData({
                                phoActive: true,
                            })
                        }

                        break;

                }

            } else {
                that.setData({
                    active: false,
                    phoActive: false,
                })
            }
        }
    },
    methods: {
        // 授权
        async auth() {

            // 获取用户信息
            let res = await wx.getUserProfile({
                desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
            })
            console.log('userInfo',res.userInfo);
            this.setData({
                userInfo: res.userInfo,
            })
            wx.login({
                success: ras => {
                    var pamdata = {
                        code: ras.code,
                        p_id: wx.$cache.get('pid') || 0,
                        mobile: 13111111111,
                    };
                    if (wx.$cache.get('phone')) { //如果有手机号，将手机号吗带入，这样就处理了手机号或者先手机号的问题
                        pamdata.mobile = wx.$cache.get('phone');
                    }
                    // 传递code 已及 分享id
                    wx.$http.post(wx.$api.getopenid, pamdata).then(res => {
                        if (res.state) {
                            console.log('登录', res)

                            // 存入用户 token 与 id,这里接口可能会变化

                            wx.$cache.set('key', res.token ? res.token : '')
                            if (!wx.$cache.get('member_id')) { //没有用户id时
                                wx.$cache.set('member_id', res.info.id ? res.info.id : '')
                            }
                            this.login()
                        }

                    })
                }
            })
        },
        // 登录
        login() {
            let uerInfo = this.data.userInfo
            let params = {
                nickname: uerInfo.nickName,
                img: uerInfo.avatarUrl,
                gender: uerInfo.gender
            }
            if (wx.$cache.get('phone')) { //如果有手机号，将手机号吗带入，这样就处理了手机号或者先手机号的问题
                params.mobile = wx.$cache.get('phone');
            }

            // 传递后端登录信息
            wx.$http.post(wx.$api.edit_member, params).then(res => {
                console.log(res, '更新头像')
                if (this.data.Authorization_type == 'user_phone') {//先授权后绑定
                    if (!wx.$cache.get('phone')) {
                        this.setData({
                            phoActive: true,
                            active: false,
                        })
                    } else {
                        this.getuserinfo()
                    }
                }

            })
        },
        getuserinfo() {
            wx.$http.post(wx.$api.get_member_info, {}).then(res => {
                console.log(res, '用户信息')
                wx.$cache.set('userInfo', res)
                wx.$cache.set('member_id', res.id)
                var pageArr = getCurrentPages();
                var thisPage = pageArr[pageArr.length - 1];
                thisPage.onShow()
                thisPage.setData({
                    login: false,
                    userInfo: res
                })

            })
        },
        phoneSc() {
            console.log(222)
            this.setData({
                phoActive: false
            })
        },
        // 取消授权
        closeActive() {
            this.setData({
                active: false
            })
            wx.switchTab({
                url: '/pages/index/index',
            })
        },


    },
})