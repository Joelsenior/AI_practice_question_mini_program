var app = getApp();
Page({
  data: {
    isDark: false, //是否暗夜模式
    showSelector: false, //是否显示收藏类型弹窗
    showModal: false, //是否显示移除题目弹窗
    showSheet: false, //是否显示答题卡
    libraryId: 0,
    page: 1,
    subjectList: [],
    askindex: 0, //当前所处小问，
    selectSubjectIndex: 0, //  当前题目对应答题卡的索引
    subjectMakeCardList: [], //  答题卡列表
    params: {}, //  参数object,{rand: 0,library_id: 1,type: 1},rand=>随机刷,lib..id=>题库ID,type:1=>每日刷题,2=>知识点
    subjectDetailData: {}, //  显示的题目的详情数据，本地数据{checkArray:[],is_make: Boolean},选择的答案和是否已提交
    subjectIds: [], //  记录的上一题的ID列表
    discussList: [], // 评论列表
    subjectNote: [], //  笔记列表
    showRecordModal: false,
    showDiscussModal: false,
    KeywordExpansion: false, //关键词展开
    mywordExpansion: false, //我的答案展开
    referenceExpansion: false, //参考答案展开
    replyUserInfo: {}, //  要回复的评论的信息
    Repeated_brush: false, //是否本地刷题
    is_display_answer: 2, //是否显示答案
    analysisExpansion: false, //解析展开
	
	// 新增代码开始
	showSchoolUseStateModal: false,// 是否展示学校解锁弹窗
	isjh:0 ,// 是否需要激码 0 不需要 1需要
	jh_price:0,//激活金额
	inputTextaa: '' ,//激活码
	zid:'',//章节id
 subject_ask_ids:''
 
	
	
	
	// 新增代码结束
	
  },
// 在复制文本之前去除 HTML 标签
 stripHtml(html) {
  return html.replace(/<[^>]+>/g, '');
},
  //复制文本
  copyText: function(e) {
    console.log(e) 
  var that =this
    wx.setClipboardData({
      data: that.stripHtml(e.target.dataset.val),
      success: function () {
        wx.showToast({
          title: '复制成功',
          icon: 'none',
          duration: 2000
        });
      }
    });
  },
  onLoad: function (options) {

    this.Brush_time = 0
    this.timmmmm = setInterval(() => {
      this.Brush_time++
    }, 1000);
    this.setData({
      params: options,
      isDark :wx.$cache.get('userinfo').is_dark == 1?true:false,
      is_display_answer: wx.$cache.get('userinfo').is_display_answer,
      referenceExpansion:wx.$cache.get('userinfo').is_display_answer==1
    })
	
    if (options.collect == 1) {


      this.getSubjectDetail(options.subject_id)

    } else if (options.collect == 2) {
  
      this.setData({
        Repeated_brush: true,
        subjectMakeCardList: wx.$cache.get('subjectMakeCardList')
      })
	  
	  
      this.getSubjectDetail(options.subject_id)
    } else {
		
		    
      this.getSubjectMakeCard().then(() => {
        // this.getSubjectList()
        // 顺序刷题根据答题卡的ID获取详情，随机每次根据接口查询一条
		// 随机刷题
        if (this.data.params.rand == 1) {
          this.randomSubjectData()
		  
        } else {
		// 顺序刷题
          let firstNoMakrId = this.data.subjectMakeCardList.find(value => value.make_state == 3)?.id;
		// 222222
		// console.log(222222)
		// console.log(this.data.subjectMakeCardList)
		// console.log(firstNoMakrId)
		// console.log(44444)





          if (!firstNoMakrId) firstNoMakrId = this.data.subjectMakeCardList[this.data.subjectMakeCardList.length - 1]?.id
          this.getSubjectDetail(firstNoMakrId)
        }
      })
	  
	  // console.log(3555)
	  // console.log(this.data.subjectMakeCardList)
	  // console.log(666)
	   
	  // return
    }

  },
  togw(){
    // wx.navigateToMiniProgram({
    //   appId: 'wxbf766cfc7cca4af7',
    // })
  },
  zheng() { //正确音频
    var innerAudioContext = wx.createInnerAudioContext();
    audioPlay()

    function audioPlay() {
      innerAudioContext.src = wx.$domain + '/img/mp3/zq.mp3';
      innerAudioContext.play();
      console.log('1')
    }
  },
  cuowu() { //错误音频
    console.log('cuo')
    var innerAudioContext = wx.createInnerAudioContext();
    audioPlay2()

    function audioPlay2() {
      innerAudioContext.src = wx.$domain + '/img/mp3/cw.mp3';;
      innerAudioContext.play();
      console.log('2')
    }
  },
  //增加刷题数量
  add_subject_num(type) {
    wx.$http.post(wx.$api.add_subject_num, {
      type: type,
      num: type == 1 ? 1 : this.Brush_time,
    }).then(res => {

    })
  },
  tobiji() { //去我的笔记
    wx.navigateTo({
      url: '/pageQ/pages/note/note',
    })
  },
  del_my_library() { //移除题目
    var that = this
    wx.showModal({
      title: '移除题目？',
      content: '移除后将不会再刷到此题',
      cancelColor: '#406BFE',
      confirmColor: '#406BFE',
      confirmText: '移除',
      complete: (res) => {
        if (res.cancel) {

        }

        if (res.confirm) { //确认移除该题
          wx.$http.post(wx.$api.member_move_subject, {
            subject_id: that.data.subjectDetailData.id
          }).then(res => {
            this.nextSubject()
          })
        }
      }
    })


  },
  skip() { //主观题的不会跳过
    //加入错题本，另外再下一小问
    this.changeWrongTopic();
    if (this.data.askindex < this.data.subjectDetailData.subject_ask_list.length - 1) {
      this.setData({
        askindex: this.data.askindex + 1

      })

    } else {
      this.nextSubject();
    }
  },
  wordExpansion(ee) { //是否展开关键字
    this.setData({
      KeywordExpansion: !this.data.KeywordExpansion
    })
  },
  analExpansion(ee) { //是否展开解析
    this.setData({
      analysisExpansion: !this.data.analysisExpansion
    })
  },
  tomorecomment(e) { //查看更多评论或者笔记
    wx.navigateTo({
      url: '/pageQ/pages/note_list/note_list?type=' + e.currentTarget.id + '&subject_id=' + this.data.subjectDetailData.id,
    })
  },
  myExpansion(e) { //是否展开我的答案
    this.setData({
      mywordExpansion: !this.data.mywordExpansion
    })
  },
  rfExpansion(e) { //是否展开参考的答案
    this.setData({
      referenceExpansion: !this.data.referenceExpansion
    })
  },
  previewImg(e) { //预览图片
    wx.previewImage({
      urls: [e.currentTarget.dataset.url],

    })
  },
  tourl: function (e) { //查看相关知识点
    let id = e.currentTarget.id;

    app.content = this.data.subjectDetailData.knowledge_subject_relation[id].fwb_content
    wx.navigateTo({
      url: '/pages/webview/webview?type=2&title=' + this.data.subjectDetailData.knowledge_subject_relation[id].name,
    })

  },
  //大题做题
  subject_do(e) { //做大题
  
  
 
    const params = e.detail
    if (params.note_type == 1 && params.note_content == "") return wx.showToast({
      title: '内容不能为空',
      icon: 'none'
    })
    if (params.note_type == 2 && params.note_imgs.length == 0) return wx.showToast({
      title: '图片不能为空',
      icon: 'none'
    })
    if (params.note_type == 3 && params.note_audio == "") return wx.showToast({
      title: '录音不能为空',
      icon: 'none'
    })
    console.log(params)
	
    params.subject_ask_id = this.data.subjectDetailData.subject_ask_list[this.data.askindex].id

    params.answer_type = params.note_type;
    if (params.note_type == 1) params.answer_content = params.note_content;
    if (params.note_type == 3) params.answer_content = params.note_audio, params.answer_audio_s = params.note_audio_time;
    if (params.note_type == 2) params.answer_content = params.note_imgs.map(value => value.url).join(',')
    //判断是否本地做题
    if (this.data.Repeated_brush) { //是本地做题
      let subjectMakeCardList = JSON.parse(JSON.stringify(this.data.subjectMakeCardList))

	  
	  
       subjectMakeCardList.forEach(value => { //将答题卡状态改变
        if (value.id == this.data.subjectDetailData.id) {
            //判断是否都做过了
            var make_state = 1
            this.data.subjectDetailData.subject_ask_list[this.data.askindex].subject_ask_make_log={
              subject_make_id: params.subject_ask_id,
              answer_audio_s: params.answer_audio_s || 0,
              answer_content: params.note_type == 2 ? params.note_imgs.map(value => value.src) : params.answer_content,
              answer_type: params.note_type,
            }
            this.data.subjectDetailData.subject_ask_list.forEach(item => {  
              if (!item.subject_ask_make_log) {
                console.log('有空')
                make_state = 3;
              }
            })
          value.make_is_ask_ok=make_state==1?1:2;
            value.make_state = make_state;
            //将答题记录保存到答题卡
         
            //存到答题卡中
            value.subjectDetailData = this.data.subjectDetailData
          
          console.log(value)
        }
        
     
      })
      this.add_subject_num(1)

      this.selectComponent('#subjective_item').empty()
      console.log(subjectMakeCardList)
      
      this.setData({
        subjectMakeCardList: subjectMakeCardList,
        [`subjectDetailData.subject_ask_list[${this.data.askindex}].subject_ask_make_log`]:{
          subject_make_id: params.subject_ask_id,
          answer_audio_s: params.answer_audio_s || 0,
          answer_content: params.note_type == 2 ? params.note_imgs.map(value => value.src) : params.answer_content,
          answer_type: params.note_type,
        }
      })
      wx.hideLoading()
    
    } else { //正常做题

      wx.$http.post(wx.$api.subject_do_2, params).then(res => {
        wx.showToast({
          title: '回答成功'
        })
        this.add_subject_num(1)
        let subjectMakeCardList = JSON.parse(JSON.stringify(this.data.subjectMakeCardList))
        this.selectComponent('#subjective_item').empty()
        
        
        this.getSubjectDetail(this.data.subjectDetailData.id)
      })
    }
  },
  openRecordModal() {
    this.setData({
      showRecordModal: true
    })
  },
  openDiscussModal() {
    this.setData({
      showDiscussModal: true
    })
  },
  closeModal() {
    this.setData({
      showRecordModal: false,
      showDiscussModal: false,
      replyUserInfo: {}
    })
  },
  
  //答题卡赋值 9999
  getSubjectMakeCard() {
    return new Promise((resolve, _reject) => {
      wx.$http.post(wx.$api.subject_make_card, this.data.params).then(res => {
        this.setData({
          subjectMakeCardList: res
        }, () => resolve())
      })
    })
  },
  Toggle_question(e) { //切换小问
 
    this.setData({
      askindex: e.currentTarget.id,   
    })
  },
  
  
  
  getSubjectList() {
    wx.$http.post(wx.$api.subject_list, {
      is_all: 1,
      library_id: this.data.libraryId
    }).then(res => {
      this.setData({
        subjectList: res,
        selectSubjectIndex: 0
      })
    })
  },
  openMarkCardBox() {
    this.setData({
      showSheet: true
    })
  },
  lastSubject() {
    // 获取当前ID，
    let nowID = this.data.subjectDetailData.id
    const nowIndex = this.data.subjectIds.findIndex(value => value == nowID)
    if (nowIndex == -1 || nowIndex == 0) {
      wx.showToast({
        title: '没有上一题了',
        icon: 'none'
      })
    } else {

      this.getSubjectDetail(this.data.subjectIds[nowIndex - 1])
    }
  },
  nextSubject() {
	  
	 
	  
	  
    let nowID = this.data.subjectDetailData.id
    const nowIndex = this.data.subjectIds.findIndex(value => value == nowID)
    let nextId = this.data.subjectIds[nowIndex + 1]
    if (nextId) {
      this.getSubjectDetail(nextId)
    } else {
      if (this.data.params.rand == 1) {
        this.randomSubjectData()
      } else {
        const nowMakeIndex = this.data.subjectMakeCardList.findIndex(value => value.id == nowID)
        if (nowMakeIndex == this.data.subjectMakeCardList.length - 1) return wx.showToast({
          title: '已经是最后一题了',
          icon: 'none'
        })
        this.getSubjectDetail(this.data.subjectMakeCardList[nowMakeIndex + 1]?.id)
      }
    }
 
 
 //小问的时候 点击下一题目 直接第一题
	this.setData({
	  askindex: 0,   
	})
	
	
	  // 如果是知识点  111 222
	  
	  
	  if(this.data.params.type == 2){
	  	
	  this.data.subject_ask_ids = this.data.subjectDetailData.subject_ask_list[this.data.askindex].id
		var pamdata = {
		     subject_ask_id :this.data.subject_ask_ids,
		};
	// 那么就调用一下做题
	  	wx.$http.post(wx.$api.subject_do_3,  pamdata).then(res => {
	  	  // wx.showToast({
	  	  //   title: '成功'
	  	  // })
	  	})
	  }
	 
	
	
  },
  getNowAnswer(e) { //点击答题卡
    // console.log(e.detail);

    this.getSubjectDetail(e.detail.id)


  },
  //切换显示模式
  switchShowMode() {
    // console.log(wx.setPro)
    // document.body.style.setProperty('--bg', '#7F583F');
    this.setData({
      isDark: !this.data.isDark
    })
  },
  onShow() {
    console.log('刷新')

    if (this.data.subjectDetailData.id) {
      this.getSubjectDetail(this.data.subjectDetailData.id)
    }

  },
  changeCollectType() {
    if (this.data.subjectDetailData.is_collection == 1) {
      wx.$http.post(wx.$api.add_collection_log, {
        collection_type: 1,
        log_id: this.data.subjectDetailData.id
      }).then(res => {
        wx.showToast({
          icon: 'none',
          title: '取消成功'
        })
        this.setData({
          'subjectDetailData.is_collection': this.data.subjectDetailData.is_collection == 1 ? 2 : 1
        })
      })
    } else {
      wx.showActionSheet({
        itemList: ['重难点', '易错点', '其他'],
        success: (e) => {
          wx.$http.post(wx.$api.add_collection_log, {
            collection_type: 1,
            log_id: this.data.subjectDetailData.id,
            type: (e.tapIndex + 1)
          }).then(e => {
            wx.showToast({
              icon: 'none',
              title: '收藏成功'
            })
            this.setData({
              'subjectDetailData.is_collection': this.data.subjectDetailData.is_collection == 1 ? 2 : 1
            })
          })
        }
      })
    }
  },
  //我要报错
  towybc() {
    wx.$wybc = { //记录缓存
      subject_audio_s: this.data.subjectDetailData.subject_audio_s,
      type: this.data.subjectDetailData.type, //题类型
      stem_type: this.data.subjectDetailData.stem_type, //题目类型
      subject_content: this.data.subjectDetailData.subject_content, //题目内容
      subject_id: this.data.subjectDetailData.id
    }
    console.log(wx.$wybc)
    wx.navigateTo({
      url: '/PackageA/pages/wybc/wybc',
    })
  },
  
  
  // 新增代码开始
 
  // 点击旁白  取消激活
  cloStateModal() {
	  // 获取当前ID，
	  let nowID = this.data.subjectDetailData.id
	  const nowIndex = this.data.subjectIds.findIndex(value => value == nowID)
	  if (nowIndex == -1 || nowIndex == 0) {
		wx.navigateTo({
		  url: '/PackageA/pages/stzy/stzy',
		})
	  } else {
	    this.getSubjectDetail(this.data.subjectIds[nowIndex - 1])
	  }
  },
  
  //使用激活码 去激活
 useSchoolStateChange() {
	 // console.log(this.data.zid)
	 // return
   wx.$http.post(wx.$api.use_activation_code,{
	   code: this.data.inputTextaa,
	   zid: this.data.zid,
	   }).then(res => {
	   
	this.setData({showSchoolUseStateModal: false, inputTextaa: ''})
	  
     wx.showToast({title: '操作成功'})

	 // location.reload()
 
   })
 },
  towebview(){
    app.content = wx.$cache.get('can').verification_url
    wx.navigateTo({
        url: '/pages/webview/webview?type=1&title=如何领取激活码',
    })
  },
 
  
  // 新增代码结束
  payOrder(){
 var that =this
    wx.$http.post(wx.$api.chapter_order_pay, {
      zid: this.data.zid
    }).then(res => {
     console.log(res)
     wx.requestPayment({
      timeStamp: res.timeStamp,  //后端返回的时间戳
      nonceStr:  res.nonceStr,   //后端返回的随机字符串
      package: res.package, //后端返回的prepay_id
      signType:res.signType, //后端签名算法,根据后端来,后端MD5这里即为MD5
      paySign:  res.paySign,  //后端返回的签名
      success (res) {
        console.log('用户支付扣款成功', res)
        that.setData({showSchoolUseStateModal: false, inputTextaa: ''})
	  
        wx.showToast({title: '操作成功'})
      },
      fail (res) { 
        console.log('用户支付扣款失败', res)
      }
     })
    })
  },
  getSubjectDetail(id) {
    
    if (!id) return wx.showToast({
      title: '无题目',
      icon: 'none'
    })
    // wx.showLoading({
    //   title: '请稍等...'
    // })
    var caridx = this.data.subjectMakeCardList.findIndex(value => value.id == id) //找到索引
    //如果是本地做题
    if (this.data.Repeated_brush && this.data.subjectMakeCardList[caridx].subjectDetailData) { //是本地做题状态，且有题目详情
      //判断本地有没有答题记录

      this.setData({
        subjectDetailData: this.data.subjectMakeCardList[caridx].subjectDetailData,
        showSheet: false,
        selectSubjectIndex: caridx
      }, () => {
        this.getDiscussList(id)
        this.getSubjectNote(id)
        this.joinIds(id)
      })
      wx.hideLoading()
    } else {
      wx.$http.post(wx.$api.subject_info, {
        member_id: wx.$cache.get('userinfo')?.id,
        subject_id: id
      }).then(res => {
		  
 
		  // 新增代码 写入需要激活
		this.data.zid =  res.chapter_id;
    this.isjh = res.isjh
    this.jh_price = res.jh_price
		  // return
		  if(  this.isjh == 1){  //1需要激活 0不需要激活
            this.setData({showSchoolUseStateModal: true, inputTextaa: ''})
            this.setData({jh_price: res.jh_price})
		  }
		   // 结束
		  
		  
        wx.hideLoading()
        if (this.data.Repeated_brush) { //错题集与收藏夹过来的，删除做题记录重新刷题
          if (res.type != 3) { //假如不是主观题
            res.is_make = 2;
            res.subject_make_log = null;
          } else {
            res.is_make = 2;
            res.is_ask_ok = 2;
            res.subject_ask_list.forEach(item => {
              item.subject_ask_make_log = null
            })
          }

        }
        res.correct_rate=res.correct_rate?res.correct_rate.toFixed(2):0;
        if(res.type==3&&res.subject_make_log?.is_ask_ok==1){
          //该大题被做过了，改答题卡
          this.data.subjectMakeCardList =  this.data.subjectMakeCardList.map(value => { //将答题卡状态改变
          if (value.id == this.data.subjectDetailData.id) {
           
              value.make_state = 1;
              value.make_is_ask_ok=1;
             
              //存到答题卡中
          }
          return value
        })
        }


	// console.log(res)
	// return



        this.setData({
          subjectDetailData: res,
	 
          subjectMakeCardList:this.data.subjectMakeCardList,
          showSheet: false,
          selectSubjectIndex: caridx
        }, () => {
          this.getDiscussList(id)
          this.getSubjectNote(id)
          this.joinIds(id)
        })
		
				return;
				
      })
    }
  },
  //加入错题本
  changeWrongTopic(state=true) {
    wx.$http.post(wx.$api.add_wrong_topic, {
      subject_id: this.data.subjectDetailData.id
    }).then(e => {
      this.getSubjectDetail(this.data.subjectDetailData.id)
      if(state){
      wx.showToast({
        title: '操作成功',
      })
    }
    })
  },
  //移除错题本 
  cancelCollectHandle() {
    const _this = this;
    wx.showModal({
      title: '是否删除？',
      content: "删除将不在错题夹展示",
      success(e) {
        if (e.confirm) {
          wx.$http.post(wx.$api.del_wrong_topic, {
            subject_id: _this.data.subjectDetailData.id
          }).then(() => {
            wx.showToast({
              title: '已从错题本成功移除',
              icon: 'none'
            })
            _this.getSubjectDetail(_this.data.subjectDetailData.id)
          })
        }
      }
    })

  },
  joinIds(id) { //历史记录
    const isFill = this.data.subjectIds.findIndex(value => value == id)
    let subjectIds = JSON.parse(JSON.stringify(this.data.subjectIds))
    if (isFill == -1) {
      subjectIds.push(id)
      this.setData({
        subjectIds: subjectIds
      })
    }
  },
  getDiscussList(id) {
    wx.$http.post(wx.$api.subject_comment_3, {
      subject_id: id,
      member_id: wx.$cache.get('userinfo')?.id
    }).then(res => {
      this.setData({
        discussList: res
      })
    })
  },
  getSubjectNote(id) {
    wx.$http.post(wx.$api.subject_note_3, {
      subject_id: id,
      member_id: wx.$cache.get('userinfo')?.id
    }).then(res => {
       console.log(res)
      this.setData({
        subjectNote: res
      })
    })
  },
  checkSelectAnswer(e) {
    console.log(e)
    //如果做过了，忽略
    if (this.data.subjectDetailData.is_make == 1) return false
    // 判断单选还是多选，进行替换或push
    let checkArray = (this.data.subjectDetailData?.checkArray || [])
 
    if (this.data.subjectDetailData.type == 1) { //判断是单选
      checkArray = [e.currentTarget.dataset.item]
    } else { //判断是多选
      
      if (checkArray.filter(value => value.option_content == e.currentTarget.dataset.item.option_content).length > 0) {
        console.log('多选如果有')
        checkArray = checkArray.filter(value => value.option_content != e.currentTarget.dataset.item.option_content)
      } else {
        console.log('多选如果没有')
        checkArray.push(e.currentTarget.dataset.item)
      }
    }
    console.log(checkArray)
    this.setData({
      'subjectDetailData.checkArray': checkArray
    })
  },
  submitAnswerHandle() {
	  
	  // console.log(1111111)
    // 判断单选还是多选，进行替换或push
    console.log(JSON.stringify(this.data.subjectDetailData.checkArray));
    console.log("触发答题完成事件");
    let reqParams = {
      subject_id: this.data.subjectDetailData.id,
      option_json: JSON.stringify(this.data.subjectDetailData.checkArray),
    }
    const {
      option_json,
      checkArray
    } = this.data.subjectDetailData
    if (this.data.subjectDetailData.type == 1) {
      if (checkArray[0].is_correct == 1) reqParams.state = 1
      else reqParams.state = 2
    } else if (this.data.subjectDetailData.type == 2) {
      if (checkArray.filter(value => value.is_correct == 2).length > 0) reqParams.state = 2
      else if (checkArray.length != option_json.filter(value => value.is_correct == 1).length) reqParams.state = 2
      else reqParams.state = 1
    }
    wx.showLoading({
      title: '请稍等',
      mask: true
    })
    if (this.data.Repeated_brush) { //本地错题本/收藏夹刷题
      let subjectMakeCardList = JSON.parse(JSON.stringify(this.data.subjectMakeCardList))
      subjectMakeCardList = subjectMakeCardList.map(value => { //将答题卡状态改变
        if (value.id == reqParams.subject_id) {
          value.make_state = reqParams.state;
          //将答题记录保存到答题卡
          this.setData({
            'subjectDetailData.is_make': 1,
            'subjectDetailData.subject_make_log': {
              "id": 1,
              "member_id": 1,
              "subject_id": 1,
              "option_type": 1,
              "option_json": JSON.parse(reqParams.option_json),
              "state": reqParams.state,
              "is_ask_ok": 2,
              "add_time": ""
            }
          }, () => {
            value.subjectDetailData = this.data.subjectDetailData
            console.log('执行')
          })
          //存到答题卡中

        }
        return value
      })
      if (wx.$cache.get('userinfo').is_music == 1) {
        if (reqParams.state == 1) {
          this.zheng();
        } else {
          this.cuowu()
        }
      }
      this.add_subject_num(1)
      this.setData({
        subjectMakeCardList: subjectMakeCardList
      })
      wx.hideLoading()
    } else { //正常刷题
      wx.$http.post(wx.$api.subject_do_1, reqParams).then(res => {
        this.add_subject_num(1)
        wx.hideLoading()
        if(reqParams.state == 2&&this.data.subjectDetailData.is_wrong==2){//如果做错了，又没有加入错题本，主动加入错题本
            console.log('做错了，而且错题本中没有')
this.changeWrongTopic(false);
        }
        if (wx.$cache.get('userinfo').is_music == 1) {
          if (reqParams.state == 1) {
            this.zheng();
          } else {
            this.cuowu()
          }
        }
        if (wx.$cache.get('userinfo').is_automatic == 1) {
          if (reqParams.state == 1) {
            console.log('答对了下一题')
            setTimeout(() => {
              this.nextSubject();
            }, 1000);

          }
        }
        let subjectMakeCardList = JSON.parse(JSON.stringify(this.data.subjectMakeCardList))
        subjectMakeCardList = subjectMakeCardList.map(value => {
          value.id == reqParams.subject_id ? value.make_state = reqParams.state : value.make_state = value.make_state
          return value
        })
        this.setData({
          subjectMakeCardList: subjectMakeCardList
        }, () => {
          this.getSubjectDetail(reqParams.subject_id)

        })
      })
    }
  },
  submitNoteData(e) { //提交笔记
    const params = e.detail
    if (params.note_type == 1 && params.note_content == "") return wx.showToast({
      title: '笔记不能为空',
      icon: 'none'
    })
    if (params.note_type == 2 && params.note_imgs.length == 0) return wx.showToast({
      title: '图片不能为空',
      icon: 'none'
    })
    if (params.note_type == 3 && params.note_audio == "") return wx.showToast({
      title: '录音不能为空',
      icon: 'none'
    })
    params.subject_id = this.data.subjectDetailData.id
    if (params.note_type == 2) params.note_imgs = params.note_imgs.map(value => value.url).join(',')
    wx.$http.post(wx.$api.add_note, params).then(res => {
      wx.showToast({
        title: '操作成功'
      })
      this.closeModal()
      this.getSubjectNote(params.subject_id)
    })
  },
  submitDiscussData(e) { //提交评论
 
    let params = {
      subject_id: this.data.subjectDetailData.id,
      p_id: this.data.replyUserInfo?.id ? this.data.replyUserInfo?.id : 0,
      content: e.detail.note_content
    }
    wx.$http.post(wx.$api.add_subject_comment, params).then(res => {
      console.log("评论成功");
      wx.showToast({
        title: '评论成功'
      })
      this.getDiscussList(params.subject_id)
      this.setData({
        showDiscussModal: false
      })
    })
  },
  replyContent(e) {
    // this.setData({replyUserInfo: e.detail},() => this.openDiscussModal())
  },
  refresh() { //刷新评论点赞
    this.getSubjectDetail(this.data.subjectDetailData.id)
  },
  randomSubjectData() {
    wx.$http.post(wx.$api.subject_rand, {
      page: 1,
      page_size: 1,
      library_id: this.data.params.library_id,
      major_id: wx.$cache.get('majorInfo').id
    }).then(res => {

      if(res[0].id==this.data.subjectDetailData.id){
        wx.showToast({
          icon:'none',
          title: '当前已经是最后一题了',
        })
      }
      this.getSubjectDetail(res[0].id)
    })
  },
  onShareAppMessage(e) {
    if(e.from=='button'){
    return {
      path: '/subPackageZ/pages/brush-topic/brush-topic?rand=0&collect=1&subject_id=' + this.data.subjectDetailData.id+'&pid'+wx.$cache.get('member_id'),
      imageUrl:wx.$cache.get('share').img,
      title: '考考你一道题～'
    }
  }else{
    return{
      title:wx.$cache.get('share').title,
      imageUrl:wx.$cache.get('share').img,
      path:`/pages/index/index?pid=${wx.$cache.get('member_id')||0}`
    }
  }
  },
  onUnload() {
    this.add_subject_num(2)
    clearInterval(this.timmmmm)
  },
  //ai浮窗
  aifuchuang(){
   
     var url= '/pages/webview/webview?url='+ wx.$cache.get('can').maxKb_url +'&type=1' 
  
     wx.navigateTo({
      url: url,
    })
  }
});