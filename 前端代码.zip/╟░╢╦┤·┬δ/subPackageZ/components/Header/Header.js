const app = getApp();
Component({
    options: {
        addGlobalClass: true,//开启使用全局样式
    },
    properties: {
        ban:{
          type:Boolean,
          value:false
        },
        showNull:{
          type:Boolean,
          value:true
        },
        bgi: {//背景图 状态栏+导航
            type: String,
            value: ''
        },
        bgc: {//导航背景颜色（包含状态栏）
            type: String,
            value: '#ffffff'//透明 transparent=》》这样可以显示图片背景
        },
        title: {//标题内容
            type: String,
            value: '标题'
        },
        titleColor:{//标题颜色
            type:String,
            value:'#333'
        },
        showBack:{//是否显示返回按钮
            type:Boolean,
            value:true,
        },
        isBack: {//true 是返回 false 跳到是首页
            type: Boolean,
            value: true,//默认是返回
        },
        backColor: {//返回按钮颜色
            type: String,
            value: '#000000'
        },
        boxPadding: {//导航内边距
            type: Number,
            value: 24,//单位 rpx
        }
    },
    lifetimes: {
        attached() {
            this.setHeader();
        }
    },

    data: {
        systemInfo: wx.getSystemInfoSync(),//全局系统信息
        headerHeight: 0,//导航高度
    },

    methods: {
        //返回按钮
        backPage() {
            console.log(this.data.ban)
            if (this.data.isBack) {
                if (this.data.ban){
                    this.triggerEvent('back');
                }else {
                    wx.navigateBack({
                        delta:1,
                        fail(res) {
                            wx.redirectTo({
                                url: '/pages/index/index'
                            })
                        }
                    });
                }
            }
            else wx.redirectTo({
                url: '/pages/index/index'
            })
        },
        //设置header高度
        setHeader() {
            //高度 = （胶囊top-状态栏height）* 2 + 胶囊的高度
            //获取胶囊信息
            const menuData = wx.getMenuButtonBoundingClientRect();
            //计算header高度
            const headerHeight = (menuData.top - this.data.systemInfo.statusBarHeight) * 2 + menuData.height;
            this.setData({
                headerHeight
            })
        }
    }
});
