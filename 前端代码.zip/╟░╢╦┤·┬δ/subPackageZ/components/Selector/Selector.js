Component({
    properties: {
        value:{//控制显示隐藏
            type:Boolean,
            default:false,
            observer:'showWatch'
        }
    },
    data: {},
    lifetimes:{
      attached() {
          console.log(this.data.value)
      }
    },
    methods: {
        //关闭
        close(){
          this.setData({
              value:false
          })
        },
        //监听
        showWatch(n,o){
            // console.log(n)
        }
    }
});
