Component({
  properties: {
    value: { //控制显示隐藏
      type: Boolean,
      default: false,
    },
    makecardList: {
      type: Array,
      default: [],
      
    }
  },
  observers: {
    'makecardList': function(val,oldval) {
	// console.log(111);
	// console.log(val.length);
 
	// console.log(val.filter(value => value.type == 2))
	// console.log(val.filter(value => value.type == 3))
      // console.log(222);
	  
	  // if(val.length >99){
		 //  console.log(111);
		 //  	console.log(val[130]);
		 //       console.log(222);
	  // }
	  
	  
      this.setData({
        'makeListData.type1': val.filter(value => value.type == 1),
        'makeListData.type2': val.filter(value => value.type == 2),
        'makeListData.type3': val.filter(value => value.type == 3),
      })
    },
   
  },
  data: {
    makeListData: {
      type1: [],
      type2: [],
      type3: [],
    }
  },
  methods: {
    closeModal() {
      this.setData({
        value: false
      })
    },
    viewBtnHandle(e) {
      this.triggerEvent('click',e.currentTarget.dataset.item)
    }
  }
});