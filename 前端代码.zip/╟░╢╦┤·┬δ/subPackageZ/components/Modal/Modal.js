Component({
    properties: {
        value:{
            default:false,
            type:Boolean,
        }
    },
    data: {},
    methods: {

    }
});
