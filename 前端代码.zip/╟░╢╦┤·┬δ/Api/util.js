function getLocation(type, compel, hint, success, fail) { //getLocation(type,有值就是gcj02，默认wgs84, compel，是否强制获取位置, hint强制提示文字,success成功回调,fail失败回调)
    var that = this
    
}

function opention(type, compel, hint, success, fail) { //强制调用授权方法
    var that = this
    wx.showModal({
        title: '获取位置失败',
        content: hint,
        success(res) {
            if (res.confirm) {
                wx.openSetting({
                    success: function (data) {
                        console.log(data, 'datadata')
                        if (data.authSetting["scope.userLocation"] === true) {
                            wx.showToast({
                                title: '授权成功',
                                icon: 'success',
                                duration: 1000
                            })
                            that.getLocation(type, compel, hint, success, fail);
                            //授权成功之后，再调用获取地理位置
                        }
                    }
                })
            } else if (res.cancel) {
                that.opention(type, compel, hint, success, fail); //重复调用
            }
        }
    })
}

//获取位置的详细信息，包括城市，省份，街道等等
function locationDetails(optionLocation) {
    return new Promise((resolve, reject) => {
        var QQMapWX = require('./qqmap/qqmap-wx');
        // 实例化API核心类
        var qqmapsdk = new QQMapWX({
            key: wx.$qqmapKey
        });
        qqmapsdk.reverseGeocoder({
            location: optionLocation || '',
            success: function (res) { //成功后的回调
                resolve(res)
            },
            fail: function (error) {
                reject(error)
            },
        })
    })
}

function getDateDiff(dateTime) {
    if (!dateTime) {
        return dateTime
    }
    let dateTimeStamp = new Date(dateTime.replace(/-/g, "/")).getTime();
    let result = '';
    let minute = 1000 * 60;
    let hour = minute * 60;
    let day = hour * 24;
    let halfamonth = day * 15;
    let month = day * 30;
    let year = day * 365;
    let now = new Date().getTime();
    let diffValue = now - dateTimeStamp;
    if (diffValue < 0) {
        return '刚刚'
    }
    let monthEnd = diffValue / month;
    let weekEnd = diffValue / (7 * day);
    let dayEnd = diffValue / day;
    let hourEnd = diffValue / hour;
    let minEnd = diffValue / minute;
    let yearEnd = diffValue / year;
    if (yearEnd >= 1) {
        result = dateTime;
    } else if (monthEnd >= 1) {
        result = "" + parseInt(monthEnd) + "月前";
    } else if (weekEnd >= 1) {
        result = "" + parseInt(weekEnd) + "周前";
    } else if (dayEnd >= 1) {
        result = "" + parseInt(dayEnd) + "天前";
    } else if (hourEnd >= 1) {
        result = "" + parseInt(hourEnd) + "小时前";
    } else if (minEnd >= 1) {
        result = "" + parseInt(minEnd) + "分钟前";
    } else {
        result = "刚刚";
    }
    return result;
};

function getDateDiff2(dateTime) {//发车时间处理
    if (!dateTime) {
        return dateTime
    }
    let dateTimeStamp = new Date(dateTime.replace(/-/g, "/")).getTime();
    let time = dateTime.split(' ')
    let mytime = new Date(new Date(new Date().getTime()).setHours(0, 0, 0, 0)).getTime();
    if (dateTimeStamp - mytime >= 0 && dateTimeStamp - mytime < 86400000) {
        return '今天' + time[1]
    } else {
        return dateTime
    }
};

/*函数防抖*/
const debounce = (fn, interval) => {
    var timer;
    var gapTime = interval || 1000;//间隔时间，如果interval不传，则默认1000ms
    return function () {
        clearTimeout(timer);
        var context = this;
        var args = arguments;//保存此处的arguments，因为setTimeout是全局的，arguments不是防抖函数需要的。
        timer = setTimeout(function () {
            fn.call(context, args);
        }, gapTime);
    };
}

//获取位置的详细信息，包括城市，省份，街道等等
function getlng(address, success, fail) {
    var that = this
    var QQMapWX = require('./qqmap/qqmap-wx');
    // 实例化API核心类
    var qqmapsdk = new QQMapWX({
        key: wx.$qqmapKey
    });
    qqmapsdk.geocoder({
        address: address || '',
        success: function (res) { //成功后的回调

            success(res.result)
        },
        fail: function (error) {
            console.error(error);
            fail(error)
        },
    })
}

function datetransition(datetime) {
    var date
    if (Object.prototype.toString.call(datetime) == '[object Date]') {
        date = datetime;
    } else if (typeof (datetime) == 'string') {
        date = new Date(datetime.replace(/-/g, "/")); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
    } else {
        date = new Date(datetime)
    }

    var Y = date.getFullYear();
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    var H = date.getHours() < 10 ? '0' + date.getHours() : date.getHours();
    var MI = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes();
    var S = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();
    let obj = {
        day1: Y + "-" + M + "-" + D,
        day2: Y + "年" + M + "月" + D + '日',
        day3: Y + "/" + M + "/" + D,
        time1: H + "时" + MI + "分" + S + "秒",
        time2: H + ":" + MI + ":" + S,
        time3: H + "时" + MI + "分",
        time4: H + ":" + MI,
        daytime1: Y + "-" + M + "-" + D + ' ' + H + ":" + MI + ":" + S,
        daytime2: Y + "年" + M + "月" + D + '日 ' + H + "时" + MI + "分" + S + "秒",
    }
    return obj;
}

module.exports = {
    getLocation: getLocation,
    opention: opention,
    locationDetails: locationDetails,
    $getDateDiff: getDateDiff,
    getDateDiff2: getDateDiff2,
    debounce: debounce,
    getlng: getlng,
    $datetype: datetransition
}
