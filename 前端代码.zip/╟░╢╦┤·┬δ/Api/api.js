// 线上版本
// wx52160a93feda945c
// const baseurl = 'https://jyxq.zyzkj.cn/api/'
// 线下版本
// wxbf766cfc7cca4af7
//请求域名头
const baseurl = 'https://stapi.seniorfd.com'
//腾讯地图KEY
const $qqmapKey = 'IFVBZ-3BD6V-T2OPH-UTMAR-UYNO3-UIF6Z'
//图片域名
const $domain=baseurl+'/uploads'
const $api = {
//pdf相关
get_pdf: 'pdf/get_pdf' ,//获取PDF详情
pdf_pay:"pdf/pay", //下单接口
//视频相关接口
durationAndTimes:"video_z_j/duration_and_times", //存储当前视频播放时长，以及播放完成次数 
click_log:"video_z_j/click_log", //用户点击视频播放记录
video_pay:"video_z_j/pay", //下单接口
get_z_list:"video_z_j/get_z_list", //获取章列表
get_j_list:"video_z_j/get_j_list", //获取节列表
  //支付章节订单相关 
  chapter_order_pay:"chapter_order/pay", //下单接口
    //基础接口start
    getopenid: 'login/login', //获取openid
    login: 'index/login',
    // edit_member: 'member/update_wechat_member', // 更新头像
    edit_member: 'member/edit_member', // 更新头像
    get_banner: 'index/get_banner', //轮播图
    get_member: 'member/get_member',
    get_member_info: 'member/get_member_info', //个人信息
    upload_img: 'base_member/upload_img', // 上传图片
    upload_img_no: 'index/upload_img', // 上传图片
    upload_file: 'base_member/upload_file', // 上传图片
    qrcode: 'index/qrcode', // 生成二位码
    decryption: 'login/decryption', // 解密手机号
    wx_login: 'login/wx_login', // 微信授权登录
    get_show: 'index/get_show', // 获取显示配置
    get_share: 'index/get_share', // 分享图
    //基础接口end
    major_list: 'index/major_list', //  专业列表
    collection_log_list: 'member/collection_log_list',
    school_list: 'index/school_list',   //  
    top_give: 'member/top_give',  //  点赞排行榜
    top_subject_num: 'member/top_subject_num',  //  刷题排行榜
    top_student_num: 'member/top_student_num',  //  学习时间排行榜
    library_list: 'index/library_list' ,//题库列表
    my_library_list: 'member/my_library_list' ,//我的题库列表
    get_library_list: 'member/get_library_list' ,//指定题库列表
    chapter_list: 'index/chapter_list',//章节列表
    subject_list: 'member/subject_list',//题目列表
    subject_make_card: 'member/subject_make_card',  //答题卡列表
    add_collection_log: 'member/add_collection_log',  //  增加收藏
    edit_collection_type: 'member/edit_collection_type',  //  修改收藏
    wrong_topic_log_library: 'member/wrong_topic_log_library',
    use_activation_code: 'member/use_activation_code',
    add_my_library: 'member/add_my_library',
    subject_info: 'index/subject_info',
    subject_do_1: 'member/subject_do_1',
    subject_comment: 'index/subject_comment',
    subject_comment_3: 'index/subject_comment_3',
    subject_note_3: 'index/subject_note_3',
    add_note: 'member/add_note',
    add_subject_comment: 'member/add_subject_comment',
    subject_rand: 'member/subject_rand',
    subject_reset: 'member/subject_reset',
    add_wrong_topic: 'member/add_wrong_topic',
    wrong_topic_log_subject: 'member/wrong_topic_log_subject',
    del_wrong_topic: 'member/del_wrong_topic',//移除错题集
    my_note: 'member/my_note',
    subject_do_2: 'member/subject_do_2',//做题_主观题
	 subject_do_3: 'member/subject_do_3',//做题_知识点
	 
    member_subject_data:'member/member_subject_data',//用户刷题统计_数据
    member_subject_num: 'member/member_subject_num',//用户刷题统计_刷题量
    member_subject_data:'member/member_subject_data',//用户刷题统计_数据
    member_subject_time: 'member/member_subject_time',//用户刷题统计_刷题时间
    member_move_subject:'member/member_move_subject',//题目移除刷题
    add_give_log:'member/add_give_log',//点赞或取消笔记,评论
    subject_comment:'index/subject_comment',//评论列表
    subject_note:'index/subject_note',//笔记列表
    add_report_errors:'member/add_report_errors',//提交报错
    report_errors_log:'member/report_errors_log',//反馈列表
    system_news_list:'member/system_news_list',//系统消息列表
    unread_news_num:'member/unread_news_num',//未读消息数
    system_news_info:'member/system_news_info',//系统消息详情
    report_errors_info:'member/report_errors_info',//反馈消息详情
   my_subject_comment:'member/my_subject_comment',//我的题目评论
   my_give_log:'member/my_give_log',//我的互动消息
   
   del_my_library:'member/del_my_library',//从我的题库移除
   add_subject_num:'member/add_subject_num',//添加刷题统计
   export_my_note:'member/export_my_note',//导出_我的or他人笔记
   del_note:'member/del_note',//删除笔记
   edit_note:'member/edit_note',//修改笔记
  }
  const $get = {
    upload_img: 'base_member/upload_img', // 上传图片
    upload_img_no: 'index/upload_img', // 上传图片
    upload_file: 'base_member/upload_file', // 上传图片
  //  ------------------------------------------------------------
  posts_list:'member/posts_list',  // 研友圈帖子列表
  update_member: 'member/edit_member', // 更新头像
    add_posts:'member/add_posts',   //发帖
    posts_info:'member/posts_info',  // 帖子详情
    posts_comment_list:'member/posts_comment_list',    // 评论列表
    del_posts: 'member/del_posts',   // 删除帖子
    edit_posts: 'member/edit_posts',   // 编辑帖子
    posts_give_member: 'member/posts_give_member',    // 点赞
    posts_give_log: 'member/posts_give_log',   // 点赞记录
    posts_add_comment: 'member/posts_add_comment',   // 发布评论
    posts_member_info: 'member/posts_member_info',   // 查看主页
    posts_comment_my: 'member/posts_comment_my',  // 评论我的
    posts_my_comment: 'member/posts_my_comment',   // 我评论的
    posts_my_follow: 'member/posts_my_follow',   // 用户的关注列表
    posts_follow_member: 'member/posts_follow_member',    // 关注或取关用户
    posts_follow_my: 'member/posts_follow_my',
    posts_word_topic: 'member/posts_word_topic',   // 话题搜素
    posts_del_follow: 'member/posts_del_follow',    // 移除粉丝的关注
    member_unread_num: 'member/member_unread_num',    // 未读消息数量
    empty_unread_num: 'member/empty_unread_num',    // 清空消息

    empty_report: 'member/empty_report',        //  清空举报投诉的状态

    index_banner_2: 'index/get_banner_2'//研友圈的banner
    }   
for (let i in $api) {
    $api[i] = baseurl +'/api/'+ $api[i]
}
for (let i in $get) {
  $get[i] = baseurl +'/api/'+ $get[i]
}     

export {
  $get,
    $api,
    $domain,
    $qqmapKey
}
