var dtime = '_deadtime'; //缓存过期时间
function set(k, v, t) { //存入，put(key,value,time)
  wx.setStorageSync(k, v)
  var seconds = parseInt(t);
  if (seconds > 0) {
    var timestamp = Date.parse(new Date());
    timestamp = timestamp / 1000 + seconds;
    wx.setStorageSync(k + dtime, timestamp + "")
  
  } else {
    wx.removeStorageSync(k + dtime)
  }
}

function get(k, def) { //取出get(key,过期，出错时调用def)
  var deadtime = parseInt(wx.getStorageSync(k + dtime))
  if (deadtime) {
    if (parseInt(deadtime) < Date.parse(new Date()) / 1000) {
      if (def) {
        return def;
      } else {
        return;
      }
    }
  }
  var res = wx.getStorageSync(k);
  if (res) {
    return res;
  } else {
    return def;
  }
}

function remove(k) { //清楚指定缓存key
  wx.removeStorageSync(k);
  wx.removeStorageSync(k + dtime);
}

function clear() { //清楚该账号所有缓存
  wx.clearStorageSync();
}
export default {
 get,
 set,
 remove,
 clear
}