import http from './http'
import {
  $api,
  $qqmapKey,
  $domain,
  $get,
} from './api'
import $cache from './cache'
import {$datetype,$getDateDiff} from './util'
function init() {
  wx.$http = http
  wx.$get = $get
  wx.$api = $api
  wx.$domain= $domain
  wx.$cache = $cache
  wx.$qqmapKey=$qqmapKey
  wx.$datetype=$datetype
  wx.$getDateDiff=$getDateDiff
}
export default init