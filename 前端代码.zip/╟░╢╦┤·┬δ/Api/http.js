function request(url, params, method = 'GET') {
  var that=this
    let header = null
    let timeout = 10000 // 超时
    let tokenName = 'key' // token名
    let p = new Promise((resolve, reject) => {
        // 开启login
        wx.showNavigationBarLoading()
        let token = wx.getStorageSync(tokenName)
        params.key = token
      
        // 请求
        wx.request({
            url: url,
            data: params,
            timeout,
            header: header || {
                'Content-Type': 'application/json'
            },
            method,
            success: (res) => {
                if (res.statusCode == 200) {
                    if (res.data.code == 200) {
                        resolve(res.data.datas)
                    } else {
                        console.log(res.data.datas.error)
                        if (res.data.datas.error == "请登录") {
                            // let pageArr = getCurrentPages();
                            // let thisPage = pageArr[pageArr.length - 1]
                          
      wx.login().then(async res => { wx.$http.post(wx.$api.login, {
                              
                              code: res.code
                            }).then(e => {
                              e.member_id=e.id
                              wx.$cache.set('userinfo', e);
                              wx.$cache.set('member_id', e.id);
                              wx.$cache.set('key', e.token);
                              if(!e.nickname){
                                wx.removeStorageSync(tokenName)
                                wx.navigateTo({
                                  url: '/pages/login/login',
                                })
                              }else{
                                that.request(url, params, method = 'GET')
                              }
                            })})
                           
                            // thisPage.setData({
                            //     login: true,
                            // })
                        } else {
                            wx.showToast({
                                title: res.data.datas.error,
                                icon: 'none'
                            })
                        }
                        wx.hideLoading()
                        reject(res)
                    }
                }

            },
            fail: err => {
                wx.hideLoading()
                reject(err)
            },
            complete: () => {
                wx.hideNavigationBarLoading()
            }

        })
    })
    return p
}

function get(url, params = {}, method = 'GET') {
    return request(url, params , method)
}

function post(url, params = {}, method = 'POST') {
    return request(url, params , method)
}

function http(url, params = {}, method = 'POST') {
  
    return request(url, params, method)
}
http.post = get
http.post = post


export default http