// pages/topic/topic.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    topic:"",
    count:0,
    postData:[],
    loadState:'loadmore',
    page:1,
    limit:15,
    userinfo: wx.$cache.get('userinfo'),
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({topic:options.text})
    this.getTopic()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.loadState != 'nomore') {
      this.setData({
        page: this.data.page + 1,
        loadState: 'loading'
      })
      this.getTopic();
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  getTopic(){
    wx.$http(wx.$get.posts_list, {page: this.data.page,page_size: this.data.limit,sort_type: 1,topic: this.data.topic}).then(res => {
      if (this.data.page == 1) {
        this.setData({ 
          postData: res.list,
          loadState: res.list.length < this.data.limit ? 'nomore' : 'loadmore',
          count: res.count
        })
      } else {
        this.setData({
          postData: [...this.data.postData, ...res.list],
          loadState: res.list.length < this.data.limit ? 'nomore' : 'loadmore',
          count: res.count
        })
      }
      wx.hideLoading()
    }).catch(res=>{
      console.log(res)
    })
  },
  goDetail(e) {
    const id = e.currentTarget.dataset.id
    const _this = this;
    wx.navigateTo({
      url: '/friend/post_detail/post_detail?id='+id,
      events: {
        editSuccess:function(result){
          let res = {detail:result};
          _this.editPostItem(res)
        }
      },
    })
  },
  showMoreModal(res){
    this.setData({showModal: true,selectPostData: res.detail})
  },
  editPostItem(res) {
    console.log(res)
    const data = res.detail
    this.setData({
      postData: this.data.postData.map((value)=>{
        if(value.id == data.id){
          return data
        }else{
          return value
        }
      }),
      showModal: false
    })
  },
  removePostItem(res) {
    const id = res.detail.id;
    this.setData({
      postData: this.data.postData.filter(value => value.id != id),
      showModal: false
    })
  },
  goReport(){
    const _this = this;
    wx.navigateTo({
      url: '/friend/report/report',
      events: {
        editSuccess:function(res){
          _this.triggerEvent('edit',res,{})
        }
      },
      success(res){
        res.eventChannel.emit('editInfo', {topic: _this.data.topic})
      }
    })
  }
})