// pages/follow/follow.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    followData: [],
    loadState: 'loadmore',
    page:1,
    limit: 15,
    type:"",
    my_uid: wx.$cache.get('member_id'),
    member_id:''
  },
  onLoad: function (options) {
    this.setData({member_id: options.member_id,type:options.type=='fans'?'fans':'follow',my_uid:wx.$cache.get('member_id')})
    if(this.data.type == 'follow'){
      this.loadFollowData()
    }else{
      wx.setNavigationBarTitle({title: '粉丝列表'})
      this.loadFansData()
    }

  },
  getBanner(){//录播图
    let {region} = this.data
    let params = {
      address_1_name:region.length==0?wx.$cache.get('province'):region[0]=='全部'?'':region[0],
      address_2_name:region.length==0?wx.$cache.get('city'):region[1]=='全部'?'':region[1],
      address_3_name:region.length==0?wx.$cache.get('area'):region[2]=='全部'?'':region[2],
    }
    wx.$http.post(wx.$get.get_banner,params).then(res=>{
      this.setData({
        lun:res
      })
      console.log(res,'轮播他')
    })
  },
  

  onReachBottom: function () {
    if(this.data.loadState != 'nomore'){
      this.setData({loadState: 'loading',page: this.data.page+1})
      if(this.data.type == 'follow'){
        this.loadFollowData()
      }else{
        this.loadFansData()
      }
    }
  },

  
  loadFollowData(){
    wx.$http.post(wx.$get.posts_my_follow,{page:this.data.page,page_size:this.data.limit,is_all:2,member_id: this.data.member_id}).then(res=>{
      this.setData({followData: [...this.data.followData,...res],loadState: res.length < this.data.limit ? 'nomore' : 'loadmore'})
    })
  },
  loadFansData(){
    wx.$http.post(wx.$get.posts_follow_my,{page:this.data.page,page_size:this.data.limit,is_all:2,member_id: this.data.member_id}).then(res=>{
      this.setData({followData: [...this.data.followData,...res],loadState: res.length < this.data.limit ? 'nomore' : 'loadmore'})
    })
  },
  followAction(e){
    let data = e.currentTarget.dataset.item;
    data.is_follow = data.is_follow == 2 ? 1 : 2;

    console.log(data)
    this.setData({
      followData: this.data.followData.map(value=>{
        if(value.id == data.id){
          console.log(data)
          return data
        }else{
          console.log("元数据",value)
          return value
        }
      })
    })
  },
  removeFans(e){
    const data = e.currentTarget.dataset.item;
    const _this = this;
    wx.showModal({
      content: "确认移除该粉丝？",
      success(res){
        if(res.confirm){
          wx.$http.post(wx.$get.posts_del_follow,{others_member_id:data.member_id}).then(res=>{
            _this.setData({followData:_this.data.followData.filter(value => value.id != data.id)})
          })
        }
      }
    })
  },
  goUserHome(e){
    wx.navigateTo({
      url: '/friend/user/user?uid='+e.currentTarget.dataset.uid,
    })
  }
})