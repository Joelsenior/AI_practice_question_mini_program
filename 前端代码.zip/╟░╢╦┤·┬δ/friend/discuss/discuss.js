// pages/discuss/discuss.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    searchText: "",
    tabBarIndex: 0,
    discussData: [],
    page: 1,
    limit: 15,
    loadState: 'loadmore'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.loadDiscussMe();
    this.readDiscuss()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  readDiscuss(){
    wx.$http.post(wx.$get.empty_unread_num).then(res=>{})
  },
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.setData({loadState: 'loading',page: this.data.page+1})
    if(this.data.tabBarIndex == 0){
      this.loadDiscussMe()
    }else if(this.data.tabBarIndex == 1){
      this.loadMyDiscuss()
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  changeTabIndex(e){
    this.setData({tabBarIndex: e.currentTarget.dataset.index,discussData:[],page:1})
    if(this.data.tabBarIndex == 0){
      this.loadDiscussMe()
    }else if(this.data.tabBarIndex == 1){
      this.loadMyDiscuss()
    }
  },
  loadDiscussMe(){
    wx.$http.post(wx.$get.posts_comment_my,{page:this.data.page,page_size:this.data.limit,is_all:2}).then(res=>{
      this.setData({discussData: [...this.data.discussData,...res],loadState: res.length < this.data.limit ? 'nomore' : 'loadmore'})
    })
  },
  loadMyDiscuss(){
    wx.$http.post(wx.$get.posts_my_comment,{page:this.data.page,page_size:this.data.limit,is_all:2}).then(res=>{
      this.setData({discussData: [...this.data.discussData,...res],loadState: res.length < this.data.limit ? 'nomore' : 'loadmore'})
    })
  },
  goDetail(e){
    wx.navigateTo({
      url: '/friend/post_detail/post_detail?id='+e.currentTarget.dataset.id,
    })
  }
})