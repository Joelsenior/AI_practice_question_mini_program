// pages/report/report.js
Page({

  data: {
    ImageGroup: [],
    topic: "",
    content: "",
    showImageGroup: [],
    id: undefined,
    data: {}
  },

  onLoad: function (options) {
    const _this = this;
    const eventChannel = this.getOpenerEventChannel();
    eventChannel.on('editInfo', function(data) {
      if(data.id) {
        _this.setData({
          topic: data.topic,
          content: data.content,
          showImageGroup: data.imgs,
          ImageGroup: data.imgs,
          id: data.id,
          data: data,
          is_edit: true
        })
        wx.setNavigationBarTitle({title: '修改帖子'})
      }else{
        _this.setData({
          topic: data.topic,
          content: data.content,
          showImageGroup: data.imgs,
          ImageGroup: data.imgs,
          data: data,
        })
      }
    })
  },

  onReady: function () {

  },

  onShow: function () {

  },

  onHide: function () {

  },

  onUnload: function () {

  },

  onPullDownRefresh: function () {

  },

  onReachBottom: function () {

  },

  onShareAppMessage: function () {

  },
  uploadImage()  {
    const _this = this;
    wx.chooseImage({
      count: 9-_this.data.ImageGroup.length,
      success:async (res)=>{
        for (let index = 0; index < res.tempFilePaths.length; index++) {
          const element = res.tempFilePaths[index];
          wx.showLoading({title: `正在上传第${index+1}张`})
          let imgInfo = await this.upload(element)
          _this.setData({
            ImageGroup: [..._this.data.ImageGroup, imgInfo.url],
            showImageGroup: [..._this.data.showImageGroup, imgInfo.src]
          })
          wx.hideLoading()
        }
      }
    })
  },
  async upload(filePath){
    return new Promise((resolve,reject)=>{
      wx.uploadFile({
        filePath: filePath,
        name: 'file',
        // url:'https://diyxc.yishuyin.com/api/index/upload_file',
        url: wx.$get.upload_file,
        formData: {key: wx.$cache.get('key'),file_type: 4},
        success(uploadRes) {
          const data = JSON.parse(uploadRes.data)
          if(data.code==200){
            resolve(data.datas)
          }else{
            reject()
          }
          // _this.setData({
          //   ImageGroup: [..._this.data.ImageGroup, data.datas.file_url],
          //   showImageGroup: [..._this.data.showImageGroup, data.datas.url]
          // })
        },
        fail(e){
          reject()
        }
      })
    })
  },
  removeImage(e) {
    const dataIndex = e.currentTarget.dataset.index;
    const _this = this;
    wx.showModal({
      content: "确认删除？",
      success(res) {
        if (res.confirm) {
          _this.setData({
            ImageGroup: _this.data.ImageGroup.filter((res, index) => index !== dataIndex),
            showImageGroup: _this.data.showImageGroup.filter((res, index) => index !== dataIndex)
          })
        }
      }
    })
  },
  addPost() {
    this.data.topic = this.data.topic.replace(/^\s*|\s*$/g,"");
function RegExpString(str) 
{ 
    var p = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]") 
     if(p.test(str)){
        return true}
    else{
        return false
    }
  }
    if(RegExpString(this.data.topic)){
      wx.showToast({
        icon: "none",
        title: '话题不能有特殊字符',
      })
      return
      }
    if (this.data.ImageGroup.length == 0 &&  this.data.content == "") {
      return wx.showToast({
        title: '请勿发布空内容',
        icon: "none"
      })
    } else 
    // if(this.data.content.length < 2) {
    //   return wx.showToast({ title: '请输入2个字以上',icon: 'none' })
    // }else 
    {
      const imgs = this.data.ImageGroup.join(',');

      // 处理地区信息
      let address_info = '未知';
      if(wx.$cache.get('province')) address_info = getApp().globalData.region[0] || wx.$cache.get('province')
      if(wx.$cache.get('city')) address_info = getApp().globalData.region[1] || wx.$cache.get('city')
      if(wx.$cache.get('area')) address_info = getApp().globalData.region[2] || wx.$cache.get('area')


      wx.$http.post(wx.$get.add_posts, {
        topic: this.data.topic.replace(/ /,''),
        content: this.data.content,
        imgs: imgs,
        address_info: address_info
      }).then(res => {
        wx.navigateBack({
          success(res) {
            return wx.showToast({
              title: '发布成功',
              icon: "none"
            })
          }
        })
      })
    }
  },
  editPost() {
    if(this.data.content.length < 10) return wx.showToast({ title: '请输入10个字以上',icon: 'none' })
    const _this = this;
    // 正则替换为相对路径图片
    const imgs = this.data.ImageGroup
    wx.$http.post(wx.$get.edit_posts, {topic: this.data.topic,content: this.data.content,imgs: imgs.join(","),posts_id: this.data.id}).then(res=>{
      
      const data = _this.data.data
      data.topic = _this.data.topic
      data.content = _this.data.content
      data.imgs = this.data.showImageGroup
      const eventChannel = this.getOpenerEventChannel()
      eventChannel.emit('editSuccess', data);
      wx.navigateBack({
        success(res) {
          return wx.showToast({title: '修改成功',icon: "none"})
        }
      })
    })
  },
  preView(e){
    wx.previewImage({
      urls:[e.currentTarget.dataset.current],
      current: e.currentTarget.dataset.current
    })
  }
})