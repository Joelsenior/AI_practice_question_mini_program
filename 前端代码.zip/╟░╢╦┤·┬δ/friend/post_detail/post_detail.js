// pages/post_detail/post_detail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentIndex: 0,
    id: 0,
    postData: {},
    member_id: wx.$cache.get('member_id'),
    replyModalShow: false,
    ImageGroup: [],
    showImageGroup: [],
    discussPage: 1,   //评论的页码
    discussData: [],   //评论的数据列表
    thumbsList: [],  // 点赞记录
    discussText: "",
    pid: 0,
    loadState: 'loadmore'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const id = options.id;
    this.setData({id:id,member_id: wx.$cache.get('member_id')})
    this.getPostDetail()
    this.getPostList()
    this.getThumbsList()
  },

  onReady: function () {

  },

  /* param [isDiao]
  *  判断是否为调用，是手动调用带参数则请求，返回页面的onShow不执行
  */
  onShow: function (isDiao) {
    if(isDiao){
      this.setData({discussPage: 1})
      this.getPostDetail()
      this.getPostList()
      this.getThumbsList()
    }
  },

  onHide: function () {

  },

  onUnload: function () {

  },

  onPullDownRefresh: function () {

  },

  onReachBottom: function () {
    if(this.data.loadState != 'nomore'){
      this.setData({discussPage: this.data.discussPage+1})
      this.getPostList()
    }
  },

  onShareAppMessage: function () {
    return {
      title: this.data.postData.content,
      path: '/friend/post_detail/post_detail?id='+this.data.postData.id
    }
  },
  changeIndex(e){
    const index = e.currentTarget.dataset.index;
    this.setData({currentIndex: index})
  },
  update(){
    let postData = this.data.postData
    postData.is_follow = postData.is_follow == 1 ? 2 : 1;
    this.setData({postData:postData})
    const eventChannel = this.getOpenerEventChannel()
    eventChannel.emit('editSuccess', postData);
  },
  onEnter(){},
  closeModal(){
    this.setData({replyModalShow: false})
  },
  openModal(res){
    this.setData({replyModalShow: true,pid:res.currentTarget.dataset.pid,nickname:res.currentTarget.dataset.nickname})
  },
  uploadImage(){
    const _this = this;
    wx.chooseImage({
      count: 1,
      success(res) {
        wx.uploadFile({
          filePath: res.tempFilePaths[0],
          name: 'file',
          url: wx.$get.upload_file,
          formData: {key: wx.$cache.get('key'),file_type: 4},
          success(uploadRes) {
            const data = JSON.parse(uploadRes.data)
            _this.setData({
              ImageGroup: [..._this.data.ImageGroup, data.datas.url],
              showImageGroup: [..._this.data.showImageGroup, data.datas.src]
            })
          }
        })
      }
    })
  },
  removeImage(e){
    const dataIndex = e.currentTarget.dataset.index;
    const _this = this;
    wx.showModal({
      content:"确认删除？",
      success(res){
        if(res.confirm){
          _this.setData({
            ImageGroup: _this.data.ImageGroup.filter((res, index) => index !== dataIndex),
            showImageGroup: _this.data.showImageGroup.filter((res, index) => index !== dataIndex)
          })
        }
      }
    })
  },
  getPostDetail(){
    wx.$http.post(wx.$get.posts_info,{posts_id:this.data.id}).then(res=>{
      this.setData({postData: res})
    })
  },
  getPostList(){
    wx.$http.post(wx.$get.posts_comment_list,{posts_id:this.data.id,page:this.data.discussPage,page_size:10}).then(res=>{
      if(this.data.discussPage == 1) {
        this.setData({discussData:res,loadState: res.length < 10 ? 'nomore' : 'loadmore'})
      }else {
        this.setData({discussData: [...this.data.discussData,...res],loadState: res.length < 10 ? 'nomore' : 'loadmore'})
      }
    })
  },
  getThumbsList(){
    wx.$http.post(wx.$get.posts_give_log,{posts_id:this.data.id,is_all: 1}).then(res=>{
      this.setData({thumbsList:res})
    })
  },
  thumb(){
    wx.$http.post(wx.$get.posts_give_member,{type:1,log_id:this.properties.postData.id}).then(res=>{
      let data = this.properties.postData;
      if(data.is_give == 1){
        wx.showToast({title: '点赞已取消',})
        data.is_give = 2;
        data.give_num--;
        this.setData({postData: data})
        const eventChannel = this.getOpenerEventChannel()
        eventChannel.emit('editSuccess', data);
      }else{
        wx.showToast({title: '点赞成功',})
        data.is_give = 1;
        data.give_num++;
        this.setData({postData: data})
        const eventChannel = this.getOpenerEventChannel()
        eventChannel.emit('editSuccess', data);
      }
    })
  },
  thumbDiscuss(e){
    wx.$http.post(wx.$get.posts_give_member,{type:2,log_id: e.currentTarget.dataset.id}).then(res=>{
      this.onShow(true);
    })
  },
  postsAddComment(){
      // 处理地区信息
      let address_info = '未知';
      if(wx.$cache.get('province')) address_info = getApp().globalData.region[0] || wx.$cache.get('province')
      if(wx.$cache.get('city')) address_info = getApp().globalData.region[1] || wx.$cache.get('city')
      if(wx.$cache.get('area')) address_info = getApp().globalData.region[2] || wx.$cache.get('area')

    wx.$http(wx.$get.posts_add_comment,{
      posts_id: this.data.postData.id,
      content: this.data.discussText,
      imgs:this.data.ImageGroup.join(','),
      p_id: this.data.pid,
      address_info: address_info
    }).then(res=>{
      this.setData({replyModalShow:false,discussText:"",ImageGroup:[],showImageGroup:[]})
      this.onShow(true)
    })
  },
  preView(e){
    wx.previewImage({
      urls: e.currentTarget.dataset.images,
      current: e.currentTarget.dataset.current
    })
  },
  goUserHome(e){
    const uid = e.currentTarget.dataset.uid;
    wx.navigateTo({
      url: '/friend/user/user?uid='+uid,
    })
  }
})