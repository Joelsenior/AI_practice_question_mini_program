// pages/list/index.js
let app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    back: "<",
    nickname: '',
  },
  tapimg() {
    var _this=this
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ["album", "camera"],
      success: function (t) {
        console.log(t)
        if(wx.cropImage){
        wx.cropImage({
          src: t.tempFilePaths[0], // 图片路径
          cropScale: '1:1', // 裁剪比例
          success: function (res) {
            wx.uploadFile({
              url: wx.$get.upload_img,
              filePath: res.tempFilePath,
              name: 'file',
              formData: {
                'key': wx.$cache.get('key')
              },
              success: (res) => {
             
                res = JSON.parse(res.data)
             
                _this.setData({
                  'img': res.datas.src,
                })
        
        
        
              },
        
        
            })
          } 
        })
      }else{
       
            wx.uploadFile({
              url: wx.$get.upload_img,
              filePath:t.tempFilePaths[0],
              name: 'file',
              formData: {
                'key': wx.$cache.get('key')
              },
              success: (res) => {
             
                res = JSON.parse(res.data)
             
                _this.setData({
                  'img': res.datas.src,
                })
        
        
        
              },
        
        
            })
        
      }
        // wx.navigateTo({
        //   url: '/friend/cropperImage/cropperImage?imageUrl=' + t.tempFilePaths[0],
        // })
      }
    })
 
  },
  onLoad: function (options) {
    this.setData({
      img: wx.$cache.get('userinfo').img,
      nickname: wx.$cache.get('userinfo').nickname
    })
  },
  submit() {
    wx.$http.post(wx.$get.update_member, this.data).then(res => {
      let userinfo = wx.$cache.get('userinfo');
      userinfo.img = this.data.img,
      userinfo.nickname = this.data.nickname
      wx.$cache.set('userinfo',userinfo)
      wx.navigateBack({
        delta: 0,
      })
    })
  },


})