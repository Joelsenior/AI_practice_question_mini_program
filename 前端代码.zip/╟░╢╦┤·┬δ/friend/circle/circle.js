// pages/circle.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    stickyBarIndex: 0,
    postData: [], // 帖子信息
    page: 1,
    limit: 15,
    userinfo: {},
    loadState: "loadmore", //  ['loadmore','loading','nomore']
    loadText: {
      loadmore: '上拉加载更多~',
      loading: '正在加载中...',
      nomore: '没有更多了'
    },
    register: true,
    showModal: false,
    selectPostData: {},
    member_unread_num: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (wx.$cache.get('key')) {
      this.setData({
        register: false
      })
    }
  },

  onReady: function () {

  },

  onShow: function () {
    if(this.data.loadState != 'nomore'){
      if(this.data.page != 1) this.setData({page:this.data.page+1})
      this.loadPostData()
    }
    this.userinfo()
    this.getunReadNum()
  },

  getunReadNum(){
    wx.$http.post(wx.$get.member_unread_num).then(res=>{
      this.setData({member_unread_num:res})
    })
  },
  onHide: function () {

  },

  onUnload: function () {

  },

  onPullDownRefresh: function () {
    this.setData({page:1,postData:[],loadState:'loading'})
    this.onShow();
  },

  onReachBottom: function () {
    if (this.data.loadState != 'nomore') {
      this.setData({
        page: this.data.page + 1,
        loadState: 'loading'
      })
      this.loadPostData();
    }
  },
  onShareAppMessage: function (e) {
if(e.from=='button'){
  return {
    title: this.data.selectPostData.content,
    imageUrl:this.data.selectPostData.imgs[0]||'',
    path: 'friend/post_detail/post_detail?id='+this.data.selectPostData.id
  }
}else{
  return {
  title:wx.$cache.get('share').title,
  imageUrl:wx.$cache.get('share').img,
  path:`/friend/circle/circle?pid=${wx.$cache.get('member_id')||0}`
  }
}
   
  },
  onTabChange(event) {
    const index = event.currentTarget.dataset.index;
    this.setData({
      stickyBarIndex: index,
      page: 1,
      loadState: 'loading'
    })
    wx.showLoading({
      title: '请稍等...',
      mask: true
    })
    this.loadPostData();
  },
  loadPostData() {
    wx.$http(wx.$get.posts_list, {
      page: this.data.page,
      page_size: this.data.limit,
      sort_type: this.data.stickyBarIndex == 0 ? 1 : 2
    }).then(res => {
      if (this.data.page == 1) {
        this.setData({ 
          postData: res.list,
          loadState: res.list.length < this.data.limit ? 'nomore' : 'loadmore'
        })
      } else {
        this.setData({
          postData: [...this.data.postData, ...res.list],
          loadState: res.list.length < this.data.limit ? 'nomore' : 'loadmore'
        })
      }
      wx.hideLoading()
      wx.stopPullDownRefresh()
    }).catch(res=>{
      console.log(res)
    })
  },
  goReport() {
    wx.navigateTo({
      url: '/friend/report/report',
    })
  },
  goDetail(e) {
    const id = e.currentTarget.dataset.id
    const _this = this;
    wx.navigateTo({
      url: '/friend/post_detail/post_detail?id='+id,
      events: {
        editSuccess:function(result){
          let res = {detail:result};
          _this.editPostItem(res)
        }
      },
    })
  },
  goSearch() {
    wx.navigateTo({
      url: '/friend/search/search',
    })
  },
  userinfo() {
    console.log(wx.$cache.get('userinfo'))
    this.setData({userinfo: wx.$cache.get('userinfo')})
  },
  showMoreModal(res){
    this.setData({showModal: true,selectPostData: res.detail})
  },
  startShare(res){
    this.setData({selectPostData: res.detail})
  },
  removePostItem(res) {
    const id = res.detail.id;
    this.setData({
      postData: this.data.postData.filter(value => value.id != id),
      showModal: false
    })
  },
  editPostItem(res) {
    console.log(res)
    const data = res.detail
    this.setData({
      postData: this.data.postData.map((value)=>{
        if(value.id == data.id){
          return data
        }else{
          return value
        }
      }),
      showModal: false
    })
  },
  followUser(res){
    const data = res.detail
    this.setData({
      postData: this.data.postData.map((value)=>{
        if(value.member_id == data.member_id){
          value.is_follow = data.is_follow
          return value
        }else{
          return value
        }
      }),
      showModal: false
    })
  },
  goUser(){
    wx.navigateTo({
      url: '/friend/user/user?uid='+this.data.userinfo.id||this.data.userinfo.member_id,
    })
  }
})