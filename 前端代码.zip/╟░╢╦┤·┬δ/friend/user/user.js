// pages/user/user.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    scrollTop:0,
    showModal: false,
    uid:0,
    my_uid: wx.$cache.get('member_id'),
    header_bg: "",
    userinfo:{},
    page:1,
    limit: 15,
    postData: [],
    loadState: "loadmore", //  ['loadmore','loading','nomore']
    loadText: {
      loadmore: '上拉加载更多~',
      loading: '正在加载中...',
      nomore: '没有更多了'
    },
    selectPostData: {},
    title: '他的主页',
    member_unread_num: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({uid: options.uid,my_uid: wx.$cache.get('member_id')})
    if(options.uid == this.data.my_uid){
      this.setData({header_bg:'https://vkceyugu.cdn.bspapp.com/VKCEYUGU-a3de8068-5f32-47fa-96a3-87a03db5d0d4/37545bdc-40e3-4666-b806-ec621a8ef795.png',title:'我的主页'})
    }else{
      this.setData({header_bg:'https://vkceyugu.cdn.bspapp.com/VKCEYUGU-a3de8068-5f32-47fa-96a3-87a03db5d0d4/77ff19c5-0ec6-4af3-b29b-5bab6fffc5fb.png',title:'他人主页'})
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function (is_diao) {
    this.getunReadNum();
    this.loadUserInfo();
    this.loadPost();
    if(this.data.my_uid == this.data.uid){
      let userinfo = this.data.userinfo;
      userinfo.img = wx.$cache.get('userinfo').img
      userinfo.nickname = wx.$cache.get('userinfo').nickname
      this.setData({userinfo:userinfo})
    }
    if(is_diao){
      this.loadUserInfo();
      this.loadPost();
    }
  },

  getunReadNum(){
    wx.$http.post(wx.$get.member_unread_num).then(res=>{
      this.setData({member_unread_num:res})
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.loadState != 'nomore') {
      this.setData({
        page: this.data.page + 1,
        loadState: 'loading'
      })
      this.loadPost();
    }
  },
  onShareAppMessage: function () {

  },
  onPageScroll(e){
    this.setData({scrollTop: e.scrollTop})
  },
  openMoreModal(e){
    this.setData({showModal: true,selectPostData: e.detail})
  },
  closeModal(){
    console.log("啊")
  },
  goFollow(e){
    wx.navigateTo({
      url: '/friend/follow/follow?member_id='+e.currentTarget.dataset.member_id,
    })
  },
  goFans(e){
    wx.navigateTo({
      url: '/friend/follow/follow?member_id='+e.currentTarget.dataset.member_id+"&type=fans",
    })
  },
  lookDiscuss(){
    wx.navigateTo({
      url: '/friend/discuss/discuss',
    })    
  },
  postsMemberInfo(){

  },
  loadUserInfo(){
    wx.$http.post(wx.$get.posts_member_info,{show_member_id: this.data.uid}).then(res=>{
      this.setData({userinfo: res})
    })
  },
  loadPost(){
    wx.$http(wx.$get.posts_list, {page: this.data.page,page_size: this.data.limit,sort_type: 1,release_member_id: this.data.uid}).then(res => {
      if (this.data.page == 1) {
        this.setData({ 
          postData: res.list,
          loadState: res.list.length < this.data.limit ? 'nomore' : 'loadmore'
        })
      } else {
        this.setData({
          postData: [...this.data.postData, ...res.list],
          loadState: res.list.length < this.data.limit ? 'nomore' : 'loadmore'
        })
      }
      wx.hideLoading()
    }).catch(res=>{
      console.log(res)
    })
  },
  goDetail(e) {
    const id = e.currentTarget.dataset.id
    const _this = this;
    wx.navigateTo({
      url: '/friend/post_detail/post_detail?id='+id,
      events: {
        editSuccess:function(result){
          let res = {detail:result};
          _this.editPostItem(res)
        }
      },
    })
  },
  removePostItem(res) {
    const id = res.detail.id;
    this.setData({
      postData: this.data.postData.filter(value => value.id != id),
      showModal: false
    })
  },
  editPostItem(res) {
    const data = res.detail
    // TODO 不知道为什么要加这个修改用户信息的代码
    // let userInfo = this.data.userinfo
    // userInfo.is_follow = userInfo.is_follow == 1 ? 2 : 1;
    // console.log(data)
    this.setData({
      postData: this.data.postData.map((value)=>{
        if(value.id == data.id){
          return data
        }else{
          return value
        }
      }),
      showModal: false,
      // userinfo: userInfo
    })
  },
  followAction(){
    wx.$http(wx.$get.posts_follow_member,{show_member_id:this.data.uid}).then(res=>{
      let userinfo = this.data.userinfo
      if(userinfo.is_follow == 1){
        wx.showToast({title: '取关成功',icon:"none"})
        userinfo.is_follow = 2;
        userinfo.posts_fans = userinfo.posts_fans -1
        this.setData({userinfo:userinfo})
      }else{
        wx.showToast({title: '关注成功',icon:"none"})
        userinfo.is_follow = 1;
        userinfo.posts_fans = userinfo.posts_fans +1
        this.setData({userinfo:userinfo})
      }
    })
  },
  updateInfo(){
    if(this.data.uid == this.data.my_uid){
      wx.navigateTo({
        url: '/friend/about-my/about-my',
      })
    }
  }
})