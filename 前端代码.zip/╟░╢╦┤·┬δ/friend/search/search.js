// pages/search/search.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    searchText: "",
    tabBarIndex: 0,
    topicData: [],
    postData: {},
    page:1,
    limit: 15,
    count: 0,
    userinfo: wx.$cache.get('userinfo'),
    showModal: false,
    selectPostData: {},
    loadState: 'loadmore'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.loadSearchResult()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if(this.data.tabBarIndex == 1){
      if (this.data.loadState != 'nomore') {
        this.setData({
          page: this.data.page + 1,
          loadState: 'loading'
        })
        this.loadSearchPostResult();
      }
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return{
      
    }
  },
  changeTabIndex(e){
    this.setData({tabBarIndex: e.currentTarget.dataset.index,postData:[]})
    this.startSearch();
  },
  clearSearchText(){
    this.setData({searchText: ""})
  },
  goTopic(e){
    wx.navigateTo({
      url: '/friend/topic/topic?text='+e.currentTarget.dataset.text,
    })
  },
  startSearch(){
    if(this.data.tabBarIndex == 0){
      this.loadSearchResult()
    }else{
      this.setData({page:1})
      this.loadSearchPostResult()
    }
  },
  loadSearchResult(){
    wx.$http.post(wx.$get.posts_word_topic,{word_str:this.data.searchText,is_all:1}).then(res=>{
      this.setData({topicData:res})
    })
  },
  loadSearchPostResult(){
    wx.$http(wx.$get.posts_list, {page: this.data.page,page_size: this.data.limit,sort_type: this.data.tabBarIndex,word_str: this.data.searchText}).then(res => {
      if (this.data.page == 1) {
        this.setData({ 
          postData: res.list,
          loadState: res.list.length < this.data.limit ? 'nomore' : 'loadmore',
          count: res.count
        })
      } else {
        this.setData({
          postData: [...this.data.postData, ...res.list],
          loadState: res.list.length < this.data.limit ? 'nomore' : 'loadmore',
          count: res.count
        })
      }
      wx.hideLoading()
    }).catch(res=>{
      console.log(res)
    })
  },
  goDetail(e) {
    const id = e.currentTarget.dataset.id
    const _this = this;
    wx.navigateTo({
      url: '/friend/post_detail/post_detail?id='+id,
      events: {
        editSuccess:function(result){
          let res = {detail:result};
          _this.editPostItem(res)
        }
      },
    })
  },
  showMoreModal(res){
    this.setData({showModal: true,selectPostData: res.detail})
  },
  editPostItem(res) {
    console.log(res)
    const data = res.detail
    this.setData({
      postData: this.data.postData.map((value)=>{
        if(value.id == data.id){
          return data
        }else{
          return value
        }
      }),
      showModal: false
    })
  },
  removePostItem(res) {
    const id = res.detail.id;
    this.setData({
      postData: this.data.postData.filter(value => value.id != id),
      showModal: false
    })
  },
})