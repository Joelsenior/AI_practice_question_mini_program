// PackageA/pages/stgl/stgl.js
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    is_del: 0,
    is_js: 1, //0未解锁，1已解锁
    is_my: 1, //是否是我得题库，
    majorInfo: {},
    schoolList: [],
    selectSchoolId: 0, //  学校ID，为0则是我的题库
    selectSchoolInfo: {}, //  学校信息
    listData: [], // 题库列表
    showSchoolUseStateModal: false,// 是否展示学校解锁弹窗
    inputText: '',  //  输入框的内容
    selectTkList: [], //  选中的题库ID列表，  eg:【0，20，1】
    type:1,//1刷题，2刷知识点
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    console.log(options)
    this.setData({
      majorInfo: wx.$cache.get('majorInfo'),
      type:options.type
    },()=>{
      this.getSchoolList()
    })
    if(options.type == 2) {
      wx.setNavigationBarTitle({title: '知识点管理'})
    }
   
  },
  pageToWorkIndex(e) {//刷题
    console.log(e)
    if(e.currentTarget.dataset.type ==1){
      if(e.currentTarget.dataset.num){
        
        wx.navigateTo({
            url: '/PackageA/pages/stzy/library_list?rand=0&library_id='+e.currentTarget.dataset.id +"&type="+this.data.type ,
          })
        }else{
          wx.showToast({
            icon:'none',
            title: '当前题库并无题目',
          })
        }
    }else{
      wx.navigateTo({
        url: '/pageQ/pages/pdf/pdf?library_id='+e.currentTarget.dataset.id +"&type="+this.data.type ,
      })
    }
    
  },
  closeshowcode(){//关闭学校二维码
    this.setData({
      'selectSchoolInfo.showcode':false
    })
  },
  towebview(){
    app.content = wx.$cache.get('can').verification_url
    wx.navigateTo({
        url: '/pages/webview/webview?type=1&title=如何领取激活码',
    })
  },
  previewImg(e) { //预览图片
    console.log(e)
    wx.previewImage({
      urls: e.currentTarget.dataset.url,
      current:e.currentTarget.dataset.current,
    })
  },
  gohome(){
    wx.reLaunch({
      url: '/pages/index/index',
    })
  },
  changeSchoolId(e) {
    const s_id = Number(e.currentTarget.dataset.id)
    const sInfo = this.data.schoolList.find(value => value.id == s_id)
   
    sInfo?sInfo.showcode=true:'';
    this.setData({
      selectSchoolId: s_id,
      is_my: s_id == 0 ? 1 : 0,
      // is_js: s_id == 0 ? 1 : ((sInfo?.is_use == 1 || sInfo?.is_currency == 1) ? 1 : 0),
	  // 新增代码
	  is_js: 1,
		 
      selectSchoolInfo: sInfo,
      listData: [],
      is_del: 0
    }, () => {
      if(s_id){
        this.getListData()//拉取题库
      }else{
        this.getmyListData()//拉取我的题库
      }
      })
  },
  getSchoolList() {//拉取学校
    wx.$http.post(wx.$api.school_list, {
      is_all: 1,
      major_id: this.data.majorInfo?.id,
      member_id: wx.$cache.get('userinfo')?.id,
      type: this.data.type
    }).then(res => {
      this.setData({
        schoolList: res,
        // is_js: this.data.selectSchoolId == 0 ? 1 : ((this.data.selectSchoolInfo?.is_use == 1 || this.data.selectSchoolInfo?.is_currency == 1) ? 1 : 0),
		// 新增代码
		is_js: 1,
	  }, () => this.getmyListData())
    })
  },
  getListData() {//拉取题库
    let reqParams = {
      is_all: 1,
      major_id: this.data.majorInfo?.id,
      member_id: wx.$cache.get('userinfo')?.id,
      type:this.data.type,
    }
    if (this.data.selectSchoolId != 0) reqParams.school_id = this.data.selectSchoolId
    wx.$http.post(wx.$api.library_list, reqParams).then(res => {
      res.forEach(item=>{
        
        item.subject_speed=item.subject_speed.toFixed(2);
        console.log(item.subject_speed)
      })
      this.setData({
        listData: res
      })
    })
  },
  getmyListData() {//拉取题库
    let reqParams = {
      is_all: 1,
      major_id: this.data.majorInfo?.id,
      member_id: wx.$cache.get('userinfo')?.id,
      type:this.data.type,
    }
    if (this.data.selectSchoolId != 0) reqParams.school_id = this.data.selectSchoolId
    wx.$http.post(wx.$api.my_library_list, reqParams).then(res => {
      res.forEach(item=>{
        
        item.subject_speed=item.subject_speed.toFixed(2);
        console.log(item.subject_speed)
      })
      this.setData({
        listData: res
      })
    })
  },
  addTkToTempList(e) {
    this.setData({selectTkList: Array.from([...this.data.selectTkList, e.currentTarget.dataset.id])})
  },
  removeTkFromTempList(e) {
    console.log(1)
    this.setData({selectTkList: this.data.selectTkList.filter(value => value != e.currentTarget.dataset.id)})
  },
  joinTk() {
    console.log(this.data.selectTkList);
    wx.$http.post(wx.$api.add_my_library,{library_ids: this.data.selectTkList.join(',')}).then(res => {
      wx.showToast({title: '操作成功'})
      let s_id = 0
      const sInfo = this.data.schoolList.find(value => value.id == s_id)
      this.setData({
        selectSchoolId: s_id,
        is_my: s_id == 0 ? 1 : 0,
        // is_js: s_id == 0 ? 1 : ((sInfo?.is_use == 1 || sInfo?.is_currency == 1) ? 1 : 0),
		// 新增代码
		is_js: 1,
		
        selectSchoolInfo: sInfo,
        listData: [],
        is_del: 0
      }, () => this.getListData())
    })
  },
  showGetSchoolUsestateModal() {
    this.setData({showSchoolUseStateModal: true, inputText: ''})
  },
  cloStateModal() {
    this.setData({showSchoolUseStateModal: false, inputText: ''})
  },
  useSchoolStateChange() {

    wx.$http.post(wx.$api.use_activation_code,{code: this.data.inputText}).then(res => {
      wx.showToast({title: '操作成功'})
     
      this.getSchoolList()
      const s_id = {currentTarget:{dataset:{id:this.data.selectSchoolInfo.id}}}
      setTimeout(() => {
        this.setData({showSchoolUseStateModal: false})
        this.changeSchoolId(s_id) 
      }, 500);
 
   
    })
  },
  checkall() {
    var selectTkList=[];
    if(this.data.listData.length!=this.data.selectTkList.length){
      this.data.listData.forEach(item=>{
        selectTkList.push(item.id)
      })
    }
this.setData({
  selectTkList,
})
  },
  del() {
    this.setData({
      is_del: this.data.is_del == 1 ? 0 : 1,
      selectTkList: []
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 移除题库
   */
  Remove_question() {
    wx.$http.post(wx.$api.del_my_library,{library_ids: this.data.selectTkList.toString()}).then(res => {
     this.setData({
      selectTkList:[],
      is_del:0
     })
      this.getSchoolList()
    })
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})