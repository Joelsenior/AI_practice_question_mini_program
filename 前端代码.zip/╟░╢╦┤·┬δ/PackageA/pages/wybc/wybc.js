// PackageA/pages/wybc/wybc.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    subject_audio_s: 0, //语音长度
    type: 1, //题类型
    stem_type: 1, //题目类型
    subject_content: '', //题目内容
    subject_id: 0, //题目id
    content: '', //报错内容
    imgs: [], //相关图片 (多图)
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.setData({
      subject_audio_s: wx.$wybc.subject_audio_s,
      type: wx.$wybc.type, //题类型
      stem_type: wx.$wybc.stem_type, //题目类型
      subject_content: wx.$wybc.subject_content, //题目内容
      subject_id: wx.$wybc.subject_id
    })
  },
  uploadImageFunction(tempPath) {//上传图片
    return new Promise((resolve,_reject) => {
      wx.showLoading({title: '上传图片中...',mask: true})
      wx.uploadFile({
        filePath: tempPath,
        name: 'file',
        formData: { 'key': wx.$cache.get('key') },
        url: wx.$api.upload_img,
        success(res) {
          res = JSON.parse(res.data)
          wx.hideLoading()
          resolve(res.datas)
        }
      })
    })
  },
  to_report_errors(){//提交报错
    wx.$http.post(wx.$api.add_report_errors,{subject_id: this.data.subject_id,content:this.data.content,imgs:this.data.imgs.map(value => value.url).join(',')}).then(res => {
   
     wx.showToast({
      title:"感谢您的反馈~",
      icon: 'none',
      duration: 1000
  });
setTimeout(function(){
  wx.navigateBack()  
},1000)
    })
  },
  previewImg(e) { //预览图片
    wx.previewImage({
      urls: [e.currentTarget.dataset.url],

    })
  },
  removeImage(e) {//删除图片
    this.setData({imgs: this.data.imgs.filter(value => value.src != e.currentTarget.dataset.item.src)})
  },
  uploadImageFile() {//上传图片
    const _this = this;
    wx.chooseMedia({
      mediaType: 'image',
      count: 9 - this.data.imgs.length,
      success(e) {
        const tempFiles = e.tempFiles
        let taskList = []
        tempFiles.forEach(value => taskList.push(_this.uploadImageFunction(value.tempFilePath)))
        Promise.all(taskList).then(res => {
          _this.setData({imgs: [..._this.data.imgs,...res]})
        })
      }
    })
  },
})