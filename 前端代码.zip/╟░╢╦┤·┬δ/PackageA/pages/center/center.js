import * as echarts from '../../../Cpart/ec-canvas/echarts';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    censusEc: {
      lazyLoad: true,
      disableTouch: false,
     
  
    },
    "subject_num": 0,
    "student_num": 0,
    "student_day": 0,
    "correct_rate": 0,
    tabidx:0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  tobcfkjl() {
wx.navigateTo({
  url: '/PackageA/pages/xx/xx?bc=1',
})
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.setData({userInfo: wx.$cache.get('userinfo')})
    this.subject_data();
    
  },

  /**
   * 切换图表
   */
  qienum(ee) {
this.setData({tabidx:ee.currentTarget.id})
this.init();
  },

  /**
   * 生命周期函数--监听页面卸载
   */

 subject_data(){
   //用户刷题统计_数据
  wx.$http.post(wx.$api.member_subject_data, {}).then(res => {
   
   
    this.setData({
      "subject_num": res.subject_num,
      "student_num": (res.student_num/3600).toFixed(1),
      "student_day": res.student_day,
      "correct_rate": res.correct_rate.toFixed(1),
    })
  })    
  //用户刷题统计_刷题量
  wx.$http.post(wx.$api.member_subject_num, {}).then(res => {
    var time=[],num=[];
    res.forEach(item=>{
      time.push(item.time)
      num.push(item.num)
    })
   this.member_subject_num={
    time,
    num,
  }
  this.init();
  })  
  //用户刷题统计_刷题时间
  wx.$http.post(wx.$api.member_subject_time, {}).then(res => {
    var time=[],num=[];
    res.forEach(item=>{
      time.push(item.time)
      num.push(item.num)
    })
    this.member_subject_time={
      time,
      num,
    }

    
   })    
 },
  init() {
    const _this = this;

    this.selectComponent('#census').init((canvas, width, height, dpr) => {
      console.log(echarts)
      const chart = echarts.init(canvas, null, {
        width,
        height,
        devicePixelRatio: dpr, // new
      });
      let option = {
        color: "#406BFE",
        xAxis: {
          type: 'category',
          data:_this.data.tabidx==1?_this.member_subject_time.time: _this.member_subject_num.time
        },
        yAxis: {
          type: 'value'
        },
        series: [{
          data: _this.data.tabidx==1?_this.member_subject_time.num: _this.member_subject_num.num,
          type: 'line',
          smooth: true,
          areaStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1,
              [{
                offset: 0,
                color: 'rgba(58,132,255, 0.5)'
              }, {
                offset: 1,
                color: 'rgba(58,132,255, 0)'
              }]
            ),

          }
        }]
      };
      chart.setOption(option);
      return chart;

    })

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  toabout_my() {
wx.navigateTo({
  url: '/friend/about-my/about-my',
})
  },

})