Page({

  /**
   * 页面的初始数据
   */
  data: {
    listData: [],
    selectData: {},
    chapterList: [],
    awaitRefresh: false,
    typeIndex: 1,   //  1 => 每日刷题,2 => 刷知识点
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    if(options.type == 2) {
      wx.setNavigationBarTitle({title: '知识点主页'})
    
    }
    this.setData({typeIndex: options.type})
   
  },
  getLibraryList() {//题库
    var  _this=this
    wx.$http.post(wx.$api.my_library_list,{
      is_all: 1, 
      type:this.data.typeIndex,//题库类型
      major_id: wx.$cache.get('majorInfo').id,
      member_id: wx.$cache.get('userinfo').id
    }).then( res => {
      res = res.filter(value => value.is_my_library == 1)
      if(res.length==0){
        wx.showModal({
          title: '您的'+(this.data.typeIndex==1?'题库':'知识点')+'空空如也~',
          content: '您还没有'+(this.data.typeIndex==1?'题库':'知识点')+',是否前去加入？',
          cancelText:'回首页',
          confirmText:'马上添加',
          complete: (res) => {
            if (res.cancel) {
              wx.navigateBack()
            }
        
            if (res.confirm) {
              wx.navigateTo({
                url: '/PackageA/pages/stgl/stgl?type='+_this.data.typeIndex,
                success() {
                  _this.setData({awaitRefresh: true})
                }
              })
            }
          }
        })
 
        
      }

      this.setData({listData: res, selectData: this.data.selectData?.id?this.data.selectData:res[0]},() => this.getChapterList())
 
	  // console.log(111)
	  // console.log(this.data.selectData.do_subject_num)
	  // console.log(this.data.selectData.do_subject_num)
	  // 	  console.log(this.data.selectData.subject_num)
		  	  // console.log(222)

	}
	)
  },
  changeSelectData(e) {
    console.log(e.detail.current);
	
    this.setData({selectData: this.data.listData[e.detail.current]},() => this.getChapterList())
  },
  getChapterList() {
    const _this = this;
   
      wx.$http.post(wx.$api.chapter_list,{is_all: 1, library_id: this.data.selectData.id, member_id: wx.$cache.get('userinfo').id}).then(res => {
        this.setData({ chapterList: res })
      })
    
  },
  //顺序刷题
  pageToWorkIndex() {
// 	  console.log(this.data.selectData.id) 0000000
// return
  

// console.log(this.data.typeIndex)  //  1 => 每日刷题,2 => 刷知识点
// return
  if(this.data.selectData.type==2){  //跳转PDF
    wx.navigateTo({
      url: '/pageQ/pages/pdf/pdf?library_id='+this.data.selectData.id +"&type="+this.data.typeIndex ,
    })
    return 
  }

    if(this.data.selectData.subject_num){
    wx.navigateTo({
      url: '/subPackageZ/pages/brush-topic/brush-topic?rand=0&type='+this.data.typeIndex+'&library_id='+this.data.selectData.id,
    })
  }else{
    wx.showToast({
      icon:'none',
      title: '当前题库并无题目',
    })
  }
  },
   //随机刷题
  pageToWorkRandom() {
	  // console.log(this.data.selectData.id)
	  // return
	  
    wx.navigateTo({
      url: '/subPackageZ/pages/brush-topic/brush-topic?rand=1&library_id='+this.data.selectData.id,
    })
  },
  
  //跳转
  pageToWorkChild(e) {
	  
	 
    wx.navigateTo({
      url: '/subPackageZ/pages/brush-topic/brush-topic?rand=0&library_id='+this.data.selectData.id+'&chapter_id='+e.currentTarget.dataset.item.id,
    })
  },
  
  
  rePageToWork() {
    var that=this
    wx.showModal({
      title: '确定要重新刷题？',
      content: '重新刷题后刷题记录将不被保留，一切将重新开始！',
      complete: (res) => {
        if (res.cancel) {
          
        }
    
        if (res.confirm) {
          wx.showLoading({title: '请稍等...',mask: true})
          wx.$http.post(wx.$api.subject_reset,{library_id: this.data.selectData.id}).then(res => {
            wx.hideLoading()
            that.pageToWorkIndex()
          })
        }
      }
    })
  
  },
  jumpTo(e) {
    const { url } = e.currentTarget.dataset
    if(!wx.$cache.get('majorInfo')?.id) return this.setData({is_show: true})
    wx.navigateTo({
      url: url,
    })
  },
  
  onShow() {
    if(this.data.awaitRefresh) {
      this.setData({awaitRefresh: false},() => this.getLibraryList())
    }else{
      this.getLibraryList();
    }
   
   
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
    return{
      title:wx.$cache.get('share').title,
      imageUrl:wx.$cache.get('share').img,
      path:`/pages/index/index?pid=${wx.$cache.get('member_id')}`
    }
  }
})