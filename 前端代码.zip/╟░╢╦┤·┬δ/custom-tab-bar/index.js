Component({
  lifetimes:{
    attached() { 
      let that=this
      // if(that.data.is_xiaoxi==0){
      //   console.log(that.data.list.splice(3,1))
      //   that.setData({
      //     list: that.data.list
      //   })
      // }else{
      //   console.log(that.data.list.splice(2,1))
      //   that.setData({
      //     list: that.data.list
      //   })
      // }
    }
  },
  data: {
    domain:"",
    isCenter: false,
    selected: 0,
    color: "#000000",//未选中的颜色
    selectedColor: "red",//选中颜色
    user_power:0,//用户权限0：普通用户，1:相当于高管
    is_xiaoxi:0,
    xiaoxi_sum:0,
    is_posts:2,
    list: [{
      "pagePath": "/pages/index/index",
      "iconPath":  wx.$domain+ "/img/tab/store_h.png",
      "selectedIconPath":  wx.$domain+ "/img/tab/store_r.png",
      "text": "首页"
    },
    {
      "pagePath":"/pages/video_z/video_z",
      "iconPath":  wx.$domain+ "/img/tab/vip_h.png",
      "selectedIconPath":  wx.$domain+ "/img/tab/vip_r.png",
      "text": "视频"
    },

    
    {
      "pagePath":   "/pages/xx/xx",
      "iconPath":  wx.$domain+ "/img/tab/order_h.png",
      "selectedIconPath":  wx.$domain+ "/img/tab/order_r.png",
      "text": "公告"
    }, 
    {
      "pagePath": "/pages/my/my",
      "iconPath":  wx.$domain+ "/img/tab/my_h.png",
      "selectedIconPath":  wx.$domain+ "/img/tab/my_r.png",
      "text": "我的"
    }

  ],
    list2: [{
        "pagePath": "/pages/index/index",
        "iconPath":  wx.$domain+ "/img/tab/store_h.png",
        "selectedIconPath":  wx.$domain+ "/img/tab/store_r.png",
        "text": "首页"
      },
      {
        "pagePath":    "/pages/video_z/video_z",
        "iconPath":  wx.$domain+ "/img/tab/vip_h.png",
        "selectedIconPath":  wx.$domain+ "/img/tab/vip_r.png",
        "text": "视频"
      },

     
      {
        "pagePath":   "/pages/xx/xx",
        "iconPath":  wx.$domain+ "/img/tab/youxiaoxi.png",
        "selectedIconPath":  wx.$domain+ "/img/tab/order_r.png",
        "text": "公告"
      },
      {
        "pagePath": "/pages/my/my",
        "iconPath":  wx.$domain+ "/img/tab/my_h.png",
        "selectedIconPath":  wx.$domain+ "/img/tab/my_r.png",
        "text": "我的"
      }

    ],
    list3: [{
      "pagePath": "/pages/index/index",
      "iconPath":  wx.$domain+ "/img/tab/store_h.png",
      "selectedIconPath":  wx.$domain+ "/img/tab/store_r.png",
      "text": "首页"
    },
    
    {
      "pagePath":   "/pages/xx/xx",
      "iconPath":  wx.$domain+ "/img/tab/order_h.png",
      "selectedIconPath":  wx.$domain+ "/img/tab/order_r.png",
      "text": "公告"
    }, 
    {
      "pagePath": "/pages/my/my",
      "iconPath":  wx.$domain+ "/img/tab/my_h.png",
      "selectedIconPath":  wx.$domain+ "/img/tab/my_r.png",
      "text": "我的"
    }

  ],
  },

 
  methods: {
    switchTab(e) {
      const data = e.currentTarget.dataset 
      const url = data.path
     
        wx.switchTab({
          url
        })
     
      this.setData({
        selected: data.index
      })
    }
  }
})