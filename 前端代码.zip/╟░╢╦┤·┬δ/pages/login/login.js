// pages/login/login.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        statusBarHeight: 0,
        avatarUrl: 'https://stapi.seniorfd.com/uploads/img/default-avatar.png',
        userNickname: '',
        telephoneNumber: ''
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.initStatusBarHeight()
    },
    initStatusBarHeight() {
        this.setData({
            statusBarHeight: wx.getSystemInfoSync().statusBarHeight + 44
        })
    },
    chooseAvatarImage(e) {
        console.log(e.detail.avatarUrl);
        this.setData({ avatarUrl: e.detail.avatarUrl })
    },
    getUserinfo() {
      wx.showLoading({title: '登陆中...'})
      this.data.userNickname = this.data.userNickname.replace(/^\s*|\s*$/g,"");
      function RegExpString(str) 
      { 
          var p = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]") 
           if(p.test(str)){
              return true}
          else{
              return false
          }
        }
          if(RegExpString(this.data.userNickname)){
            wx.showToast({
              icon: "none",
              title: '昵称不能有特殊字符',
            })
            return
            }
          if (this.data.userNickname.length == 0) {
            return wx.showToast({
              title: '昵称不能为空',
              icon: "none"
            })
          }
         
      wx.login().then(async res => {
        var imageUrl =''
        if(this.data.avatarUrl.indexOf('https')!=-1){
        imageUrl = this.data.avatarUrl
        }else{
          imageUrl = await this.uploadAvatarImage()
        }
      
        wx.$http.post(wx.$api.login, {
          p_id: wx.getStorageSync('p_id') || 0,
          // mobile: wx.$cache.get('mobile'),
          img: imageUrl||'https://stapi.seniorfd.com/uploads/api/img/20221225/040e093c7720fa2728247577445e14ad.jpeg',
          nickname: this.data.userNickname,
          code: res.code
        }).then(e => {
          e.member_id=e.id
          wx.$cache.set('userinfo', e);
          wx.$cache.set('member_id', e.id);
          wx.$cache.set('key', e.token);
          // this.updateUserInfo()
          wx.showToast({
            title: '登陆成功',
            icon: 'none',
            success: () => {
              setTimeout(() => {
                wx.navigateBack({})
              }, 1000);
            }
          })
        })
      })
    },
    quxiaologin(){
      wx.navigateBack({})
    },
    updateUserInfo() {
      const that = this;
      wx.hideLoading()
      wx.showLoading({title: '头像上传中...'})
      wx.getImageInfo({src: this.data.avatarUrl}).then(res => {
        wx.uploadFile({
          filePath: res.path,
          name: 'file',
          formData: { 'key': wx.$cache.get('key') },
          url: wx.$api.upload_img,
          success(res) {
            res = JSON.parse(res.data)
            that.setData({avatarUrl: res.datas.src})
            wx.hideLoading()
            wx.showLoading({title: '登陆中...'})
            wx.$http.post(wx.$api.edit_member,{avatar: that.data.avatarUrl, nickname: that.data.userNickname, mobile: wx.$cache.get('mobile')}).then(e => {
              wx.hideLoading();
              wx.$http.post(wx.$api.get_member).then(res => {
                wx.$cache.set('userinfo', res);
                wx.showToast({
                  title: '登陆成功',
                  icon: 'none',
                  success: () => {
                    setTimeout(() => {
                      wx.navigateBack({})
                    }, 1000);
                  }
                })
              })
            })
          }
        })
      })
    },
    uploadAvatarImage() {
      wx.showLoading({title: '头像上传中...'})
      return new Promise((resolve,reject) => {
        wx.getImageInfo({src: this.data.avatarUrl}).then(res => {
          wx.uploadFile({
            filePath: res.path,
            name: 'file',
            formData: { 'key': wx.$cache.get('key') },
            url: wx.$api.upload_img_no,
            success(res) {
              res = JSON.parse(res.data)
              // that.setData({avatarUrl: res.datas.src})
              wx.hideLoading()
              resolve(res.datas.src)
            }
          })
        })
      })
    },
    //获取用户手机号
    getPhoneNumber(e) {
      wx.hideLoading()
      const that = this;
      const { code, errMsg, iv, encryptedData } = e.detail;
      console.log(e.detail);
      if(errMsg !== 'getPhoneNumber:ok') return wx.showToast({
        title: '登陆异常',
        icon: 'none'
      })
      wx.login().then(res => {
        wx.$http.post(wx.$api.decryption, { code: res.code, iv, encryptedData }).then(res => {
          wx.$cache.set('mobile',res)
          that.getUserinfo()
        })
      })
    },
    login(e){ 
      this.getUserinfo() 
      return
      wx.login().then(res => {
        
        wx.$http.post(wx.$api.wx_login, { code: res.code}).then(res => {
          console.log("code",res)
          this.getUserinfo() 
        })
      })
    },
    //昵称输入
    nicknameInput(e) {
        this.setData({
            'userinfo.nickname': e.detail.value
        })
    },
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})