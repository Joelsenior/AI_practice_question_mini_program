const app = getApp();
Component({
    lifetimes: {
        attached() {
         
        },

    },
    properties: {
        info: {//title字
            type: Object,
            value: {}
        },
       
    },
    data: {
       

    },
   
    /**
     * 组件的方法列表
     */
    methods: {
      previewImg(e) { //预览图片
        wx.previewImage({
          urls: [e.currentTarget.dataset.url],
    
        })
      },
      tosubjectdetail(){//去题目详情
        // wx.$http.post(wx.$api.report_errors_info, {report_errors_id:this.data.info.id}).then(res => {
        
        // })  
        wx.$cache.set('subjectMakeCardList',[{
          "id": this.data.info.subject_id,
          "make_is_ask_ok": 2,
          "make_state": 3,
          "type": this.data.info.subject_type
        }],)
        wx.navigateTo({
          url: '/subPackageZ/pages/brush-topic/brush-topic?rand=0&collect=1&subject_id='+this.data.info.subject_id,
        })
      },
    }
})
