 
Page({

  /**
   * 页面的初始数据
   */
  data: {
    censusEc: {
      lazyLoad: true,
      disableTouch: false,
     
  
    },
    "subject_num": 0,
    "student_num": 0,
    "student_day": 0,
    "correct_rate": 0,
    tabidx:0,
    selectMajorInfo:{}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.getMajorData()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  set() {
    this.setUserSetting({is_music: this.data.set1 == 1 ? 2 : 1}).then(e => {
      this.setData({set1: this.data.set1 == 1 ? 2 : 1})
    })
   
  },
  set1() {
    this.setUserSetting({is_display_answer: this.data.set2 == 1 ? 2 : 1}).then(e => {
      this.setData({set2: this.data.set2 == 1 ? 2 : 1})
    })
  },
  set2() {
    this.setUserSetting({is_automatic: this.data.set3 == 1 ? 2 : 1}).then(e => {
      this.setData({set3: this.data.set3 == 1 ? 2 : 1})
    })
  },
  set3() {
    this.setUserSetting({is_dark: this.data.set4 == 1 ? 2 : 1}).then(e => {
      this.setData({set4: this.data.set4 == 1 ? 2 : 1})
    })
  },
  setUserSetting(params) { 
    return new Promise((resolve,reject) => {
      wx.$http.post(wx.$api.edit_member,params).then(e => {
        wx.$http.post(wx.$api.get_member).then(res => {
          wx.$cache.set('userinfo',res)
          wx.showToast({title: '操作成功'})
          resolve(e)
        })
      })
    })
  },
  tocommunity(){//去研友圈
    wx.navigateTo({
      url: '/friend/circle/circle',
    })
 },
 getMajorInfo(e) { 
  this.setData({
    selectMajorInfo: e.currentTarget.dataset.item,
    is_show: 0
  })
  wx.$cache.set("majorInfo",e.currentTarget.dataset.item)
  
  this.get_unread_news_num();
  //更新存储专业ID
  this.setUserSetting({major_id:e.currentTarget.dataset.item.id})
}, 
get_unread_news_num(){//获取消息数量
  if(!wx.$cache.get('majorInfo')){ 
    return
  }

  wx.$http.post(wx.$api.unread_news_num,{major_id:wx.$cache.get('majorInfo').id
  }).then( res => { 
    if (typeof this.getTabBar === 'function' &&  this.getTabBar()) {
      this.getTabBar().setData({ 
        is_xiaoxi: res.total >0 ?1 :0,
        xiaoxi_sum:res.total
      })
    }
  })
},
  jumpTo(e) {
    const { url } = e.currentTarget.dataset
    if(!wx.$cache.get('userinfo')?.id) {
      wx.navigateTo({url: '/pages/login/login'})
      return false
    } 
    if(!wx.$cache.get('majorInfo')?.id) return this.setData({is_show: true})
    wx.navigateTo({
      url: url,
    })
  },
  close() {
    this.setData({
      is_show: 0,
      is_qrcode: 0,
      is_set: 0
    })
  },
  showQrcode() {
    if(wx.$cache.get('majorInfo')) {
      this.setData({ is_qrcode: true })
    }
  },
  openSetModal() {
    if(wx.$cache.get('userinfo')?.id) {
      this.setData({
        is_set: 1,
        set1: wx.$cache.get('userinfo').is_music,
        set2: wx.$cache.get('userinfo').is_display_answer,
        set3: wx.$cache.get('userinfo').is_automatic,
        set4: wx.$cache.get('userinfo').is_dark,
      })
    } else {
      wx.navigateTo({
        url: '/pages/login/login',
      })
    }
  },
   saveImageBtn() {
    wx.downloadFile({
      url: this.data.selectMajorInfo.qrcode_img,
      success(res) {
        wx.saveImageToPhotosAlbum({
          filePath: res.tempFilePath,
        })
      }
    })
  },
  saveImageBtn() {
    wx.downloadFile({
      url: this.data.selectMajorInfo.qrcode_img,
      success(res) {
        wx.saveImageToPhotosAlbum({
          filePath: res.tempFilePath,
        })
      }
    })
  },
  getMajorData() {
    wx.$http.post(wx.$api.major_list,{}).then( res => {
      this.setData({
        majorList: res, 
        // is_show: this.data.selectMajorInfo.id ? 0 : 1
      })
      
      if(wx.$cache.get('majorInfo')) {
      res.forEach(item=>{if(item.id==wx.$cache.get('majorInfo').id){
  
        this.setData({
          selectMajorInfo: item, 
         
        })
      }
      })
    }
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    if (typeof this.getTabBar === 'function' &&  this.getTabBar()) {
      this.getTabBar().setData({
        selected:wx.$cache.get('can').is_posts ==1? 3:2,
        is_posts:wx.$cache.get('can').is_posts
      })
    }
    this.setData({userInfo: wx.$cache.get('userinfo')})
    this.subject_data();
    if(wx.$cache.get('userinfo')) {this.setData({'userInfo': wx.$cache.get('userinfo')})
      this.get_unread_news_num();
    }
  },
 
  /**
   * 生命周期函数--监听页面卸载
   */

 subject_data(){
   //用户刷题统计_数据
  wx.$http.post(wx.$api.member_subject_data, {}).then(res => {
   
   
    this.setData({
      "subject_num": res.subject_num,
      "student_num": (res.student_num/3600).toFixed(1),
      "student_day": res.student_day,
      "correct_rate": res.correct_rate.toFixed(1),
    })
  })      
 },  
})