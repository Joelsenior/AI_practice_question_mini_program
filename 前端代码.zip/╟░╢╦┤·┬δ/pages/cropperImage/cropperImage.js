var isUpload = false;
let app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    cropperWidth: 200,
    cropperHeight: 200,
    cropperSrc: '',
    type: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      type: options.type
    })
    if (options.type == 1) {
      var calcWidth = wx.getSystemInfoSync().windowWidth - 4;
      this.setData({
        cropperWidth: calcWidth,
        cropperHeight: 320
      });
    } else if (options.type == 2) {
      this.setData({
        cropperWidth: 200,
        cropperHeight: 200
      });
    }
    //获取到image-cropper对象
    this.cropper = this.selectComponent("#image-cropper");
    //开始裁剪
    this.setData({
      cropperSrc: options.imageUrl,
    });
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    })
  },
  //确定
  croppersure(e) {
    if (isUpload) {
      return
    }
    wx.showLoading({
      title: '上传中',
    })
    isUpload = true
    
    const pages = getCurrentPages()
    const prevPage = pages[pages.length - 2] // 上一页
    wx.uploadFile({
      url: wx.$api.upload_img,
      filePath: e.detail.url,
      name: 'file',
      formData: {
        'key': wx.$cache.get('key')
      },
      success: (res) => {
        wx.hideLoading({})
        // let data = JSON.parse(res.data)
        console.log(res)
        res = JSON.parse(res.data)
        // 调用上一个页面的setData 方法，将数据存储
        isUpload = false
        prevPage.setData({
          'img': res.datas.src,
        })



        wx.navigateBack();
      },

      complete: () => {
        wx.hideLoading({})
        isUpload = false
      }

    })


  },

  cropperload(e) {
    console.log("cropper初始化完成");
  },

  loadimage(e) {
    console.log("图片加载完成", e.detail);
    //重置图片角度、缩放、位置
    // this.cropper.imgReset();
  },
  clickcut(e) {
    console.log(e.detail);
    //点击裁剪框阅览图片
    wx.previewImage({
      current: e.detail.url, // 当前显示图片的http链接
      urls: [e.detail.url] // 需要预览的图片http链接列表
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  }
})