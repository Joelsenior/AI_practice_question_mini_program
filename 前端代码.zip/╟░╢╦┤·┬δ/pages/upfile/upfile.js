// pages/upfile/upfile.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
imgurl:wx.$imgurl,

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    options={
      lengths:6,
      key:wx.$cache.get('key')
    }
    this.setData({
      src: wx.$H5+'#' + options.lengths + '&' + options.key
    })
  },
  message(e){
    let pageArr = getCurrentPages();

    if(  wx.$cache.get('file')){
      let service_file= wx.$cache.get('service_file')
      e.detail.data[0].forEach(item=>{
        item.add_time=wx.$formatTime();
        item.file_type=item.fileType;
        item.url=item.src
        service_file.push(item)
       })
       wx.$cache.set('service_file',service_file)
    }else{
      let thisPage = pageArr[pageArr.length - 2]
      let service_file= thisPage.data.service_file;
   
      e.detail.data[0].forEach(item=>{
        item.add_time=wx.$formatTime();
        item.file_type=item.fileType;
        item.url=item.src
        service_file.push(item)
       })
       thisPage.setData({
         service_file,
       })
    }
   
  },
  
})