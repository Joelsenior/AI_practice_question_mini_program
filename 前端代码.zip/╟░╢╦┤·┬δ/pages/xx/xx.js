// PackageA/pages/xx/xx.js 
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sel: 1,
    errors_log: [], //报错反馈列表
    news_list: [], //系统消息列表
    my_subject_comment: [], //我的评论列表
    news_num:0,
    errors_sum:0,
    subject_sum:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
   
if(options.bc){
 this.sel({currentTarget:{dataset:{sel:2}}})
}
  
 
  },
  sel(e) {
    this.setData({
      sel: e.currentTarget.dataset.sel
    })
    if (e.currentTarget.dataset.sel == 1) {
      this.get_news_list();
    } else if (e.currentTarget.dataset.sel == 2) {
      this.get_errors_log()
    } else {
      this.get_my_subject_comment();
    }

    this.get_unread_news_num()
  },
  onShow() {
    if (typeof this.getTabBar === 'function' &&  this.getTabBar()) {
      this.getTabBar().setData({
        selected:wx.$cache.get('can').is_posts ==1? 2:1,
        is_posts:wx.$cache.get('can').is_posts
      })
    }
    this.get_unread_news_num()
    if (this.data.sel == 1) {
      this.get_news_list();
    } else if (this.data.sel == 2) {
      this.get_errors_log()
    } else {
      this.get_my_subject_comment();
    }
    
  },
  get_unread_news_num(){//获取消息数量
    if(!wx.$cache.get('majorInfo')){ 
      return
    }
  
    wx.$http.post(wx.$api.unread_news_num,{major_id:wx.$cache.get('majorInfo').id
    }).then( res => {
      console.log('resresresres',res)
      this.setData({
        news_num: res.news_num,   
        errors_sum:res.errors_sum,
        subject_sum:res.subject_sum
      })
    
    })
  },
  get_news_list() { //消息列表
    
    wx.$http.post(wx.$api.system_news_list, {
      is_all: 1,
      major_id: wx.$cache.get('majorInfo').id,
    }).then(res => {
  
      this.setData({
        news_list: res 
      })
    })
  },
 
  get_errors_log() { //报错反馈列表
    wx.$http.post(wx.$api.report_errors_log, {
      is_all: 1,
      major_id: wx.$cache.get('majorInfo').id,
    }).then(res => {
 
      this.setData({
        errors_log: res 
      })
    })
  },
  get_my_subject_comment() { //我的评论回复列表
    wx.$http.post(wx.$api.my_give_log, {
      is_all: 1
    }).then(res => { 
      
      this.setData({
        my_subject_comment: res 
      })
    })
  },
  toerrors_info() { //查看反馈详情
    wx.navigateTo({
      url: '/PackageA/Cpart/bcfkjl/bcfkjl',
    })
  },
  refresh() { //刷新评论点赞
    if (this.data.type == 1) {

      this.subject_commentlist()
    } else {
      this.subject_notelist()
    }
  },
  showNoteModal() { //打开评论
    this.setData({
      isShowModal: true
    })
  },
  closeModal() { //关闭组件
    this.setData({
      isShowModal: false,
      showRecordModal: false
    })
  },
  submitDiscussData(e) {//回复评论
    console.log(e.detail.note_content);
    let params = {
      subject_id: this.data.subject_id,

      content: e.detail.note_content
    }
    wx.$http.post(wx.$api.add_subject_comment, params).then(res => {
      console.log("评论成功");
      wx.showToast({
        title: '评论成功'
      })
      this.refresh()
      this.closeModal()
    })
  }, 
  tosubjectdetail(e) { //去题目详情
    // console.log('11111111','tosubjectdetail_'+e.currentTarget.dataset.id)

    // wx.setStorageSync('tosubjectdetail_'+e.currentTarget.dataset.id, e.currentTarget.dataset.id); // 将勾选状态存储到本地缓存
    wx.navigateTo({
        url: '/subPackageZ/pages/brush-topic/brush-topic?rand=0&collect=1&subject_id=' +e.currentTarget.dataset.subject_id,
    })
},
})