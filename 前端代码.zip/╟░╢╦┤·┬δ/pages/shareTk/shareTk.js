// pages/shareTk/shareTk.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id: 0,
    askIndex: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    if(!options.id) return wx.showToast({title: '题目不存在',icon: 'error'})
    this.setData({id: options.id},() => this.getDetail())
  },
  getDetail() {
    wx.$http.post(wx.$api.subject_info,{subject_id: this.data.id}).then(res => {
      this.setData({dataInfo: res})
    })
  },
  changeIndex(e) {
    this.setData({askIndex: e.currentTarget.dataset.index})
  },
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})