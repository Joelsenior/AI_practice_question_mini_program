import Poster from '../../Cpart/posterdist/poster/poster';

let app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        login: false,//是否调起登录，默认false
        userInfo: {},//用户信息对象
        bgSrc: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fku.90sjimg.com%2Fback_pic%2F03%2F58%2F71%2F8057a30a8ce6941.jpg&refer=http%3A%2F%2Fku.90sjimg.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1642084921&t=4f5be4028cc0f5e80eafe6b77631efea',//背景图
        checkInDate: '' || wx.$datetype(new Date()).day1,//开始日期
        checkInTime: '00:00',//开始时间
        checkInDate2: '',//开始时间戳
        checkOutDate: wx.$datetype(new Date()).day1,//结束日期
        checkOutTime: '12:00',//结束时间
        checkOutDate2: '',//结束时间戳
        //海报相关
        posterConfig: {
            width: 574,
            height: 715,
            pixelRatio:10,
            texts:[
                {
                    x:10,
                    y:200,
                    text:'哈宝说的就是',
                    fontSize:50
                }
            ],
            images: [
                {
                    x: 0,
                    y: 0,
                    url: '{{domain}}/img/popup_bg.png',
                    width: 574,
                    height: 715,
                },
                {
                    x: 284,
                    y: 335,
                    url: '{{domain}}/img/qrcode_23.png',
                    width: 207,
                    height: 206,
                },
            ]
        }
    },

    /**
     * 生命周期函数--监听页面加载
     */
    menberinfo: function (options) {
//直接调接口，登录会根据接口唤起，不另外处理
        wx.$http.post(wx.$api.get_member_info, {}).then(res => {
            console.log(res, '用户信息')
            wx.$cache.set('userInfo', res)
            wx.$cache.set('member_id', res.id)
            this.setData({
                userInfo: wx.$cache.get('userInfo') || ''
            })

        })
    },
    //返回生成海报图片的本地url
    onPosterSuccess(e) {
        const {detail} = e;
        wx.previewImage({
            current: detail,
            urls: [detail]
        })
    },
    /**
     * 异步生成海报
     */
    toupfile() {
        wx.navigateTo({
            url: '/pages/upfile/upfile',
        })
    },
    bindDateChange(e) {
        let {id} = e.target
        console.log(e)
        if (id == 1) {
            this.setData({
                checkInDate: e.detail.day.day3,
                checkInTime: e.detail.day.time4,
                checkInDate2: e.detail.lotterytime
            })
        } else {
            this.setData({
                checkOutDate: e.detail.day.day3,
                checkOutTime: e.detail.day.time4,
                checkOutDate2: e.detail.lotterytime
            })
        }
        this.setData({
            timenum: parseInt((this.data.checkOutDate2 - this.data.checkInDate2) / 86400000)
        })
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    tourl: function (e) {
        let id = e.currentTarget.id;
        if (id == 1) {
            app.content = 'http://wulihao_ct_09.mb.dlshtsy.net.cn/vip_wulihao_ct_09.html?notech=1'
            wx.navigateTo({
                url: '/pages/webview/webview?type=1&title=化妆品模板',
            })
        } else {
            app.content = wx.$cache.get('can').notice_content
            wx.navigateTo({
                url: '/pages/webview/webview?type=2&title=公告',
            })
        }
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        this.getTabBar().setData({
            selected: 1,

        })
        if (wx.$cache.get('userInfo')) {
            this.menberinfo();
        }
    },
    editmenber() {
        wx.navigateTo({
            url: '/pages/about-my/about-my',
        })
    }
})