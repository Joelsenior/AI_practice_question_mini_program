// pages/list/index.js
let app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        back: "<",


        nickname: '',

    },


    tapimg() {
        wx.chooseImage({
            count: 1,
            sizeType: ['original', 'compressed'],
            sourceType: ["album", "camera"],
            success: function (t) {
                wx.navigateTo({
                    url: '/pages/cropperImage/cropperImage?imageUrl=' + t.tempFilePaths[0],
                })
            }
        })
    },
    onLoad: function (options) {

        this.setData({
            img: wx.$cache.get('userInfo').img,
            nickname: wx.$cache.get('userInfo').nickname
        })
    },
    submit() {
        wx.$http.post(wx.$api.edit_member, this.data).then(res => {
            wx.navigateBack({
                delta: 0,
            })
        })
    },


})