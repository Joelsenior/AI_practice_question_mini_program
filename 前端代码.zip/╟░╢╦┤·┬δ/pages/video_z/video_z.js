var app = getApp()
Page({
  data: {
    src: "",
    is_show: 0,
    is_qrcode: 0,
    is_set: 0,
    set1: 0,
    set2: 0,
    set3: 0,
    bannerData: [],
    majorList: [],
    selectMajorInfo: {},
    config: {},
    locallist: [
      {
        PraiseNum:"3",
        cookbookcode:"C32909584",
        cookbookid:"37",
        cookbookname: "香蕉巧克力冷燕麦",
        coverpicpath:"../../image/list/list.jpg"
      },
      {
        PraiseNum: "3",
        cookbookcode: "C32909584",
        cookbookid: "37",
        cookbookname: "香蕉巧克力冷燕麦",
        coverpicpath: "../../image/list/list.jpg"
      },
      {
        PraiseNum: "3",
        cookbookcode: "C32909584",
        cookbookid: "37",
        cookbookname: "香蕉巧克力冷燕麦",
        coverpicpath: "../../image/list/list.jpg"
      },
      
    ],//模拟网络访问数据
    searchSongList: [], //放置返回数据的数组  
    searchPageNum: 1,   // 设置加载的第几次，默认是第一次  
    searchLoading: false, //"上拉加载"的变量，默认false，隐藏  
    searchLoadingComplete: false  //“没有数据”的变量，默认false，隐藏  
  },
  close() {
    this.setData({
      is_show: 0,
    })
  },
  sel_zy() {
    this.setData({
      is_show: 1
    })
  },
  getMajorInfo(e) {
    console.log("e.currentTarget.dataset.item",e.currentTarget.dataset.item)
    this.setData({
      selectMajorInfo: e.currentTarget.dataset.item,
      is_show: 0,
      searchPageNum:1 //重置分页
    })
    wx.$cache.set("majorInfo",e.currentTarget.dataset.item)
    this.onInit()
    this.get_unread_news_num();
    //更新存储专业ID
    this.setUserSetting({major_id:e.currentTarget.dataset.item.id})
    this.fetchSearchList();
    
  },
  get_unread_news_num(){//获取消息数量
    if(!wx.$cache.get('majorInfo')){ 
      return
    }
  
    wx.$http.post(wx.$api.unread_news_num,{major_id:wx.$cache.get('majorInfo').id
    }).then( res => {
  
      if (typeof this.getTabBar === 'function' &&  this.getTabBar()) {
        this.getTabBar().setData({ 
          is_xiaoxi: res.total >0 ?1 :0,
          xiaoxi_sum:res.total
        })
      }
    })
  },


  setUserSetting(params) { 
    return new Promise((resolve,reject) => {
      wx.$http.post(wx.$api.edit_member,params).then(e => {
        wx.$http.post(wx.$api.get_member).then(res => {
          wx.$cache.set('userinfo',res)
          wx.showToast({title: '操作成功'})
          resolve(e)
        })
      })
    })
  },
  // 首次加载
  onLoad: function () {
    this.setData({
      src: "https://kodo.seniorfd.com/image/img_box.jpg"
    }) 
    let that = this;
    that.onInit()
    this.getMajorData()

  

  },
  onInit() {
    if(!wx.$cache.get('can')) {
      setTimeout(() => {
        this.onInit()
      }, 1000);
      return false
    }
    this.setData({config: wx.$cache.get('can')},() => {
      var startTime = wx.$cache.get('can').postgraduate_time;
    var s1 = new Date(startTime.replace(/-/g, "/")),
    s2 = new Date(),
    runTime = parseInt((s1.getTime()-s2.getTime()) / 1000);
  
    var day = Math.floor(runTime / 86400);
    
      this.setData({ 'config.day': day })
    }) 
  },
  getMajorData() {

    wx.$http.post(wx.$api.major_list,{}).then( res => {
      this.setData({
        majorList: res, 
        // is_show: this.data.selectMajorInfo.id ? 0 : 1
      })
      if(wx.$cache.get('majorInfo')) {
   
      res.forEach(item=>{if(item.id==wx.$cache.get('majorInfo').id){
      
        this.setData({
          selectMajorInfo: item, 
         
        })
      }
      })
    }
    this.fetchSearchList();
    })
  },
  onShow() {
    if (typeof this.getTabBar === 'function' &&  this.getTabBar()) {
      this.getTabBar().setData({
        selected:1,
        is_posts:wx.$cache.get('can').is_posts
      })
    }
    if(wx.$cache.get('userinfo')) {this.setData({'userInfo': wx.$cache.get('userinfo')})
      this.get_unread_news_num();
    }
 
  },
  // 搜索，访问网络  
  fetchSearchList: function () {
    let that = this;
    let searchPageNum = that.data.searchPageNum//把第几次加载次数作为参数 
     
    let params = {}
    if(this.data.selectMajorInfo.id) params.major_id = this.data.selectMajorInfo.id
    params.page_size =15
    params.page=searchPageNum
    wx.$http.post(wx.$api.get_z_list,params).then( res => {
    
      if (res.length != 0) {
      //  let searchList = [];
        //拼接数组
       // searchList = that.data.searchSongList.concat(res);
        that.setData({
          searchSongList: res, //获取数据数组  
          searchLoading: false,   //把"上拉加载"的变量设为true，显示  
          searchLoadingComplete:false
        });
        //console.log("eeee",searchList)
      } else {
        that.setData({
          searchSongList: [],
          searchLoadingComplete: true, //把“没有数据”设为true，显示  
          searchLoading: false  //把"上拉加载"的变量设为false，隐藏  
        });
      }
   
    })
 
  
    wx.hideLoading()

     
  },

  //滚动到底部触发事件  
  searchScrollLower: function () {
    console.log(111111111111)
    let that = this;
    if (that.data.searchLoading && !that.data.searchLoadingComplete) {
      that.setData({
        searchPageNum: that.data.searchPageNum + 1,  //每次触发上拉事件，把searchPageNum+1  
        searchLoading: false
      });
      that.fetchSearchList();
    }
  }
})  