// PackageA/pages/index/index.js
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    src: "",
    is_show: 0,
    is_qrcode: 0,
    is_set: 0,
    set1: 0,
    set2: 0,
    set3: 0,
    bannerData: [],
    majorList: [],
    selectMajorInfo: {},
    config: {},
    news_num:0,//消息数
  },
  //跳官网小程序
  togw(){
    // wx.navigateToMiniProgram({
    //   appId: 'wxbf766cfc7cca4af7',
    // })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  set() {
    this.setUserSetting({is_music: this.data.set1 == 1 ? 2 : 1}).then(e => {
      this.setData({set1: this.data.set1 == 1 ? 2 : 1})
    })
   
  },
  set1() {
    this.setUserSetting({is_display_answer: this.data.set2 == 1 ? 2 : 1}).then(e => {
      this.setData({set2: this.data.set2 == 1 ? 2 : 1})
    })
  },
  set2() {
    this.setUserSetting({is_automatic: this.data.set3 == 1 ? 2 : 1}).then(e => {
      this.setData({set3: this.data.set3 == 1 ? 2 : 1})
    })
  },
  set3() {
    this.setUserSetting({is_dark: this.data.set4 == 1 ? 2 : 1}).then(e => {
      this.setData({set4: this.data.set4 == 1 ? 2 : 1})
    })
  },
  show_m() {
    this.setData({
      is_qrcode: 1
    })
  },
  toxx(){//查看消息
wx.navigateTo({
  url: '/PackageA/pages/xx/xx',
})
  },
  tocommunity(){//去研友圈
wx.navigateTo({
  url: '/friend/circle/circle',
})
  },
  setUserSetting(params) { 
    return new Promise((resolve,reject) => {
      wx.$http.post(wx.$api.edit_member,params).then(e => {
        wx.$http.post(wx.$api.get_member).then(res => {
          wx.$cache.set('userinfo',res)
          wx.showToast({title: '操作成功'})
          resolve(e)
        })
      })
    })
  },
  close() {
    this.setData({
      is_show: 0,
      is_qrcode: 0,
      is_set: 0
    })
  },
  sel_zy() {
    this.setData({
      is_show: 1
    })
  },
  onLoad(options) {
  
    this.setData({
      src: "https://kodo.seniorfd.com/image/img_box.jpg"
    })
   
    this.onInit()
    this.getMajorData()
  },
  onInit() {
    if(!wx.$cache.get('can')) {
      setTimeout(() => {
        this.onInit()
      }, 1000);
      return false
    }
    this.setData({config: wx.$cache.get('can')},() => {
      var startTime = wx.$cache.get('can').postgraduate_time;
    var s1 = new Date(startTime.replace(/-/g, "/")),
    s2 = new Date(),
    runTime = parseInt((s1.getTime()-s2.getTime()) / 1000);
  
    var day = Math.floor(runTime / 86400);
    
      this.setData({ 'config.day': day })
    })
    
    this.getTabBar().setData({
      is_posts:wx.$cache.get('can').is_posts
    })

    this.getBannerData()
  },
  getBannerData() {
    let params = {}
    if(this.data.selectMajorInfo.id) params.major_id = this.data.selectMajorInfo.id
    wx.$http.post(wx.$api.get_banner,params).then( res => {
      this.setData({ bannerData: res})
    })
  },
  getMajorData() {
    wx.$http.post(wx.$api.major_list,{}).then( res => {
      this.setData({
        majorList: res, 
        // is_show: this.data.selectMajorInfo.id ? 0 : 1
      })
      if(wx.$cache.get('majorInfo')) {
      res.forEach(item=>{if(item.id==wx.$cache.get('majorInfo').id){
        this.setData({
          selectMajorInfo: item, 
         
        })
      }
      })
    }
    })
  },
    // 轮播图跳转
    gonewBanner(e) {
      console.log(e);
      var that = this;
      var looplist = that.data.bannerData;
      var index = e.currentTarget.dataset.index;
      console.log(looplist);
      if (looplist[index].target == "utside") {
        app.globalData.content = looplist[index].url;
        wx.navigateTo({
          url: '/pages/webview/webview?type=1&title=' + looplist[index].title + '&url=' + looplist[index].url,
        })
      } else {
        if (looplist[index].applets_page_is_tabbar == 1) {
          console.log(looplist[index].applets_page_path)
          wx.switchTab({
            url: looplist[index].applets_page_path,
          })
        } else if(looplist[index].target =='self') {
          if (looplist[index].parameter) {
            wx.navigateTo({
              url: looplist[index].applets_page_path + '?' + looplist[index].parameter+'&'+looplist[index].applets_page_parameter,
            })
          } else {
            wx.navigateTo({
              url: looplist[index].applets_page_path,
            })
          }
        }else{
          wx.navigateToMiniProgram({
            appId: looplist[index].app_id, // 要跳转的小程序的appid
            path: looplist[index].path+'?'+looplist[index].parameter, // 跳转的目标页面
            extarData: {
              open: 'auth'
            },
            envVersion: 'release',
            success(res) {
              // 打开成功
            }
          })
        }
      }
    },
  getMajorInfo(e) {
    console.log("e.currentTarget.dataset.item",e.currentTarget.dataset.item)
    this.setData({
      selectMajorInfo: e.currentTarget.dataset.item,
      is_show: 0
    })
    wx.$cache.set("majorInfo",e.currentTarget.dataset.item)
    this.onInit()
    this.get_unread_news_num();
    //更新存储专业ID
    this.setUserSetting({major_id:e.currentTarget.dataset.item.id})
  },
  jumpTo(e) {
    const { url } = e.currentTarget.dataset
    if(!wx.$cache.get('userinfo')?.id) {
      wx.navigateTo({url: '/pages/login/login'})
      return false
    }
    //触发订阅消息  
    wx.requestSubscribeMessage({
      tmplIds: ["8LIraQUVf5ZnZ6LjEYj-01sW-JxiQJ6tm80j9ewRGt4"],
    })

    if(!wx.$cache.get('majorInfo')?.id) return this.setData({is_show: true})
    wx.navigateTo({
      url: url,
    })
  },
  showQrcode() {
    if(wx.$cache.get('majorInfo')) {
      this.setData({ is_qrcode: true })
    }
  },
  openSetModal() {
    if(wx.$cache.get('userinfo')?.id) {
      this.setData({
        is_set: 1,
        set1: wx.$cache.get('userinfo').is_music,
        set2: wx.$cache.get('userinfo').is_display_answer,
        set3: wx.$cache.get('userinfo').is_automatic,
        set4: wx.$cache.get('userinfo').is_dark,
      })
    } else {
      wx.navigateTo({
        url: '/pages/login/login',
      })
    }
  },
  saveImageBtn() {
    wx.downloadFile({
      url: this.data.selectMajorInfo.qrcode_img,
      success(res) {
        wx.saveImageToPhotosAlbum({
          filePath: res.tempFilePath,
        })
      }
    })
  },
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    if (typeof this.getTabBar === 'function' &&  this.getTabBar()) {
      this.getTabBar().setData({
        selected:0
      })
    }

    if(wx.$cache.get('userinfo')) {this.setData({'userInfo': wx.$cache.get('userinfo')})
    this.get_unread_news_num();
    }
  },
  get_unread_news_num(){//获取消息数量
  wx.$http.post(wx.$api.unread_news_num,{major_id:this.data.selectMajorInfo.id
  }).then( res => { 
 
    if (typeof this.getTabBar === 'function' &&  this.getTabBar()) {

    
      this.getTabBar().setData({ 
        is_xiaoxi: res.total >0 ?1 :0,
        xiaoxi_sum:res.total
      })
    }
  })
},

  onShareAppMessage() {
    return{
      title:wx.$cache.get('share').title,
      imageUrl:wx.$cache.get('share').img,
      path:`/pages/index/index?pid=${wx.$cache.get('member_id')||0}`
    }
  }
})