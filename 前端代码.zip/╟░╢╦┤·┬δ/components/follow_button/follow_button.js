// components/follow_button/follow_button.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    uid:{
      type:String|Number,
      value: 0
    },
    is_follow: {
      type: String|Number,
      value: 1
    },
    showButton: {
      type:Boolean,
      value: true
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    my_uid: wx.$cache.get('member_id')
  },
  attached(){
    this.setData({my_uid:wx.$cache.get('member_id')})
  },
  methods: {
    FollowMember(){
      wx.$http(wx.$get.posts_follow_member,{show_member_id: this.properties.uid}).then(res=>{
        if(this.properties.is_follow == 1){
          wx.showToast({title: '已取消关注',icon:'none'})
        }else{
          wx.showToast({title: '关注成功',icon:'none'})
        }
        this.triggerEvent('follow',this.properties.is_follow,{})
      })
    }
  }
})
