/**
 * 输入组件
 */
Component({
    properties: {
        placeholder: {
            type: String,
            value: '记录笔记'
        },
        isDiscuss: {
            type: Boolean,
            value: false
        },
        pattern: {
            type: Boolean,
            value: false
        },
        //是否暗黑模式
        isDark: {
            type: Boolean,
            value: false
        },
        olddata: {
            type: Object,
            value: {}
        },
    },
    data: {
        keyBoardHeight: 0,
        type: 0, //  [0,1,2] 0=>文字，1=>图像，2=>语音
        imageList: [],
        audioInfoTempPath: '',
        audioDuration: 0,
        inputText: '',
        pubState: true
    },
    // observers
    lifetimes: {
        attached() {
           
            this.addKeyboardListener()
        }
    },
    observers: {
      'olddata': function (val) {
        var olddata = this.data.olddata
        if (olddata.id){
        if (!this.data.pattern) {
          let imageList = []
          if (olddata.note_type == 2) {
              olddata.note_imgs.forEach(item => {
                  imageList.push({
                      src: item,
                      url: item.replace('https://stapi.seniorfd.com', '')
                  })
              })
          }
      
          console.log('修改')
          this.setData({
              type: olddata.note_type - 1,
              inputText:olddata.note_type==1?olddata.note_content:'',
              imageList: olddata.note_type==2?imageList:[],
              audioInfoTempPath:olddata.note_type==3?olddata.note_audio:'',
              audioDuration:olddata.note_type==3?olddata.note_audio_time:0,
              pubState:olddata.is_public==1?true:false,
          })
        }else{
          let imageList = []
          if (olddata.answer_type == 2) {
              olddata.answer_content.forEach(item => {
                  imageList.push({
                      src: item,
                      url: item.replace('https://stapi.seniorfd.com', '')
                  })
              })
          }
      
          console.log('还原答案')
          this.setData({
              type: olddata.answer_type - 1,
              inputText: olddata.answer_type==1?olddata.answer_content:'',
              imageList: olddata.answer_type==2?imageList:[],
              audioInfoTempPath:olddata.answer_type==3?olddata.answer_content:'',
              audioDuration:olddata.answer_type==3?olddata.answer_audio_s:0,
              // pubState:olddata.is_public==1?true:false,
          })
        }
      }

      }
  },
    pageLifetimes: {
        show() {
            this.addKeyboardListener()
        }
    },
    methods: {
      inputtxt(e){
        console.log(e.detail.value)
        this.setData({
          inputText:e.detail.value
        })
      },
        empty() {
          console.log('清空了')
            this.setData({
                type: 0, //  [0,1,2] 0=>文字，1=>图像，2=>语音
                imageList: [],
                audioInfoTempPath: '',
                audioDuration: 0,
                inputText: '',
            })
        },
        addKeyboardListener() {
            console.log("开始监听键盘的事件");
            wx.onKeyboardHeightChange((result) => {
                this.setData({
                    keyBoardHeight: result.height
                })
            })
        },
        changeTypeHandle(e) {
            this.setData({
                type: e.currentTarget.dataset.type
            })
        },
        changePubState(e) {
            this.setData({
                pubState: e.detail.value
            })
        },
        getAudioInfo(e) {
            console.log(e.detail);
            this.setData({
                audioInfoTempPath: e.detail.tempFilePath,
                audioDuration: Math.ceil(e.detail.duration / 1000)
            })
        },
        skip() { //不会跳过，加入错题本
            this.triggerEvent('skip', {})
        },
        closeModal(e) {
            this.triggerEvent('close', {}, {})
        },
        clickHandle(e) {
            let triggerData = {
                note_type: (Number(this.data.type) + 1),
                is_public: this.data.pubState ? 1 : 2
            }
            if(this.data.olddata?.id >0)triggerData.note_id=this.data.olddata.id
            if (this.data.type == 0) triggerData.note_content = this.data.inputText
            if (this.data.type == 1) triggerData.note_imgs = this.data.imageList
            if (this.data.type == 2) {
                triggerData.note_audio_time = this.data.audioDuration
                triggerData.note_audio = this.data.audioInfoTempPath
                const _this = this;
                if(triggerData.note_audio.indexOf('https://stapi.seniorfd.com')==-1){
                wx.uploadFile({
                    filePath: this.data.audioInfoTempPath,
                    name: 'file',
                    formData: {
                        'key': wx.$cache.get('key')
                    },
                    url: wx.$api.upload_file,
                    success(res) {
                        res = JSON.parse(res.data)
                        triggerData.note_audio = res.datas.url
                        _this.triggerEvent('submit', triggerData)
                    }
                })
              }else{
                _this.triggerEvent('submit', triggerData)
              }
            }
            if (this.data.type != 2) this.triggerEvent('submit', triggerData)
        },
        doexercise(e) {
            let triggerData = {
                note_type: (Number(this.data.type) + 1),
                is_public: this.data.pubState ? 1 : 2
            }
            if (this.data.type == 0) triggerData.note_content = this.data.inputText
            if (this.data.type == 1) triggerData.note_imgs = this.data.imageList
            if (this.data.type == 2) {
                triggerData.note_audio_time = this.data.audioDuration
                triggerData.note_audio = this.data.audioInfoTempPath
                const _this = this;
                if(this.data.audioInfoTempPath&&triggerData.note_audio.indexOf('https://stapi.seniorfd.com')==-1){
                wx.uploadFile({
                    filePath: this.data.audioInfoTempPath,
                    name: 'file',
                    formData: {
                        'key': wx.$cache.get('key')
                    },
                    url: wx.$api.upload_file,
                    success(res) {
                        res = JSON.parse(res.data)
                        triggerData.note_audio = res.datas.url
                        _this.triggerEvent('submit', triggerData)
                    }
                })
            }else{
                _this.triggerEvent('submit', triggerData)
            }
            }
            if (this.data.type != 2) this.triggerEvent('submit', triggerData)
        },
        removeImage(e) { //删除图片
            this.setData({
                imageList: this.data.imageList.filter(value => value.src != e.currentTarget.dataset.item.src)
            })
        },
        uploadImageFile() { //上传图片
            const _this = this;
            wx.chooseMedia({
                mediaType: 'image',
                count: 9 - this.data.imageList.length,
                success(e) {
                    const tempFiles = e.tempFiles
                    let taskList = []
                    tempFiles.forEach(value => taskList.push(_this.uploadImageFunction(value.tempFilePath)))
                    Promise.all(taskList).then(res => {
                        _this.setData({
                            imageList: [..._this.data.imageList, ...res]
                        })
                    })
                }
            })
        },
        previewImg(e) { //预览图片
          console.log(e)
          wx.previewImage({
            urls: e.currentTarget.dataset.url,
            current:e.currentTarget.dataset.current,
          })
        },
        deleteaudio(){
          this.setData({
            audioInfoTempPath: '',
            audioDuration: 0,
          })
        },
        uploadImageFunction(tempPath) { //上传图片
            return new Promise((resolve, _reject) => {
                wx.showLoading({
                    title: '上传图片中...',
                    mask: true
                })
                wx.uploadFile({
                    filePath: tempPath,
                    name: 'file',
                    formData: {
                        'key': wx.$cache.get('key')
                    },
                    url: wx.$api.upload_img,
                    success(res) {
                        res = JSON.parse(res.data)
                        wx.hideLoading()
                        resolve(res.datas)
                    }
                })
            })
        }
    }
})