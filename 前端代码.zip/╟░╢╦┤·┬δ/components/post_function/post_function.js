// components/post_function/post_function.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    showModal:{
      type:Boolean,
      value: false
    },
    postData: {
      type: Object,
      value: {}
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    show: false,
  },
  observers:{
    'showModal':function(newVal){
      this.setData({show: newVal})
    },
    'show':function(newVal){
      console.log(newVal)
      // if(newVal){
      //   this.animation.scale(1).step({duraion: 300})
      //   this.setData({animation:this.animation.export()})
      // }else{
      //   this.animation.scale(0).step()
      //   this.setData({animation:this.animation.export()})
      // }
    }
  },
  attached(){
    this.animation = wx.createAnimation({
      scale: 0
    })
  },
  methods: {
    onEnter(){},
    deletePost(){
      const _this = this;
      wx.showModal({
        content: "确认删除吗？",
        success(res){
          if(res.confirm){
            wx.$http(wx.$get.del_posts,{posts_id:_this.properties.postData.id}).then(res=>{
              wx.showToast({title: '操作成功',icon:"none"})
              _this.triggerEvent('delete',_this.properties.postData,{})
            })
          }
        }
      })
    },
    editPost(){
      const _this = this;
      wx.navigateTo({
        url: '/friend/report/repor',
        events: {
          editSuccess:function(res){
            _this.triggerEvent('edit',res,{})
          }
        },
        success(res){
          res.eventChannel.emit('editInfo', _this.properties.postData)
        }
      })
    },
    closeModal(){
      this.setData({show: false})
    }
  }
})
