/**
 * 录音组件
 * time Number 录音时长
 * result Function getAudio 通过bindgetAudio事件返回地址和时长音频大小
 */
let recorderManager = wx.getRecorderManager()
let myAudio = wx.createInnerAudioContext();
let timer = null
Component({
  properties: {
    time: {
      type: Number,
      value: 180
    },
     //是否暗黑模式
     isDark: {
      type: Boolean,
      value: false
    }
  },
  data: {
    record_state: 'ready',  //  [ready,playing,pause,stop]  录音状态
    play_time: 0, //  录制时长
    isReStart: false, //  是否为重新录制，【重录时不触发组件的回调】
  },
  lifetimes: {
    attached() {
      console.log("录音组件开始加载");
      recorderManager.onStart(() => this.recorderManagerStart())
      recorderManager.onPause(() => this.recorderManagerPause())
      recorderManager.onResume(() => this.recorderManagerResume())
      recorderManager.onStop((e) => this.recorderManagerStop(e))
    }
  },
  methods: {
    recorderManagerStart() {
      this.setData({record_state: 'playing', isReStart: false},() => {
        timer = setInterval(()=>{
          this.setData({play_time: this.data.play_time + 1})
        },1000)
      })
    },
    recorderManagerPause() {
      console.log("录音暂停");
      this.setData({record_state: 'pause'},() => {
        if(timer) (clearInterval(timer),timer = null)
      })
    },
    recorderManagerResume() {
      console.log("录音继续");
      // 经试验发现会调用两次resume的逻辑，判断状态避免重复调用
      if(this.data.record_state == 'pause') this.setData({record_state: 'playing'},() => {
        timer = setInterval(()=>{
          this.setData({play_time: this.data.play_time + 1})
        },1000)
      })
    },
    recorderManagerStop(e) {
      console.log("录音停止");
      this.setData({record_state: 'stop'},() => {
        if(timer) (clearInterval(timer),timer = null)
        if(!this.data.isReStart) {
          // let emitData = {}
          // emitData.path = e.tempFilePath,
          // myAudio.src = emitData.path
          // myAudio.onCanplay(()=> {
          //   myAudio.duration
          //   setTimeout(() => {
          //     console.log(myAudio.duration); // 401.475918
          //   }, 500)
          // })
          this.triggerEvent('getAudio',e)
        }
      })
    },
    // 重新录音
    refreshRecord() {
      recorderManager.pause()
      const _this = this;
      wx.showModal({
        title: '提示',
        content: '确定要重新录制吗？',
        success(res) {
          if(res.confirm) {
            _this.setData({isReStart: true})
            recorderManager.stop()
            _this.setData({play_time: 0})
            recorderManager.start({duration: _this.properties.time * 1000,format: 'mp3'})
          }
        }
      })
    },
    onBtnClickHandle: function() {
      console.log(5555)
      if(this.data.record_state == 'ready') {
        recorderManager.start({duration: this.properties.time * 1000,format: 'mp3'})
      }
      if(this.data.record_state == 'playing') {
        recorderManager.pause()
      }
      if(this.data.record_state == 'pause') {
        recorderManager.resume()
      }
      if(this.data.record_state == 'stop') {
        this.setData({isReStart: true})
        recorderManager.stop()
        this.setData({play_time: 0})
        recorderManager.start({duration: this.properties.time * 1000,format: 'mp3'})
      }
    },
    stopAudio() {
      recorderManager.stop()
    }
  }
})
