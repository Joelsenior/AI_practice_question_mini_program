// component/post_item/post_item.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    showFunction: {
      type: Boolean,
      value: true
    },
    postData: {
      type: Object,
      value: {}
    },
    uid: {
      type: Number|String,
      value: 0
    },
    showButton: {
      type: Boolean,
      value: true
    },
    showSeeNum: {
      type: Boolean,
      value: false
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    shareAction(){
      console.log("分享")
      this.triggerEvent('share',this.properties.postData,{})
    },
    thumbsAction(){
      console.log("点赞事件")
      wx.$http.post(wx.$get.posts_give_member,{type:1,log_id:this.properties.postData.id}).then(res=>{
        let data = this.properties.postData;
        if(data.is_give == 1){
          data.is_give = 2;
          data.give_num--;
          this.triggerEvent('thumb',data)
        }else{
          data.is_give = 1;
          data.give_num++;
          this.triggerEvent('thumb',data)
        }
      })
    },
    followAction(){
      let data = this.properties.postData;
      data.is_follow = data.is_follow == 1 ? 2 : 1;
      this.triggerEvent('thumb',data)
      this.triggerEvent('follow',data)
    },
    moreAction(){
      this.triggerEvent('ShowMore',this.properties.postData,{})
    },
    preViewImage(e){
      wx.previewImage({
        urls: e.currentTarget.dataset.imgs,
        current:e.currentTarget.dataset.item
      })
    },
    goUserCenter(){
      wx.navigateTo({
        url: '/friend/user/user?uid='+this.properties.postData.member_id,
      })
    },
    goTopic(){
      wx.navigateTo({
        url: '/friend/topic/topic?text='+this.properties.postData.topic,
      })
    }
  }
})
