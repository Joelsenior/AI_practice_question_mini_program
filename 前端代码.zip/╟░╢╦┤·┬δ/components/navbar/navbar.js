// component/navbar/navbar.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    fixed: {
      type: Boolean,
      value: false
    },
    placeholder: {
      type: Boolean,
      value: false
    },
    title: {
      type: String,
      value: "首页"
    },
    opacity: {
      type: Number||String,
      value: 1 
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    statusBarHeight: 0,
    navH: 0
  },
  lifetimes: {
  attached(){
    const {statusBarHeight} = wx.getSystemInfoSync()
    const menu = wx.getMenuButtonBoundingClientRect()
    const navigationBar = (menu.top - statusBarHeight) * 2 + menu.height
    this.setData({statusBarHeight:statusBarHeight,navH:navigationBar})
    console.log(statusBarHeight,navigationBar,'222222222222222')
  },
},
  methods: {
    navback(){
      wx.navigateBack({
        fail(res){
          wx.redirectTo({
            url: '/pages/index/index',
          })
        }
      })
    }
  }
})
