/**
 * 音频播放组件
 * 单例化一个播放对象，保证只会有一个播放实例
 * [mp-weixin] 共享播放的ID，实现监听数据后改变播放的状态
 * 
 * url String 音频播放地址
 * duration Number 音频播放时长
 * type String [record,title]  类型，录音或标题，默认record
 * color String  [info,primary,danger]  当type=title时的颜色显示
 * isDark Boolean 是否为暗黑模式
 * answerText String 显示的文字[A、B、C、D]
 */
import { singleton } from "../../utils/audio-singleton"
import '../../utils/mp-weixin'

// 全局播放对象
var globalAudioPlayer = singleton.getInstance().myAudio
// 共享数据，同步所有使用中组件播放的ID
const mixins = {
  store: wx.createStore({playerAudioId: ''})
}
Component({
  mixin: mixins,
  properties: {
    url: {
      type: String,
      value: ''
    },
    duration: {
      type: Number|String,
      value: 0
    },
    type: {
      type: String,
      value: 'record'
    },
    color: {
      type: String,
      value: 'info'
    },
    isDark: {
      type: Boolean,
      value: false
    },
    answerText: {
      type: String,
      value: 'A'
    }

  },
  lifetimes: {
    detached: function() {
      this.stopVideo()
    }
  },
  pageLifetimes: {
    hide: function() {
      this.stopVideo()
    }
  },
  observers: {
    'duration': function(val) {
      if(val) this.setData({audio_duration: val})
    },
    'playerAudioId': function(val) {
      if(val !== this.data.componentAudioUUid) this.setData({ video_is_play: false })
      else this.setData({ video_is_play: true })
    },
    'color': function(val) {
      if(val == 'info' && (!this.properties.isDark)) this.setData({themeConfig: {backgroundColor: '#FFF', borderColor: '#F2F2F2', primaryColor: '#000', infoColor: '#333'}})
      if(val == 'primary' && (!this.properties.isDark)) this.setData({themeConfig: {backgroundColor: '#FFF', borderColor: '#406BFE', primaryColor: '#406BFE', infoColor: '#406BFE'}})
      if(val == 'danger' && (!this.properties.isDark)) this.setData({themeConfig: {backgroundColor: '#FFF', borderColor: '#FF3C2C', primaryColor: '#FF3C2C', infoColor: '#FF3C2C'}})
      if(val == 'info' && (this.properties.isDark)) this.setData({themeConfig: {backgroundColor: '#202125', borderColor: '#FFFFFF', primaryColor: '#FFF', infoColor: '#FFF'}})
      if(val == 'primary' && (this.properties.isDark)) this.setData({themeConfig: {backgroundColor: 'rgba(64,107,254,0.2)', borderColor: 'rgba(64,107,254,0.5)', primaryColor: '#406BFE', infoColor: '#406BFE'}})
      if(val == 'danger' && (this.properties.isDark)) this.setData({themeConfig: {backgroundColor: 'rgba(255,60,44,0.2)', borderColor: 'rgba(255,60,44,0.5)', primaryColor: '#FF3C2C', infoColor: '#FF3C2C'}})
    },
    'isDark': function(val) {
      if((!val) && this.properties.color == 'info') this.setData({themeConfig: {backgroundColor: '#FFF', borderColor: '#F2F2F2', primaryColor: '#000', infoColor: '#333'}})
      if((!val) && this.properties.color == 'primary') this.setData({themeConfig: {backgroundColor: '#FFF', borderColor: '#406BFE', primaryColor: '#406BFE', infoColor: '#406BFE'}})
      if((!val) && this.properties.color == 'danger') this.setData({themeConfig: {backgroundColor: '#FFF', borderColor: '#FF3C2C', primaryColor: '#FF3C2C', infoColor: '#FF3C2C'}})
      if(val && this.properties.color == 'info') this.setData({themeConfig: {backgroundColor: '#202125', borderColor: '#FFFFFF', primaryColor: '#FFF', infoColor: '#FFF'}})
      if(val && this.properties.color == 'primary') this.setData({themeConfig: {backgroundColor: 'rgba(64,107,254,0.2)', borderColor: 'rgba(64,107,254,0.5)', primaryColor: '#406BFE', infoColor: '#406BFE'}})
      if(val && this.properties.color == 'danger') this.setData({themeConfig: {backgroundColor: 'rgba(255,60,44,0.2)', borderColor: 'rgba(255,60,44,0.5)', primaryColor: '#FF3C2C', infoColor: '#FF3C2C'}})
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    video_is_play: false,   //  音频是否在播放
    audio_duration: 0,      //  音频时长
    componentAudioUUid: '',  //  播放的uuid，每次播放时都会重置一个新的uuid，监听全局的uuid是否和当前的uuid一致，不一致时切换为停止播放
    themeConfig: {
      backgroundColor: '#FFF',  //  背景色
      borderColor: '#F2F2F2',   //  边框色
      primaryColor: '#000',     //  主字体色
      infoColor: '#333',        //  次级字体色
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    playVideo() {
      const tempUuid = Math.random().toString(36).slice(2)
      this.setData({
        playerAudioId: tempUuid,
        componentAudioUUid: tempUuid
      })
      globalAudioPlayer.stop();
      globalAudioPlayer.src = this.properties.url
      globalAudioPlayer.play();
      globalAudioPlayer.onEnded(() => {
        console.log("停止事件");
        this.stopVideo()
      })
    },
    stopVideo() {
      console.log("触发停止播放");
      globalAudioPlayer.pause();
      this.setData({
        video_is_play: false
      });
    },
    changePlayState() {
      if(this.data.video_is_play) this.stopVideo()
      else this.playVideo()
    }
  },
})