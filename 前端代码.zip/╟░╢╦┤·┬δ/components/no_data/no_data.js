// components/no_data/no_data.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    image:{
      type:String,
      value:'https://vkceyugu.cdn.bspapp.com/VKCEYUGU-a3de8068-5f32-47fa-96a3-87a03db5d0d4/906a7296-bb97-4174-a47b-c380ee7d0eb3.png'
    },
    text:{
      type:String,
      value:'数据为空~'
    },
    show:{
      type:Boolean,
      value: false
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
