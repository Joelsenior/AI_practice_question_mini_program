// components/load_text/load_text.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    show:{
      type:Boolean,
      value: false
    },
    // loadState: "loadmore", //  ['loadmore','loading','nomore']
    loadState: {
      type: String,
      value: "loadmore"
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    loadText: {
      loadmore: '上拉加载更多~',
      loading: '正在加载中...',
      nomore: '没有更多了'
    },
  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
