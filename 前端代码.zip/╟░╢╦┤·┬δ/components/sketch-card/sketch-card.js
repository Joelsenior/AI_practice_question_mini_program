// components/sketch-card/sketch-card.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    type: {
      type: String,
      value: 'discuss'  //  [discuss=评论，note=>笔记]
    },
    item: {
      type: Object,
      value: {}
    },
     //是否暗黑模式
     isDark: {
      type: Boolean,
      value: false
    },
    //题目id
    subject_id: {
      type: Number,
      value: 0
    },
    xxmoshi:{
      type: Boolean,
      value: false
    },
  },

  /**
   * 组件的初始数据
   */
  data: {
    nickname:'',
    p_id:'',
    member_id :wx.$cache.get('member_id')
  },

  /**
   * 组件的方法列表
   */
  methods: {
    replyUser() {
      this.triggerEvent('reply',this.properties.item)
    },
    comment(e){
     this.setData({
      showDiscussModal:true,
      nickname:e.currentTarget.dataset.nickname,
      p_id:e.currentTarget.id,
     })
    },
    closeModal(){
      this.setData({
        showDiscussModal:false,

       })
    },
    previewImg(e) { //预览图片
      console.log(e)
      wx.previewImage({
        urls: e.currentTarget.dataset.url,
        current:e.currentTarget.dataset.current,
      })
    },
    submitDiscussData(e) {
      console.log(e.detail.note_content);
      let params = {
        subject_id: this.data.subject_id||this.data.item.subject_id,
        p_id: this.data.p_id,
        content: e.detail.note_content
      }
      wx.$http.post(wx.$api.add_subject_comment, params).then(res => {
        console.log("评论成功");
        wx.showToast({
          title: '评论成功'
        })
        this.triggerEvent('ref',{})
        this.setData({
          showDiscussModal: false
        })
      })
    },
    tosubjectdetail(){//去题目详情
    if(this.data.xxmoshi){
      wx.$cache.set('subjectMakeCardList',[{
        "id": this.data.item.subject_id,
        "make_is_ask_ok": 2,
        "make_state": 3,
        "type": this.data.item.subject_type
      }],)
      wx.navigateTo({
        url: '/subPackageZ/pages/brush-topic/brush-topic?rand=0&collect=1&subject_id='+this.data.item.subject_id,
      })
    }
    },
    bindgive(){//点赞取消点赞
      //判断是笔记还是评论
      let params = {
        log_id: this.data.item?.id,
        type:this.data.type=='note'?1:2
       
      }
      wx.$http.post(wx.$api.add_give_log, params).then(res => {
        this.triggerEvent('ref',{})
      })
        },
        //收藏笔记
        add_collection(e){
          wx.$http.post(wx.$api.add_collection_log, {
            collection_type: 2,
            log_id: this.properties.item.id
          }).then(res => {
            this.triggerEvent('ref',{})
          })  
        },
        bijitiaozhuan(){
          wx.navigateTo({
            url: '/pageQ/pages/note/note',
          })
        }
  },

 
})
