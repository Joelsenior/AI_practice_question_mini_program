// 音频播放的单例化对象，设置仅允许播放一个媒体对象
export class singleton {
  static instance = null
  static getInstance() {
    if (singleton.instance === null) {
      singleton.instance = new singleton();
    }
    return singleton.instance;
  }
  myAudio = (function() {
    console.log("创建全局的AudioContext对象");
    return wx.createInnerAudioContext()
  })()
}