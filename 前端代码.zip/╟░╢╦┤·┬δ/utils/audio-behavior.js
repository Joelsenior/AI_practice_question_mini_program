module.exports = Behavior({
  behaviors: [],
  data: {
    playerAudioId: 0
  },
  attached: function(){
    console.log("zujianbei粗昂见");
  },
  methods: {
    myBehaviorMethod: function(){}
  }
})