// 时间格式化
function formatDate(value, type = 2) {
  console.log('列', value)
  if (!value) {
    return ''
  }
  if (type == 2) {

    var str = value.replace(/-/g, '/'); // 时间格式转换
    // 将字符串转换成时间格式
    var time = new Date(str)
  }
  console.log('wo',time)


  if (type == 3) {
    time = new Date();
  }
  if (type == 4) {
    time = value
  }

  var year = time.getFullYear();
  var month = time.getMonth() + 1;
  var date = time.getDate();
  var hour = time.getHours();
  var minute = time.getMinutes();
  var second = time.getSeconds();
  month = month < 10 ? "0" + month : month;
  date = date < 10 ? "0" + date : date;
  hour = hour < 10 ? "0" + hour : hour;
  minute = minute < 10 ? "0" + minute : minute;
  second = second < 10 ? "0" + second : second;
  if (type == 1) {
    return year + "-" + month + "-" + date + " " + hour + ":" + minute + ":" + second;
  }
  if (type == 2 || type == 4) {
    return year + "-" + month + "-" + date
  }
  if (type == 3) {
    return month + "月" + date + "日"
  }
}
module.exports = {

  formatDate: formatDate
}