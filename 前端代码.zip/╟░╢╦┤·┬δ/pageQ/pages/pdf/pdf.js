// pageQ/pages/pdf/pdf.js
Page({

  /**
   * 页面的初始数据
   */ 
  data: {
// viewer.html 查看器的路径 
pdfView:"https://pdfjs.seniorfd.com/pdfplugin/web/viewer.html?file=", 
showPopup: true,
zhifuPopup:false,
checked: false,
library_id:"",
images:{},
is_jh:0,
pdf_link:"",
jh_price:0,
freshen:false,
urls:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(e) {
    if(!e.library_id){
      return
    } 
    this.setData({
      library_id: e.library_id,
    });
    // 检查是否勾选了不再提示 
    const noPrompt = wx.getStorageSync('noPrompt'); 
    if (noPrompt) {
      this.setData({
        showPopup: false,
      });
    }
    wx.hideShareMenu({
      menus: ['shareAppMessage', 'shareTimeline']
    })
    this.getLibraryList()
  },

  getLibraryList() {//题库
    var  _this=this  
    wx.$http.post(wx.$api.get_pdf,{ 
      library_id:this.data.library_id
    }).then( res => {   
console.log(res)
      _this.setData({
        images:res.images,
        is_jh:res.is_jh,
        pdf_link:encodeURIComponent(res.pdf_link),
        jh_price:res.jh_price

      })
  

	}
	)
  },
  tupian(e){
    this.setData({
      freshen: true,
    });
    console.log(e.target.dataset.img)
    wx.previewImage({
      showmenu: false,
      current: e.target.dataset.img, // 当前显示图片的http链接
      urls: this.data.images, // 需要预览的图片http链接列表
      success: (res) => {
        console.log(res)
        if (res.current === this.data.images[this.data.images.length - 1]) {
          
          // 执行弹窗到最后一张图片时的操作
        }
      }
    })
  },
  onShow(){
    if(this.data.freshen){
      console.log("浏览到最后一张图片");
      this.isPlay()
      this.setData({
        freshen: false,
      });
      
    }
  },
  onUnload() {
    console.log("页面被卸载，用户退出当前页面");
    // 执行用户退出当前页面时的操作
    this.isPlay()
  },

   /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {
    console.log("用户浏览图片到最底部");
    this.isPlay()
  },
    //支付弹窗
    isPlay(){  
      if(this.data.is_jh !=1 &&  parseFloat(this.data.jh_price) >0){
        this.setData({
          zhifuPopup:true
        })
      }
     
    },
    payOrder(){
      var that =this 
      
         wx.$http.post(wx.$api.pdf_pay, {
          library_id: this.data.library_id
         }).then(res => {
          console.log(res)
          wx.requestPayment({
           timeStamp: res.timeStamp,  //后端返回的时间戳
           nonceStr:  res.nonceStr,   //后端返回的随机字符串
           package: res.package, //后端返回的prepay_id
           signType:res.signType, //后端签名算法,根据后端来,后端MD5这里即为MD5
           paySign:  res.paySign,  //后端返回的签名
           success (res) { 
             that.setData({showSchoolUseStateModal: false, inputTextaa: ''})
          
             wx.showToast({
                  title:"支付成功",
                  icon: 'none',
                  duration: 1500
              });
          setTimeout(function(){
                var arr={}
                arr.library_id =that.data.library_id
                that.onLoad(arr)    
          },1500)
           },
           fail (res) { 
             console.log('用户支付扣款失败', res)
           }
          })
         })
       },
  handleCheckboxChange: function(event) { 
    this.setData({
      checked: !this.data.checked,
    });
  },

  handleConfirm: function() { 
    if (this.data.checked) {
      wx.setStorageSync('noPrompt', true); // 将勾选状态存储到本地缓存
    }
    this.setData({
      showPopup: false,
    });
  },
  zhifuHandleConfirm: function() { 
    this.setData({
      zhifuPopup: false,
    });
  },
  get_message(e){
    console.log("e.detail ",e )
},
   
 

  
})