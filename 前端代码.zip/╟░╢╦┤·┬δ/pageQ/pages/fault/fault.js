Page({
  data: {
    menuList: [],
    defaultIndex: [0,0],
    searchParams: {},
    page: 1,
    listData: []
  },

  initSchoolList() {
    wx.$http.post(wx.$api.school_list, {
      is_all: true,
      major_id: wx.$cache.get('majorInfo').id
    }).then(res => {
      this.setData({
        menuList: [
          {
            name: '学校',
            index: 0,
            children: res
          },
          {
            name: '题目分类',
            index: 1,
            children: [{
                name: '全部',
                index: 0
              },
              {
                name: '主观题',
                index: 1
              },
              {
                name: '客观题',
                index: 2
              }
            ]
          }
        ]
      })
    })
  },
  queryData(e) {
    console.log(e);
    if(e.detail[0]) this.setData({'searchParams.school_id': e.detail[0].id})

    let subject_type = ''
    if(e.detail[1].index == 0) subject_type = '1,2,3'
    if(e.detail[1].index == 1) subject_type = '3'
    if(e.detail[1].index == 2) subject_type = '1,2'
    this.setData({
      'searchParams.subject_type': subject_type
      ,page: 1, listData: []
    },() => this.getListData())
  },
  getListData() {
    wx.$http.post(wx.$api.wrong_topic_log_library,this.data.searchParams).then(res => {
      this.setData({listData: this.data.listData.concat(res),page: this.data.page+1})
    })
  },
  pageTo(e) {
    wx.navigateTo({
      url: e.currentTarget.dataset.url,
    })
  },
 
  onShow() {
    this.initSchoolList()
  },
  onReachBottom() {
   
    this.getListData()
  },
  onShareAppMessage() {
    return{
      title:wx.$cache.get('share').title,
      imageUrl:wx.$cache.get('share').img,
      path:`/pages/index/index?pid=${wx.$cache.get('member_id')}`
    }
  }
})