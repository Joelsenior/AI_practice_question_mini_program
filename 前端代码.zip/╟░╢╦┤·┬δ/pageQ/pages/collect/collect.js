// pageQ/page/collect/collect.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    url: '',
    show: false,
    page: 1,
    listData: [],
    menuList: [],
    defaultIndex: [0,1,0],
    searchParams: {}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.setData({
      url: 'https://zwqr.xqxx.online/uploads/mp3/630859405e17320001e1ae9a.mp3'
    })
    this.onInit()
  },

  onInit() {
    this.initSchoolList()
  },
  // 处理完筛选项后开始展示数据
  queryData(e) {
    let subject_type = ''
    if(e.detail[1].index == 0) subject_type = '1,2,3'
    if(e.detail[1].index == 1) subject_type = '3'
    if(e.detail[1].index == 2) subject_type = '1,2'
    let type = ''
    // if(e.detail[2].index == 0) type = '1,2,3'
    if(e.detail[2].index == 1) type = '1'
    if(e.detail[2].index == 2) type = '2'
    if(e.detail[2].index == 3) type = '3'

    if(e.detail[0]) this.setData({ 
      'searchParams.school_id': e.detail[0].id,
      'searchParams.subject_type': subject_type,
      'searchParams.type': type,
      page: 1,
      listData: []
    },() => this.getListData())
    if(!e.detail[0]) this.setData({
      'searchParams.subject_type': subject_type,
      'searchParams.type': type,
      page: 1,
      listData: []
    },() => this.getListData())
  },
  refreshData() {
    this.setData({page: 1, listData: []},() => this.getListData())
  },
  getListData() {
    wx.$http.post(wx.$api.collection_log_list, {collection_type:1,...this.data.searchParams,page: this.data.page,page_size: 10}).then(res => {
      this.setData({listData: this.data.listData.concat(res),page: this.data.page+1})
    })
  },
  initSchoolList() {
    wx.$http.post(wx.$api.school_list, {
      is_all: true,
      major_id: wx.$cache
        .get('majorInfo').id
    }).then(res => {
      this.setData({
        menuList: [
          {
            name: '学校',
            index: 0,
            children:[{name:'全部',id:''},...res] 
          },
          {
            name: '题目分类',
            index: 1,
            children: [{
                name: '全部',
                index: 0
              },
              {
                name: '主观题',
                index: 1
              },
              {
                name: '客观题',
                index: 2
              }
            ]
          },
          {
            name: '题目类型',
            index: 2,
            children: [
              {
                name: '全部',
                index: 0
              },
              {
                name: '重难点',
                index: 1
              },
              {
                name: '易错点',
                index: 2
              },
              {
                name: '其他',
                index: 3
              }
            ]
          }
        ]
      })
    })
  },
  //顺序刷题
  Sequential_brush(){
 
     var subjectMakeCardList=[];
     this.data.listData.forEach(item=>{
      subjectMakeCardList.push({
        "id": item.subject_id,
        "make_is_ask_ok": 2,
        "make_state": 3,
        "type": item.subject_type
      })
     })
        wx.$cache.set('subjectMakeCardList',subjectMakeCardList,)
        wx.navigateTo({
          url: '/subPackageZ/pages/brush-topic/brush-topic?rand=0&collect=2&subject_id='+subjectMakeCardList[0].id,
        })
     
  },
  bindInput(e) {
    this.setData({'searchParams.word_str': e.detail.value})
  },
  querySearch() {
    this.setData({page: 1, listData: []},() => this.getListData())
  },
 
  getResultUrl(res) {
    console.log(res.detail.tempFilePath);
    this.setData({
      url: res.detail.tempFilePath
    })
  },
  onShow() {

  },
  showAudio() {
    this.setData({
      show: true
    })
  },
  
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {
   
    this.getListData()
  },
  onShareAppMessage() {
    return{
      title:wx.$cache.get('share').title,
      imageUrl:wx.$cache.get('share').img,
      path:`/pages/index/index?pid=${wx.$cache.get('member_id')}`
    }
  }
})