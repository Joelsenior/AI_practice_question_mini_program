var app = getApp() 
Page({

  /**
   * 页面的初始数据
   */
  data: { 
    playbackRate: 1.0, // 初始倍数
    buttonLeft: 10, // 初始按钮位置
    videoContext: null,
    currentTime: 0,
    menulist:[],//列表 
    networkflag: false,//是否是wifi
    dianzannum: '',//点赞数
    hasdianzan: false,//是否点赞 
    playStates: true, //控制播放 & 暂停按钮的显示
    playAlls: true,
    mast_video:true,
    z_id:0,
    index:0,//选中下标
   z_det:{},
   showSchoolUseStateModal:false
  },
  quxiao(){
this.setData({
  showSchoolUseStateModal:false
})
  },
   // 全屏状态变化事件
   // 全屏状态变化事件
   fullscreenChange: function(e) {
    let isFullscreen = e.detail.fullscreen;
    let buttonRight = isFullscreen ? 10 : 0; // 在全屏状态下，将按钮右边距设置为 10px，非全屏状态下设置为 0
    let buttonBottom = isFullscreen ? 10 : 0; // 在全屏状态下，将按钮底边距设置为 10px，非全屏状态下设置为 0
    
    this.setData({
      buttonRight: buttonRight,
      buttonBottom: buttonBottom
    });
  },
 
  /**
   * 生命周期函数--监听页面加载
   */ 
  videoOpreation() { //自定义暂停
    this.data.playStates ? this.videoContext.pause() : this.videoContext.play();
    this.setData({
      playStates: !this.data.playStates
    })
  },
  videoAllscreen(e) { //自定义全屏
    this.data.playAlls ? this.videoContext.requestFullScreen() : this.videoContext.exitFullScreen();
    this.setData({
      playAlls: !this.data.playAlls
    })
  },
  video_back: function (e) {
    this.data.playAlls ? this.videoContext.requestFullScreen() : this.videoContext.exitFullScreen();
    this.setData({
      playAlls: !this.data.playAlls
    })
  },
  sliderChanging(e) { //拖拽过程中，不允许更新进度条
    var new_stuflag = wx.getStorageSync("key_stuflag");
    if (new_stuflag == 1) { //学完允许拖动
      this.setData({
        updateState: false
      })
    } else {

    }

  },  
  bindButtonRate(e) { //倍速
    var that = this;
    let rate = e.currentTarget.dataset.rate
    this.setData({
      playbackRate:rate
    })
    this.videoContext.playbackRate(Number(rate))
    setTimeout(function () {
      that.setData({
        change_mast: false,
        mast_video: true,
      })
    }, 400)
  },
 
  onTimeUpdate: function (event) {
    // 更新当前播放位置和视频时长
 
    this.setData({
      currentTime: event.detail.currentTime,
      duration: event.detail.duration
    });
  },

  onReady: function () {
    // 获取 video 组件实例
    this.setData({
      videoContext: wx.createVideoContext('myVideo')
    });
  },
  seed_change: function (s) { //按钮展开倍速
    this.setData({
      mast_video: false,
      change_mast: true,
    })
  },
  close_change: function () { //空白处关闭倍速
    this.setData({
      mast_video: true,
      change_mast: false,
    })
  },
  fetchSearchList: function () {
    let that = this;
    let searchPageNum = that.data.searchPageNum//把第几次加载次数作为参数 
 
    let params = {} 
    params.z_id =that.data.z_id
    params.page_size =15
    params.page=searchPageNum
    wx.$http.post(wx.$api.get_j_list,params).then( res => {
     console.log(res)  
      if (res.info.length != 0) {
        // //判断是否拉起支付弹窗
        // var showSchoolUseStateModal =false
        // if(res.info[0].isjh ==1){
        //   showSchoolUseStateModal =true
        // }
        //拼接数组 
        that.setData({
          // menulist:that.data.menulist.concat(res.info),
          menulist:res.info,
          // showSchoolUseStateModal:showSchoolUseStateModal,
          z_det:res.z,
          searchLoading: false   //把"上拉加载"的变量设为true，显示  
        }); 
      } else {
        that.setData({
          searchLoadingComplete: true, //把“没有数据”设为true，显示  
          searchLoading: false  //把"上拉加载"的变量设为false，隐藏  
        });
      }
   
    })
 
  
    wx.hideLoading()

     
  },
  handleVideoPlay(e){ //用户点击视频播放的时候触发
   
    var index =this.data.index 
    wx.$http.post(wx.$api.click_log, {
      j_id:  this.data.menulist[index].id,
      uid:wx.$cache.get('member_id')
    }).then(res => { 
    })
  },
  payOrder(){
    var that =this 
    
       wx.$http.post(wx.$api.video_pay, {
         zid: this.data.z_id
       }).then(res => {
        console.log(res)
        wx.requestPayment({
         timeStamp: res.timeStamp,  //后端返回的时间戳
         nonceStr:  res.nonceStr,   //后端返回的随机字符串
         package: res.package, //后端返回的prepay_id
         signType:res.signType, //后端签名算法,根据后端来,后端MD5这里即为MD5
         paySign:  res.paySign,  //后端返回的签名
         success (res) { 
           that.setData({showSchoolUseStateModal: false, inputTextaa: ''})
        
           wx.showToast({
                title:"支付成功",
                icon: 'none',
                duration: 1500
            });
        setTimeout(function(){
              var arr={}
              arr.cookbookcode =that.data.z_id
              that.onLoad(arr)    
        },1500)
         },
         fail (res) { 
           console.log('用户支付扣款失败', res)
         }
        })
       })
     },
  qiehuanb(e){ 
 var index =e.currentTarget.dataset.index
     // 读取播放记录
   
     if(index ==this.data.index){
      return
     }
      
      wx.setStorageSync('video_playback_time'+this.data.z_id+"_"+this.data.index, this.data.currentTime);
      // var arr={}
      // arr.cookbookcode =this.data.z_id
      // this.onLoad(arr)   
      this.durationAndTimes()
     this.bofangjilu(this.data.z_id,index)
   
    
  //判断是否拉起支付弹窗
  var showSchoolUseStateModal =false
  if(this.data.menulist[index].isjh ==1){
    showSchoolUseStateModal =true
  }
this.setData(
  {
    showSchoolUseStateModal:showSchoolUseStateModal,
    index:index
  }
)
  },
  onLoad: function (options) {  
    
    this.videoContext = wx.createVideoContext('myVideo');
    let cbcode = options.cookbookcode;
    let that = this;
     // 读取下标 
     var index =  wx.getStorageSync('video_playback_index'+"_"+cbcode);
      if(!index){
        index = 0;
      } 
    that.setData({ 
      z_id:cbcode,
      index:index
    }) 
    this.fetchSearchList()
 
  } ,
  //存储当前视频播放时长，以及播放完成次数 
  //触发场景 ：1  结束当前页面，2 用户切换其他视频 ，3 视频播放结束
  durationAndTimes(){  
    var index =this.data.index 
    wx.$http.post(wx.$api.durationAndTimes, {
      j_id:  this.data.menulist[index].id,
      currentTime:this.data.currentTime,
      duration:this.data.duration ,
      uid:wx.$cache.get('member_id')
    }).then(res => { 
     
    })
  },
  onShow(){
    this.bofangjilu(this.data.z_id,this.data.index)
  },
  onUnload: function () { 
    this.durationAndTimes()
    // 页面卸载时存储当前播放位置
    wx.setStorageSync('video_playback_time'+this.data.z_id+"_"+this.data.index, this.data.currentTime);
 
    wx.setStorageSync('video_playback_index'+"_"+this.data.z_id,this.data.index);
  },
  bofangjilu(z_id,index){ 
     // 读取播放记录

     var currentTime = wx.getStorageSync('video_playback_time' + z_id + '_' + index);
   
     if(!currentTime){
      currentTime = 0;
     }
     this.setData({
      currentTime: currentTime
    });
    if(currentTime !=0){
      this.videoContext.seek(currentTime);
    }
    
  
    
  },
  onEnded: function () {
    // 当视频播放结束时，将播放位置重置为0
  this.durationAndTimes() //重置前调用记录
    this.setData({
      currentTime: 0
    }); 
    wx.setStorageSync('video_playback_time'+this.data.z_id+"_"+this.data.index, 0);
  },



  
})