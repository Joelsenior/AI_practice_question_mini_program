// pageQ/pages/fault-detail/fault-detail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    library_id: 0,//题库id
    page: 1,
    listData: [],//错题集
    word_str: "",//关键词
    subject_type:'1,2,3',//题目类型
    school_id:0,//学校id
    major_id:wx.$cache.get('majorInfo').id,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.setData({
      library_id: options.id,
      subject_type:options.type,
      school_id:options.school_id,
      major_id:wx.$cache.get('majorInfo').id
    },() => this.getListData())
  },
  querySearch() {
    this.setData({page: 1,listData: []},() => this.getListData())
  },
  refreshData() {
    console.log('刷新')
    this.setData({page: 1,listData: []},() => this.getListData())
  },
  getListData() {
    if(this.data.word_str) {
      wx.$http.post(wx.$api.wrong_topic_log_subject,{subject_type:this.data.subject_type,library_id: this.data.library_id,page: this.data.page, page_size: 10, word_str: this.data.word_str}).then(res => {
        this.setData({listData: [...this.data.listData, ...res],page: this.data.page + 1})
      })
    } else {
      wx.$http.post(wx.$api.wrong_topic_log_subject,{subject_type:this.data.subject_type,library_id: this.data.library_id,page: this.data.page, page_size: 10}).then(res => {
        this.setData({listData: [...this.data.listData, ...res],page: this.data.page + 1})
      })
    }
  },
  onReachBottom() {
    this.getListData()
  },
  

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },
  Sequential_brush(){
 
    var subjectMakeCardList=[];
    this.data.listData.forEach(item=>{
     subjectMakeCardList.push({
       "id": item.subject_id,
       "make_is_ask_ok": 2,
       "make_state": 3,
       "type": item.type
     })
    })
       wx.$cache.set('subjectMakeCardList',subjectMakeCardList,)
       wx.navigateTo({
         url: '/subPackageZ/pages/brush-topic/brush-topic?rand=0&collect=2&subject_id='+subjectMakeCardList[0].id,
       })
    
 },

onShareAppMessage() {
  return{
    title:wx.$cache.get('share').title,
    imageUrl:wx.$cache.get('share').img,
    path:`/pages/index/index?pid=${wx.$cache.get('member_id')}`
  }
}
})