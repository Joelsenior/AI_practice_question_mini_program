// pageQ/pages/note_list/note_list.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isShowModal: false,
    type: 1, //1评论，2、笔记
    subject_id: 0, //题目id
    listData: [],
  },
  onLoad(options) {
    this.setData({
      type: options.type,
      subject_id: options.subject_id
    })
    if (options.type == 1) {
      wx.setNavigationBarTitle({
        title: '评论',
      })
      this.subject_commentlist()
    } else {
      this.subject_notelist()
    }
  },
  refresh() { //刷新评论点赞
    if (this.data.type == 1) {

      this.subject_commentlist()
    } else {
      this.subject_notelist()
    }
  },
  showNoteModal() { //打开评论
    this.setData({
      isShowModal: true
    })
  },
  closeModal() { //关闭组件
    this.setData({
      isShowModal: false,
      showRecordModal: false
    })
  },
  submitNoteData(e) { //记录笔记
    const params = e.detail
    if (params.note_type == 1 && params.note_content == "") return wx.showToast({
      title: '笔记不能为空',
      icon: 'none'
    })
    if (params.note_type == 2 && params.note_imgs.length == 0) return wx.showToast({
      title: '图片不能为空',
      icon: 'none'
    })
    if (params.note_type == 3 && params.note_audio == "") return wx.showToast({
      title: '录音不能为空',
      icon: 'none'
    })
    params.subject_id = this.data.subject_id
    if (params.note_type == 2) params.note_imgs = params.note_imgs.map(value => value.url).join(',')
    wx.$http.post(wx.$api.add_note, params).then(res => {
      wx.showToast({
        title: '操作成功'
      })
      this.closeModal()
      this.refresh()
    })
  },
  //打开笔记
  openRecordModal() {
    this.setData({
      showRecordModal: true
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  subject_notelist() { //笔记列表
    wx.$http.post(wx.$api.subject_note, {
      subject_id: this.data.subject_id,
      member_id: wx.$cache.get('userinfo').id,
      is_all: 1,
    }).then(res => {
      this.setData({
        listData: res
      })
    })
  },

  subject_commentlist() {
    wx.$http.post(wx.$api.subject_comment, {
      subject_id: this.data.subject_id,
      member_id: wx.$cache.get('userinfo').id,
      is_all: 1,
    }).then(res => {
      this.setData({
        listData: res
      })
    })
  },
  submitDiscussData(e) {
    console.log(e.detail.note_content);
    let params = {
      subject_id: this.data.subject_id,

      content: e.detail.note_content
    }
    wx.$http.post(wx.$api.add_subject_comment, params).then(res => {
      console.log("评论成功");
      wx.showToast({
        title: '评论成功'
      })
      this.refresh()
      this.closeModal()
    })
  },
})