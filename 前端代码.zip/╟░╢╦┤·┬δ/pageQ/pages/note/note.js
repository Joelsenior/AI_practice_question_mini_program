Page({
    data: {
        menuList: [],
        defaultIndex: [0, 0, 0],
        searchParams: {},
        page: 1,
        listData: [],
        word_str: '',
        
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.initSchoolList()
    },
    initSchoolList() {
        wx.$http.post(wx.$api.school_list, {
            is_all: true,
            major_id: wx.$cache.get('majorInfo').id
        }).then(res => {
            this.setData({
                menuList: [{
                        name: '学校',
                        index: 0,
                        children: [{
                                name: '学校',
                                id: ''
                            },
                            ...res
                        ]
                    },
                    {
                        name: '全部题库',
                        index: 1,
                        children: [{
                                name: '全部题库',
                                id: ''
                            },

                        ]
                    },
                    {
                        name: '笔记',
                        index: 2,
                        children: [{
                                name: '我的笔记',
                                index: 1
                            },
                            {
                                name: '他人笔记',
                                index: 2
                            }
                        ]
                    }
                ]
            })
            this.querySearch();
        })
    },
    ExportNote() {
        wx.showLoading({
            title: '正在导出，请稍后....',
        })
        wx.$http.post(wx.$api.export_my_note, {
            ...this.data.searchParams,
            word_str: this.data.word_str,
        }).then(res => {
            console.log(res)
            wx.downloadFile({
                url: res,
                success(res) {
                    // 只要服务器有响应数据，就会把响应内容写入文件并进入 success 回调，业务需要自行判断是否下载到了想要的内容
                    if (res.statusCode === 200) {
                        wx.openDocument({
                            filePath: res.tempFilePath,
                            showMenu: true,
                        })

                    }
                }
            })

            wx.hideLoading()
        }).cache

    },
    queryData(e) {
        console.log(e)
        if (!e.detail[0]) return wx.showToast({
            title: '学校列表为空',
            icon: 'none'
        })

        this.setData({
            'searchParams.school_id': e.detail[0].id,
            'searchParams.is_my': e.detail[2].index,
            //   'searchParams.subject_type': e.detail[1].index == 0 ? '1,2,3' :e.detail[3].index == 1?'1,2': '3',
            'searchParams.library_id': e.detail[1].id,
            page: 1,
            listData: []
        }, () => this.getListData(), )
    },

    querySearch() {
        this.data.page = 1
        this.data.listData = []
        this.getListData();
    },
    getListData() {
        wx.$http.post(wx.$api.my_note, {
            ...this.data.searchParams,
            word_str: this.data.word_str,
            page: this.data.page,
            page_size: 10
        }).then(res => {
            this.setData({
                listData: [...this.data.listData, ...res],
                page: this.data.page + 1
            })
        })
    },
    onReachBottom() {
        this.getListData()
    },

})