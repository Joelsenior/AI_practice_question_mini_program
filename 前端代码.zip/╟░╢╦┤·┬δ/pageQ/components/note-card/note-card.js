// pageQ/components/note-card/note-card.js
Component({
    /**
     * 组件的属性列表
     */
    properties: {
        item: {
            type: Object,
            value: {}
        }
    },

    /**
     * 组件的初始数据
     */
    data: {
        showRecordModal: false, //修改笔记弹窗
        member_id: wx.$cache.get('member_id')
    },

    /**
     * 组件的方法列表
     */
    methods: {
        //收藏/取消笔记
        add_collection(e) {
            wx.$http.post(wx.$api.add_collection_log, {
                collection_type: 2,
                log_id: this.properties.item.id
            }).then(res => {
                this.triggerEvent('refresh', {})
            })
        },
        bindedit_note() { //修改i笔记
            this.setData({
                showRecordModal: true
            })
        },
        closeModal(){
          this.setData({
            showRecordModal: false
        })
        },
        previewImg(e) { //预览图片
          console.log(e)
          wx.previewImage({
            urls: e.currentTarget.dataset.url,
            current:e.currentTarget.dataset.current,
          })
        },
        submitNoteData(e) { //记录笔记
            var _this = this
            const params = e.detail
            if (params.note_type == 1 && params.note_content == "") return wx.showToast({
                title: '笔记不能为空',
                icon: 'none'
            })
            if (params.note_type == 2 && params.note_imgs.length == 0) return wx.showToast({
                title: '图片不能为空',
                icon: 'none'
            })
            if (params.note_type == 3 && params.note_audio == "") return wx.showToast({
                title: '录音不能为空',
                icon: 'none'
            })
            params.subject_id = this.data.subject_id
            if (params.note_type == 2) params.note_imgs = params.note_imgs.map(value => value.url).join(',')
            wx.$http.post(wx.$api.edit_note, params).then(res => {
                wx.showToast({
                    title: '修改成功'
                })
                this.setData({
                    showRecordModal: false
                })
                _this.triggerEvent('refresh', {})
            })
        },
        binddel_note() { //删除笔记
            var _this = this
            wx.showModal({
                title: '删除笔记',
                content: '确定要删除该笔记吗？',
                complete: (res) => {
                    if (res.cancel) {

                    }

                    if (res.confirm) {
                        wx.$http.post(wx.$api.del_note, {
                            note_id: _this.data.item.id
                        }).then(res => {
                            _this.triggerEvent('refresh', {})
                        })
                    }
                }
            })


        },
        tosubjectdetail() { //去题目详情
            wx.navigateTo({
                url: '/subPackageZ/pages/brush-topic/brush-topic?rand=0&collect=1&subject_id=' + this.data.item.subject_id,
            })
        },
    }
})