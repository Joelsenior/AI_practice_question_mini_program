// pageQ/components/collect-card/collect-card.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    item: {
      type: Object,
      value: {}
    },
    ids:{
      type: Number,
      value: 1
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    tosubjectdetail(){//去题目详情
      console.log(this.data.item)
      wx.$cache.set('subjectMakeCardList',[{
        "id": this.data.item.subject_id,
        "make_is_ask_ok": 2,
        "make_state": 3,
        "type": this.data.item.type
      }],)
      wx.navigateTo({
        url: '/subPackageZ/pages/brush-topic/brush-topic?rand=0&collect=1&subject_id='+this.data.item.subject_id,
      })
    },
    movoeCollectHandle() {
      wx.showActionSheet({
        alertText: '请选择收藏夹',
        itemList: ['重难点','易错点','其他'],
      })
    },
    cancelCollectHandle() {
      const _this = this;
      wx.showModal({
        title: '是否删除？',
        content: "删除将不在错题夹展示",
        success(e) {
          if(e.confirm) {
            wx.$http.post(wx.$api.del_wrong_topic,{subject_id: _this.properties.item.subject_id}).then(() => {
              wx.showToast({title: '操作成功'})
              _this.triggerEvent('refresh')
            })
          }
        }
      })
    }
  }
})
