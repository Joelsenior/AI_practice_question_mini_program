Component({
    properties: {
        menuList: {
            type: Array,
            value: []
        },
        sortCheckIndex: {
            type: Array,
            value: []
        },
        type: {
            type: String,
            value: 'mistakes'
        }

    },
    observers: {
        'menuList': function (val) {
            if (this.data.type == 'mistakes') {
                this.initCheckIndex()
            }else{
                this.setData({
                    checkedIndex: [0,0,0]
                })
            }

        }
    },
    data: {
        isDidShow: false,
        firstIndex: 0,
        checkedIndex: []
    },
    lifetimes: {
        // attached() {
        //   this.initCheckIndex()
        // }
    },
    methods: {
        catchTap() {

        },
        initCheckIndex() {
            let arr = []
            this.properties.menuList.forEach(value => arr.push(0))
            console.log(arr)
            if (arr.length != this.properties.sortCheckIndex.length) this.setData({
                checkedIndex: arr
            })
            else this.setData({
                checkedIndex: this.properties.sortCheckIndex
            })

            //  初始化筛选参数
            let tempSendData = []
            this.data.checkedIndex.forEach((value, index) => {
                tempSendData.push(this.properties.menuList[index].children[value])
            })
            this.triggerEvent('query', tempSendData)
        },
        closeModal() {
            this.setData({
                isDidShow: false
            })
        },
        openGetItem(e) {
            const tempIsDidShow = this.data.isDidShow
            if (!tempIsDidShow) {
                this.setData({
                    firstIndex: e.currentTarget.dataset.index,
                    isDidShow: true
                })
            }
            if (tempIsDidShow && this.data.firstIndex == e.currentTarget.dataset.index) {
                this.setData({
                    isDidShow: false
                })
            }
            if (tempIsDidShow && this.data.firstIndex != e.currentTarget.dataset.index) {
                this.setData({
                    firstIndex: e.currentTarget.dataset.index,
                    isDidShow: true
                })
            }
        },
        clickHandle(e) {
            const {
                subindex
            } = e.currentTarget.dataset
            console.log(e)
            let checkIndexTempData = JSON.parse(JSON.stringify(this.data.checkedIndex))
            checkIndexTempData[this.data.firstIndex] = subindex
            //如果是笔记
            if (this.data.type = 'note' && this.data.firstIndex == 0) {
                this.get_library_list(this.properties.menuList[0].children[subindex].id)
                checkIndexTempData[1] = 0
               
            }
            console.log(checkIndexTempData)
            this.setData({
                checkedIndex: checkIndexTempData,
                isDidShow: false
            })
            // 整理数据并发送到父级元素
            let tempSendData = []
            this.data.checkedIndex.forEach((value, index) => {
                tempSendData.push(this.properties.menuList[index].children[value])
            })
            this.triggerEvent('query', tempSendData)
        },
        get_library_list(id) { //拉取题库列表
            wx.$http.post(wx.$api.library_list, {
                is_all: 1,
                school_id: id
            }).then(res => {
                this.setData({
                    'menuList[1]': {
                        name: '全部题库',
                        index: 1,
                        children: [{
                                name: '全部题库',
                                id: ''
                            },
                            ...res
                        ]
                    },
                })
            })
        },
    }
})