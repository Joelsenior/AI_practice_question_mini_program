// pageQ/components/collect-card/collect-card.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    item: {
      type: Object,
      value: {}
    },   ids:{
      type: Number,
      value: 1
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    movoeCollectHandle() {
      wx.showActionSheet({
        alertText: '请选择收藏夹',
        itemList: ['重难点','易错点','其他'],
        success: (e) => {
          wx.$http.post(wx.$api.edit_collection_type,{collection_type: 1, log_id: this.properties.item.log_id, type: (e.tapIndex + 1)}).then(res => {
            wx.showToast({title: '操作成功'}).then(e => {
              this.triggerEvent('refresh')
            })
          })
        }
      })
    },
    tosubjectdetail(){//去题目详情
      wx.$cache.set('subjectMakeCardList',[{
        "id": this.data.item.subject_id,
        "make_is_ask_ok": 2,
        "make_state": 3,
        "type": this.data.item.subject_type
      }],)
      wx.navigateTo({
        url: '/subPackageZ/pages/brush-topic/brush-topic?rand=0&collect=1&subject_id='+this.data.item.subject_id,
      })
    },
    cancelCollectHandle() {
      const that = this;
      wx.showModal({
        title: '是否取消收藏？',
        content: "取消收藏将不在收藏夹展示",
        success(e) {
          if(e.confirm) {
            wx.$http.post(wx.$api.add_collection_log,{collection_type: 1,log_id: that.properties.item.log_id}).then(e => {
              wx.showToast({
                title: '操作成功',
              }).then(e => {
                that.triggerEvent('refresh')
              })
            })
          }
        }
      })
    }
  }
})
